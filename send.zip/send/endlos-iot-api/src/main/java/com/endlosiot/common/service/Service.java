package com.endlosiot.common.service;

/**
 * This is a marker interface used to identifies service.
 *
 * @author chetanporwal
 * @since 29/08/2023
 */
public interface Service {
}
