package com.endlosiot.common.notification.operation;

import com.endlosiot.common.notification.view.EmailContentView;
import com.endlosiot.common.operation.BaseOperation;

/**
 * @author Nirav.Shah
 * @since 23/07/2018
 */
public interface EmailContentOperation extends BaseOperation<EmailContentView> {
}
