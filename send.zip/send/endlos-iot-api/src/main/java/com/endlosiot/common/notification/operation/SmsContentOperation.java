package com.endlosiot.common.notification.operation;

import com.endlosiot.common.notification.view.SmsContentView;
import com.endlosiot.common.operation.BaseOperation;

/**
 * @author neha
 * @since 15/02/2023
 */
public interface SmsContentOperation extends BaseOperation<SmsContentView> {
}
