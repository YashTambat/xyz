import { Injectable } from '@angular/core';
import { Pagination } from 'src/app/common/interfaces/entities/entity';
import { ListResponse, ViewResponse } from 'src/app/common/interfaces/response';
import { ApiUrl } from 'src/app/constant/app-url';
import { HttpService } from 'src/app/services/http.service';
import * as XLSX from 'xlsx';
import * as FileSaver from 'file-saver';
@Injectable({
  providedIn: 'root'
})
export class ReportService {

  constructor(private httpService: HttpService) {}

  list(pagination: Pagination, data: any): Promise<ListResponse> {
      const params = `start=${pagination.pageIndex * pagination.pageSize}&recordSize=${pagination.pageSize}`;
      return this.httpService.postAuth<ListResponse>(`${ApiUrl.REPORT_SEARCH}?${params}`, data, true).then((listResponse: ListResponse) => {
          pagination.length = listResponse.records;
          return listResponse;
      });
  }

  delete(id: number): Promise<ListResponse> {
      return this.httpService.deleteAuth(`${ApiUrl.REPORT_DELETE}?id=${id}`);
  }

  view(reportId: number): Promise<ViewResponse> {
      return this.httpService.getAuth(`${ApiUrl.REPORT_VIEW}?id=${reportId}`, true);
  }

  save(reportView: Report): Promise<ViewResponse> {
      return this.httpService.postAuth(`${ApiUrl.REPORT_SAVE}`, reportView);
  }

  update(reportView: Report): Promise<ViewResponse> {
      return this.httpService.putAuth(`${ApiUrl.REPORT_UPDATE}`, reportView);
  }

  portDropDown(): Promise<ListResponse> {
      return this.httpService.getAuth(`${ApiUrl.PORT_DROPDOWN}`);
  }

  generateExcel(data: any[], fileName: string): void {
    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(data);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    const excelBuffer: any = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
    this.saveAsExcelFile(excelBuffer, fileName);
  }
 
  private saveAsExcelFile(buffer: any, fileName: string): void {
    const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    FileSaver.saveAs(blob, fileName + '_export.xlsx');
  }

  getParameterWiseReport(data): Promise<any> {
    return this.httpService.postAuth(`${ApiUrl.REPORT_GET_PARAMETER_WISE}`,data);
  }

  downloadReport(filter: any): Promise<any> {
    return this.httpService.postAuthBlob(`${ApiUrl.REPORT_GET_EXCEL}`, filter);
  }

}
