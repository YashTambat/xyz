import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReportListComponent } from './report-list/report-list.component';
import { ReportRouting } from './report-routing';
import { SharedModule } from 'src/app/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ReportChartComponent } from './report-chart/report-chart.component';
import { ZingChartModule } from 'src/app/shared/components/zing-chart/zing-chart.module';



@NgModule({
  declarations: [
    ReportListComponent,
    ReportChartComponent
  ],
  imports: [
    CommonModule,
    ReportRouting,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    ZingChartModule
  ]
})
export class ReportModule { }
