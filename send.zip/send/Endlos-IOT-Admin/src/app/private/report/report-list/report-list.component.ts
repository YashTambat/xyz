import { Component } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { IdName, KeyValue, Pagination } from "src/app/common/interfaces/entities/entity";
import { ListResponse } from "src/app/common/interfaces/response";
import { PageTitle } from "src/app/constant/page-title";
import { Line100By50Theme, Line100PercentBy300Theme } from "src/app/constant/skeleton-theme";
import { SnackBarService } from "src/app/shared/components/services/snackbar.service";
import { paginationFactory } from "src/app/shared/entities/pagination";
import { PaginationType } from "src/app/shared/enums/common-enums";
import { ReportService } from "../report.service";
import { Report } from 'src/app/shared/entities/Report';
import { range } from "lodash";
import { FormBuilder, FormControl, FormGroup, Validators } from "@angular/forms";
import * as moment from "moment";
import { DeviceDiagnosisService } from "../../diagnosis/device-diagnosis/device-diagnosis.service";
import { DeviceService } from "../../device/device.service";
import { ParameterMapping } from "src/app/shared/entities/ParameterMapping";


@Component({
  selector: 'app-report-list',
  templateUrl: './report-list.component.html',
  providers: [ReportService, DeviceDiagnosisService, DeviceService]
})
export class ReportListComponent {

  pagination!: Pagination;
  reportList: Report[] = [];
  hasData = false;
  breadcrumbs: KeyValue[];
  hasAppliedFilter = false;
  searchedData = '';
  placeholderList = range(24);
  cardPlaceholderList = range(9);
  theme = Line100By50Theme;
  cardTheme = Line100PercentBy300Theme;
  displayedColumns: string[] = ['date', 'time', 'flow'];
  selectElement = new Report();
  isDeleteDialogBoxOpen = false;
  deviceType = [];
  deviceSelectOptions = [
    { name: 'Flowmeter', id: 0 },
    { name: 'Turbidity', id: 1 },
    { name: 'Chlorine', id: 2 },
    { name: 'Pressure', id: 3 },
  ];
  headerName = this.deviceSelectOptions[0].name;
  flowmetterData = [
    { 'Date': '2022-02-16 14:00:02', 'TotaFlow': '1000', 'LastUpdatedValue': '19,10,230', 'PreviousUpdatedValue': '1,10,230' },
    { 'Date': '2022-02-17 14:00:02', 'TotaFlow': '2000', 'LastUpdatedValue': '19,10,230', 'PreviousUpdatedValue': '1,10,230' },
    // Add more static data as needed
  ];
  turbidityData = [
    { 'Date': '2022-02-18 14:00:02', 'TotaFlow': '3000', 'LastUpdatedValue': '19,10,230', 'PreviousUpdatedValue': '1,10,230' },
    { 'Date': '2022-02-19 14:00:02', 'TotaFlow': '4000', 'LastUpdatedValue': '19,10,230', 'PreviousUpdatedValue': '1,10,230' },
    // Add more static data as needed
  ];
  chlorineData = [
    { 'Date': '2022-02-20 14:00:02', 'TotaFlow': '5000', 'LastUpdatedValue': '19,10,230', 'PreviousUpdatedValue': '1,10,230' },
    { 'Date': '2022-02-21 14:00:02', 'TotaFlow': '6000', 'LastUpdatedValue': '19,10,230', 'PreviousUpdatedValue': '1,10,230' },
    // Add more static data as needed
  ];
  pressureData = [
    { 'Date': '2022-02-22 14:00:02', 'TotaFlow': '7000', 'LastUpdatedValue': '19,10,230', 'PreviousUpdatedValue': '1,10,230' },
    { 'Date': '2022-02-23 14:00:02', 'TotaFlow': '8000', 'LastUpdatedValue': '19,10,230', 'PreviousUpdatedValue': '1,10,230' },
    // Add more static data as needed
  ];
  selectedArray: any[];
  selectedArray2: any;
  selectedData: string | undefined;
  deviceTypeId!: number;
  filterForm: FormGroup;
  moment1: any = moment();
  deviceList: any[];
  parameterList: ParameterMapping[];
  totalRecords: number;
  graphStartDate: any;
  selectedDeviceType: any;
  reportTypeList: any[];
  isDateRange = true;
  reportTypeId = 1;

  constructor(
    private reportService: ReportService,
    private router: Router,
    private snackbarService: SnackBarService,
    private fb: FormBuilder,
    private deviceDiagnosisService: DeviceDiagnosisService,
    private deviceService: DeviceService,
    private activatedRoute: ActivatedRoute
  ) {
    this.breadcrumbs = [
      { key: PageTitle.REPORT, value: '' }
    ];
    this.pagination = paginationFactory(PaginationType.table);
    // this.combinedArray = [...this.flowmetterData, ...this.turbidityData, ...this.chlorineData,...this.pressureData];
    this.filterForm = this.fb.group({
      deviceViewId: new FormControl(8, Validators.compose([Validators.required])),
      parameterMasterViewId: new FormControl(1, Validators.compose([Validators.required])),
      startDate: new FormControl(this.moment1._d, Validators.compose([Validators.required])),
      endDate: new FormControl(this.moment1._d, Validators.compose([Validators.required])),
      reportType: new FormControl(1, Validators.compose([Validators.required]))
    });
  }

  // selectDevice(value: IdName){
  //   this.deviceTypeId = value.id;
  //   this.headerName = this.deviceSelectOptions.find(f=>f.id == value.id).name
  //   switch (this.deviceTypeId) {
  //     case 0:
  //       this.selectedArray = this.flowmetterData;
  //       break;
  //     case 1:
  //       this.selectedArray = this.turbidityData;
  //       break;
  //     case 2:
  //       this.selectedArray = this.chlorineData;
  //       break;
  //     case 3:
  //       this.selectedArray = this.pressureData;
  //       break;
  //   }
  // }

  downloadExcel(): void {
    const filter: any = {};
    filter.deviceView = { id: this.filterForm.value.deviceViewId };
    filter.parameterMasterView = { id: this.filterForm.value.parameterMasterViewId };
    filter.startDate = moment(this.filterForm.value.startDate).startOf('day').unix();
    filter.endDate = moment(this.filterForm.value.startDate).endOf('day').unix();
    filter.reportType = { key: this.filterForm.value.reportType };
    this.reportService.downloadReport(filter).then((response: any) => {
      const url = window.URL.createObjectURL(response);
      // Create a temporary anchor element
      const a = document.createElement('a');
      a.href = url;
      a.download = new Date().getTime().toString() + 'report.xlsx'; // Set the file name
      // Trigger the download
      document.body.appendChild(a);
      a.click();
      // Cleanup
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    });
  }

  ngOnInit(): void {
    const data: any = sessionStorage.getItem('reportFilter');
    const filterData = JSON.parse(data);
    if (filterData && (filterData.searchedData)) {
      this.searchedData = filterData.searchedData ? filterData.searchedData : null;
      this.hasAppliedFilter = true;
    }
    // this.onSearch();
    this.onDeviceDropDown();
    this.getReportTypeDropDown();
  }

  onSearch() {
    this.hasData = false;
    const data: any = {};
    if (this.searchedData) {
      data.name = this.searchedData;
    }
    this.reportService.list(this.pagination, data).then((response: ListResponse) => {
      this.reportList = response.list as Report[];
    }).finally(() => {
      this.hasData = true;
    });
  }

  changeView(type: string) {
    // this.isListButtonName = type === 'grid' ? false : true;
    // this.pagination = paginationFactory(this.isListButtonName ? PaginationType.table : PaginationType.card);
    this.onSearch();
  }

  onSearched(event: any) {
    if (event) {
      this.searchedData = event;
      this.hasAppliedFilter = true;
      this.setFilterStorage();
    }
    else {
      this.onCancel(1);
    }
  }

  setFilterStorage() {
    const data: any = {};
    data.searchedData = this.searchedData;
    sessionStorage.setItem('reportFilter', JSON.stringify(data));
    this.onSearch();
  }

  onCancel(index: number) {
    switch (index) {
      case 1:
        this.searchedData = '';
        break;
      case 2:
        this.searchedData = '';
        this.hasAppliedFilter = false;
        break;
    }
    if (!this.searchedData) {
      this.hasAppliedFilter = false;
    }
    this.setFilterStorage();
  }

  gotoView(reportID: number) {
    // this.router.navigate([Url.REPORT_VIEW + '/' + reportID]);
  }

  gotoEdit(reportID: number) {
    // this.router.navigate([Url.REPORT_EDIT + '/' + reportID]);
  }
  onDelete(reportData: Report) {
    this.selectElement = reportData;
    this.isDeleteDialogBoxOpen = true;
  }

  submitDelete(event: any) {
    if (event) {
      this.reportService.delete(this.selectElement.id).then(() => {
        this.snackbarService.successSnackBar('Report deleted successfully.');
        this.onSearch();
      }).finally(() => {
        this.isDeleteDialogBoxOpen = false;
      });
    }
  }

  getReportTypeDropDown() {
    this.deviceDiagnosisService.reportTypeDropDown().then((response: ListResponse) => {
      this.reportTypeList = response.list as any[];
    })
  }


  onDeviceDropDown() {
    this.deviceDiagnosisService.deviceDropDown().then((response: ListResponse) => {
      this.deviceList = response.list as any[];
      this.getParameterMappingDropdown();
    })
  }

  getParameterMappingDropdown() {
    this.deviceService.parameterMappingMachineDropdown().then((response: ListResponse) => {
      this.parameterList = response.list as ParameterMapping[];
      this.activatedRoute.queryParams.subscribe(params => {
        const parameterMasterViewId = Number(params['parameter']);
        const deviceViewId = Number(params['device']);
        if (parameterMasterViewId && deviceViewId) {
          this.filterForm.patchValue({ deviceViewId: deviceViewId })
          this.filterForm.patchValue({ parameterMasterViewId })
          this.getParameterWiseReport();
        }
      });
    })
  }

  getParameterWiseReport() {
    this.hasData = false;
    const filter: any = {};
    filter.deviceView = { id: this.filterForm.value.deviceViewId };
    filter.parameterMasterView = { id: this.filterForm.value.parameterMasterViewId };
    filter.startDate = moment(this.filterForm.value.startDate).startOf('day').unix();
    filter.endDate = moment(this.filterForm.value.endDate).endOf('day').unix();
    filter.reportType = { key: this.filterForm.value.reportType };
    this.selectedDeviceType = this.parameterList.find(a => a.id == filter.parameterMasterView.id)
    if (!this.isDateRange) {
      filter.endDate = null;
    }
    if (this.selectedDeviceType) {
      if (filter.parameterMasterView.id == 1) this.selectedDeviceType['key'] = 'flow';
      if (filter.parameterMasterView.id == 2) this.selectedDeviceType['key'] = 'cholrine';
      if (filter.parameterMasterView.id == 3) this.selectedDeviceType['key'] = 'turbidity';
      if (filter.parameterMasterView.id == 4) this.selectedDeviceType['key'] = 'pressureTransmitter';
      if (filter.parameterMasterView.id == 5) this.selectedDeviceType['key'] = 'levelSensor';
    }
    this.reportService.getParameterWiseReport(filter).then(data => {
      this.selectedArray = data.list;
      this.selectedArray2 = this.groupBy1Hour(data.list);
      this.totalRecords = data.records;
      this.graphStartDate = this.filterForm.value.startDate;
      this.hasData = true;
    }).finally(() => {
      this.hasData = true;
    });
  }

  groupBy1Hour(timestamps) {
    const groupedData = [];
    // Initialize groupedData with 24 empty groups, one for each hour
    for (let i = 0; i < 24; i++) {
      groupedData.push({
        hour: i,
        dateEpoch: null,
        dataDeviceViews: []
      });
    }
    timestamps.forEach(obj => {
      // Convert timestamp to milliseconds
      const timestamp = obj.createDate;
      const date = new Date(timestamp * 1000);
      // Calculate the hour of the day for the timestamp
      const hourOfDay = date.getHours();
      // Find the group for the hour
      const hourGroup = groupedData.find(group => group.hour === hourOfDay);
      // Add object to the hour group
      hourGroup.dataDeviceViews.push({ ...obj, actualName: this.selectedDeviceType.name, "max": obj[this.selectedDeviceType.key], "value": obj[this.selectedDeviceType.key] });
      if (hourGroup.dateEpoch === null) {
        hourGroup.dateEpoch = obj.createDate;
      }
    });
    return groupedData;
  }

  onPaginationChange(event) {
    console.log(event);
  }

  onReportTypeChange(value: any) {
    this.isDateRange = value === 1
  }

}
