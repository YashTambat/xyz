
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/auth-guard';   
import { ReportListComponent } from './report-list/report-list.component';

const routes: Routes = [
    { path: '', component: ReportListComponent, canActivate: [AuthGuard] }, 
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class ReportRouting {}