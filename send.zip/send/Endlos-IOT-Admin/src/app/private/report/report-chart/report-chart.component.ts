import { Component, Inject, Input, OnInit, SimpleChanges } from '@angular/core';
import { Observable } from 'rxjs';
import * as _ from 'lodash';
import { ChartQuery, ChartService } from 'src/app/shared/components/zing-chart/akita/chart';
import { CHART_WRAPPER_SERVICE } from 'src/app/shared/components/zing-chart/chart-services/chart-wrapper-service';
import { ReportChartWrapperService } from 'src/app/shared/components/zing-chart/chart-services/report-chart-wrapper.service';
import { Constants } from 'src/app/shared/components/zing-chart/constants';
import { ChartType } from 'src/app/shared/components/zing-chart/enums';
import { ChartTypeSelector } from 'src/app/shared/components/zing-chart/interface';

@Component({
  selector: 'app-report-chart',
  templateUrl: './report-chart.component.html',
  styleUrls: ['./report-chart.component.scss'],
  providers: [{ provide: CHART_WRAPPER_SERVICE, useClass: ReportChartWrapperService }],
})
export class ReportChartComponent implements OnInit {
  chartType$: Observable<ChartTypeSelector>;
  chartType = ChartType;
  @Input() dataDeviceList: Array<any> = [];
  @Input() selectedDeviceType:any;
  @Input() dataDeviceListData: Array<any> = [];
  legends: any[] = [];
  colorList = ['#54c1fb', '#6d71f8', '#ff505a', '#fe8057', '#11ce8c', '#FFBD44', '#2D4EF5', '#0b9999']
  tempChartData: any;

  constructor(@Inject(CHART_WRAPPER_SERVICE) private chartWrapperService: ReportChartWrapperService,
    private chartQuery: ChartQuery,
    private chartService: ChartService
  ) { }
  ngOnInit(): void {
    this.chartType$ = this.chartQuery.getChartTypeSelectorObservable(this.chartWrapperService.getChartEntityId());
    this.generateChart();
    this.updateAkita();
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.generateChart();
    this.updateAkita();
  }

  generateChart() {
    const seriesList: any = [];
    const labels: any = [];
    this.legends = [];
    const markers: any = [];
    this.legends = Object.assign([], this.legends);
    if (this.dataDeviceList) {
      this.dataDeviceList.forEach((dataDeviceObj) => {
        if (dataDeviceObj.dateEpoch != undefined) {
          labels.push(dataDeviceObj.dateEpoch)
        }
        const deviceParamMap: Map<string, Array<any>> = new Map([]);
        if (dataDeviceObj.dataDeviceViews != undefined && dataDeviceObj.dataDeviceViews.length > 0) {
          let j = 0;
          dataDeviceObj.dataDeviceViews.forEach((val: any, key: any) => {
            if (deviceParamMap.get(val.actualName)) {
              deviceParamMap.get(val.actualName)?.push(val);
            } else {
              const parmObjectList: Array<any> = [];
              parmObjectList.push(val);
              deviceParamMap.set(val.actualName, parmObjectList);
            }
            markers.push({
              type: "line",
              range: [dataDeviceObj.dataDeviceViews[j].max],
              lineColor: this.colorList[j],
              lineWidth: 2,
              "visible": false,
              label: { //define label within marker
                text: dataDeviceObj.dataDeviceViews[j].actualName + " Maximum Level",
                backgroundColor: "white",
                alpha: 0.7,
                textAlpha: 1,
                offsetX: 360,
                offsetY: -5
              }
            });
            j++;
          })
        }
        this.legends.push({ isSelected: true, className: 'bar-chart-color-', name: this.selectedDeviceType.name });
        let i = 0;
        deviceParamMap.forEach((value: any, key: string) => {
          let values = 0;
          const sum = this.sumOfValues(value, "value");
          values = this.roundTo((sum / value.length) || 0, 2)

          const seriesObject = seriesList.find((e: any) => e.text == key);
          if (seriesList.find((e: any) => e.text == key)) {
            if (values == 0) {
              seriesObject.values.push(null);
            } else {
              seriesObject.values.push(values);
            }
          } else {
            const series: any = {};
            series.text = key;
            if (values == 0) {
              series.values = [null];
            } else {
              series.values = [values];
            }
            series.backgroundColor = this.colorList[i];
            series.lineColor = this.colorList[i];

            series.marker = {
              "background-color": this.colorList[i],
              "border-width": 0,
              "shadow": 0,
              // "border-color": this.colorList[i]
            },
              seriesList.push(series)
            // let isSelected = false;
            // i == 0 ? isSelected = true : isSelected = false;
            i++;
          }
        });
      });
      const diff = this.dataDeviceListData[1].createDate - this.dataDeviceListData[0].createDate;
      seriesList[0].values = this.dataDeviceListData.map(a => Number(a[this.selectedDeviceType.key]));


      this.tempChartData = {
        "type": "area",
        "hideprogresslogo": true,
        scaleY: {
          markers
        },
        gui: {
          contextMenu: {
            empty: true
          }
        },
        "noData": {
          "text": "Currently there is no data in the chart",
          "fontSize": 18,
        },
        "plotarea": {
          "margin": "dynamic 45 60 dynamic",
        },
        "scale-x": {
          "min-value": this.dataDeviceListData[0].createDate * 1000,
          "max-value": this.dataDeviceListData[this.dataDeviceListData.length - 1].createDate * 1000,
          "step": diff * 1000,
          "transform": {
            "type": "date",
            "all": "%D, %d %M<br />%h:%i %A",
            "item": {
              "visible": false
            }
          },
          "label": {
            "visible": false
          },
          "minor-ticks": 0
        },
        "crosshair-x": {
          "line-color": "#efefef",
          "plot-label": {
            "border-radius": "5px",
            "border-width": "1px",
            "border-color": "#f6f7f8",
            "padding": "10px",
            "font-weight": "bold"
          },
          "scale-label": {
            "font-color": "#000",
            "background-color": "#f6f7f8",
            "border-radius": "5px"
          }
        },
        "tooltip": {
          "visible": false
        },
        "plot": {
          "highlight": true,
          "tooltip-text": "%t views: %v<br>%k",
          "shadow": 0,
          "line-width": "2px",
          "marker": {
            "type": "circle",
            "size": 3
          },
          "highlight-state": {
            "line-width": 3
          },
        },
        "series": seriesList
      }
    }
  }

  updateAkita() {
    const id = `${Constants.reportChart}`;
    const chartEntityModel = this.chartQuery.get(id);
    const chartTypeSelector =
      chartEntityModel?.chartTypeSelector ??
      _.find(Constants.chartTypeSelectors, (c: ChartTypeSelector) => c.type === ChartType.LineArea);
    // const chartEntity: ChartEntity = {
    //   id,
    //   chartRawData: this.data.chartRawData,
    //   hasLegend: !!this.data.chartRawData?.legends?.length,
    //   filter: {},
    //   chartTypeSelector,
    // };
    // if (chartEntityModel) {
    //   this.chartService.update(id, chartEntity);
    // } else {
    //   this.chartService.add(chartEntity);
    // }
  }

  sumOfValues(items: any, prop: any) {
    return items.reduce(function (a: any, b: any) {
      let value;
      if (b[prop] == undefined) {
        value = a + Math.trunc(0)
      } else {
        value = a + Math.trunc(b[prop])
      }
      return value;
    }, 0);

  }
  minOfValues(items: any, prop: any) {
    return items.reduce(function (prev: any, curr: any) {
      return prev[prop] < curr[prop] ? prev[prop] : curr[prop];
    });
  }

  maxOfValues(items: any, prop: any) {
    return items.reduce(function (prev: any, curr: any) {
      return prev[prop] > curr[prop] ? prev[prop] : curr[prop];
    });
  }
  roundTo = function (num: number, places: number) {
    const factor = 10 ** places;
    return Math.round(num * factor) / factor;
  };
}
