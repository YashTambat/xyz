import { Component } from '@angular/core';

@Component({
  selector: 'app-setting-add-edit',
  templateUrl: './setting-add-edit.component.html',
})
export class SettingAddEditComponent {

}
