import { SettingModule } from './setting.module';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/auth-guard';
 
import { AppUrlConstant } from 'src/app/constant/app-url'; 
import { SettingAddEditComponent } from './setting-add-edit/setting-add-edit.component';
 

const routes: Routes = [
    { path: '', component: SettingAddEditComponent, canActivate: [AuthGuard] },
    { path: 'add', component: SettingAddEditComponent, canActivate: [AuthGuard] },
    { path: AppUrlConstant.EDIT + '/:id', component: SettingAddEditComponent, canActivate: [AuthGuard] },
    { path: AppUrlConstant.VIEW + '/:id', component: SettingAddEditComponent, canActivate: [AuthGuard] }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class SettingRouting {}