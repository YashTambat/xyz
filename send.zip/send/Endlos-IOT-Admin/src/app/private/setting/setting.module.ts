import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SettingListComponent } from './setting-list/setting-list.component';
import { SettingAddEditComponent } from './setting-add-edit/setting-add-edit.component';
import { SettingViewComponent } from './setting-view/setting-view.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'primeng/api';  
import { SettingRouting } from './setting-routing';



@NgModule({
  declarations: [
    SettingListComponent,
    SettingAddEditComponent,
    SettingViewComponent
  ],
  imports: [
    CommonModule,
    SettingRouting,
    SharedModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class SettingModule { }
