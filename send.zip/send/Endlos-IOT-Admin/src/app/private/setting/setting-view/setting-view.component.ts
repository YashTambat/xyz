import { Component } from '@angular/core';

@Component({
  selector: 'app-setting-view',
  templateUrl: './setting-view.component.html', 
})
export class SettingViewComponent {

}
