import { Component } from '@angular/core';

@Component({
  selector: 'app-setting-list',
  templateUrl: './setting-list.component.html', 
})
export class SettingListComponent {

}
