import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppUrlConstant } from '../constant/app-url';
import { AuthGuard } from '../auth-guard';

const routes: Routes = [
    { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
    { path: AppUrlConstant.DASHBOARD, loadChildren: () => import('src/app/private/dashboard/dashboard.module').then(m => m.DashboardModule), canActivate: [AuthGuard] },
    { path: AppUrlConstant.MY_PROFILE, loadChildren: () => import('src/app/private/my-profile/my-profile.module').then(m => m.MyProfileModule), canActivate: [AuthGuard] },
    { path: AppUrlConstant.USER, loadChildren: () => import('src/app/private/user/user.module').then(m => m.UserModule), canActivate: [AuthGuard] }, 
    { path: AppUrlConstant.GATEWAY, loadChildren: () => import('src/app/private/gateway/gateway.module').then(m => m.GatewayModule), canActivate: [AuthGuard] },
     { path: AppUrlConstant.DEVICE, loadChildren: () => import('src/app/private/device/device.module').then(m => m.DeviceModule), canActivate: [AuthGuard] },
     { path: AppUrlConstant.REPORT, loadChildren: () => import('src/app/private/report/report.module').then(m => m.ReportModule), canActivate: [AuthGuard] },
     { path: AppUrlConstant.ALARM, loadChildren: () => import('src/app/private/alarm/alarm.module').then(m => m.AlarmModule), canActivate: [AuthGuard] },
     { path: AppUrlConstant.LOCATION, loadChildren: () => import('src/app/private/location/location.module').then(m => m.LocationModule), canActivate: [AuthGuard] },
     { path: AppUrlConstant.SETTING, loadChildren: () => import('src/app/private/setting/setting.module').then(m => m.SettingModule), canActivate: [AuthGuard] },
     { path: AppUrlConstant.CLIENTS, loadChildren: () => import('src/app/private/clients/clients.module').then(m => m.ClientsModule), canActivate: [AuthGuard] },
     { path: AppUrlConstant.DEVICE_DATA, loadChildren: () => import('src/app/private/device-data/device-data.module').then(m => m.DeviceDataModule), canActivate: [AuthGuard] },
     { path: AppUrlConstant.DIAGNOSIS, loadChildren: () => import('src/app/private/diagnosis/diagnosis.module').then(m => m.DiagnosisModule), canActivate: [AuthGuard] },
     { path: AppUrlConstant.SCREEN, loadChildren: () => import('src/app/private/screen/screen.module').then(m => m.ScreenModule), canActivate: [AuthGuard] },
     { path: AppUrlConstant.USER_ROLE, loadChildren: () => import('src/app/private/role/role.module').then(m => m.RoleModule), canActivate: [AuthGuard] },
     { path: AppUrlConstant.ALARM_HISTORY, loadChildren: () => import('src/app/private/alarm-history/alarm-history.module').then(m => m.AlarmHistoryModule), canActivate: [AuthGuard] },
    ];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class PrivateRouting {}
