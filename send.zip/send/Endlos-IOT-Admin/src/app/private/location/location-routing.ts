import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/auth-guard';
 import { AppUrlConstant } from 'src/app/constant/app-url';
import { LocationListComponent } from './location-list/location-list.component';
import { LocationAddEditComponent } from './location-add-edit/location-add-edit.component';
import { LocationViewComponent } from './location-view/location-view.component';
 

const routes: Routes = [
    { path: '', component: LocationListComponent, canActivate: [AuthGuard] },
    { path: 'add', component: LocationAddEditComponent, canActivate: [AuthGuard] },
    { path: AppUrlConstant.EDIT + '/:id', component: LocationAddEditComponent, canActivate: [AuthGuard] },
    { path: AppUrlConstant.VIEW + '/:id', component: LocationViewComponent, canActivate: [AuthGuard] }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class LocationRouting {}