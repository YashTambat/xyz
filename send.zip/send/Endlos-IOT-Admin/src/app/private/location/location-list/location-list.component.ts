import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { KeyValue, Pagination } from 'src/app/common/interfaces/entities/entity';
import { ListResponse } from 'src/app/common/interfaces/response';
import { Url } from 'src/app/constant/app-url';
import { PageTitle } from 'src/app/constant/page-title';
import { Line100By50Theme, Line100PercentBy300Theme } from 'src/app/constant/skeleton-theme';
import { SnackBarService } from 'src/app/shared/components/services/snackbar.service';
import { paginationFactory } from 'src/app/shared/entities/pagination';
import { PaginationType } from 'src/app/shared/enums/common-enums';
import { LocationService } from '../location.service';
import { Location } from 'src/app/shared/entities/Location';
import { range } from 'lodash';

@Component({
  selector: 'app-location-list',
  templateUrl: './location-list.component.html',
  providers: [LocationService]
})
export class LocationListComponent implements OnInit {

  pagination!: Pagination;
  locationList: Location[] = [];
  hasData = false;
  breadcrumbs: KeyValue[];
  isListView = false;
  hasAppliedFilter = false;
  searchedData = '';
  placeholderList = range(24);
  cardPlaceholderList = range(9);
  theme = Line100By50Theme;
  cardTheme = Line100PercentBy300Theme;
  displayedColumns: string[] = ['location_id', 'location_name', 'location_client_name', 'location_latitude','location_longitude','location_altitude','location_address', 'action'];
  selectElement = new Location();
  isDeleteDialogBoxOpen = false;

  constructor(
    private locationService: LocationService,
    private router: Router,
    private snackbarService: SnackBarService
  ) {
    this.breadcrumbs = [
      { key: PageTitle.LOCATION, value: '' }
    ];
    const viewTypeData = sessionStorage.getItem('viewType');
    if(viewTypeData) {
      this.isListView = viewTypeData === 'grid' ? false : true;
    }
    this.pagination = paginationFactory(this.isListView ? PaginationType.table : PaginationType.card);
  }

  ngOnInit(): void {
    const data: any = sessionStorage.getItem('locationFilter');
    const filterData = JSON.parse(data);
    if(filterData && (filterData.searchedData)) {
      this.searchedData = filterData.searchedData ? filterData.searchedData : null;
      this.hasAppliedFilter = true;
    }
    this.onSearch();
  }

  onSearch() {
    this.hasData = false;
    const data: any = {};
    if(this.searchedData) {
      data.name = this.searchedData;
    }
    this.locationService.list(this.pagination, data).then((response: ListResponse) => {
      this.locationList = response.list as Location[];
    }).finally(() => {
      this.hasData = true;
    });
  }

  changeView(type: string) {
    this.isListView = type === 'grid' ? false : true;
    this.pagination = paginationFactory(this.isListView ? PaginationType.table : PaginationType.card);
    this.onSearch();
  }

  onSearched(event: any) {
    if(event) {
      this.searchedData = event;
      this.hasAppliedFilter = true;
      this.setFilterStorage();
    }
    else {
      this.onCancel(1);
    }
  }

  setFilterStorage() {
    const data: any = {};
    data.searchedData = this.searchedData;
    sessionStorage.setItem('locationFilter', JSON.stringify(data));
    this.onSearch();
  }

  onCancel(index: number) {
    switch(index) {
      case 1:
        this.searchedData = '';
        break;
      case 2:
        this.searchedData = '';
        this.hasAppliedFilter = false;
        break;
    }
    if(!this.searchedData) {
      this.hasAppliedFilter = false;
    }
    this.setFilterStorage();
  }

  gotoView(locationId: number) {
    this.router.navigate([Url.LOCATION_VIEW + '/' + locationId]);
  }

  gotoEdit(locationId: number) {
    this.router.navigate([Url.LOCATION_EDIT + '/' + locationId]);
  }

  onDelete(locationData: Location) {
    this.selectElement = locationData;
    this.isDeleteDialogBoxOpen = true;
  }

  submitDelete(event: any) {
    if(event) {
      this.locationService.delete(this.selectElement.id).then(() => {
        this.snackbarService.successSnackBar('Location deleted successfully.');
        this.onSearch();
      }).finally(() => {
        this.isDeleteDialogBoxOpen = false;
      });
    }
  }
}
