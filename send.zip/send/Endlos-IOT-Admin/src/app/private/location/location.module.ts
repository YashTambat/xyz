import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LocationAddEditComponent } from './location-add-edit/location-add-edit.component';
import { LocationListComponent } from './location-list/location-list.component';
import { LocationViewComponent } from './location-view/location-view.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LocationRouting } from './location-routing';



@NgModule({
  declarations: [
    LocationAddEditComponent,
    LocationListComponent,
    LocationViewComponent
  ],
  imports: [
    CommonModule,
      LocationRouting,
      SharedModule,
      FormsModule,
      ReactiveFormsModule
  ]
})
export class LocationModule { }
