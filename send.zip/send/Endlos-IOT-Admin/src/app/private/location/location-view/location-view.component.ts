import { KeyValue } from 'src/app/common/interfaces/entities/entity';
import { Component } from '@angular/core';
import { LocationService } from '../location.service'; 
import { ActivatedRoute, Router } from '@angular/router';
 
import { ViewResponse } from 'src/app/common/interfaces/response';
import { Url } from 'src/app/constant/app-url';
import { PageTitle } from 'src/app/constant/page-title';
import { Line100By50Theme } from 'src/app/constant/skeleton-theme';
import { SnackBarService } from 'src/app/shared/components/services/snackbar.service';
import { Location } from 'src/app/shared/entities/Location';
import { range } from 'lodash';

@Component({
  selector: 'app-location-view',
  templateUrl: './location-view.component.html',
  providers: [LocationService] 
})
export class LocationViewComponent {
  locationId!: number;
  locationView = new Location();
  breadcrumbs: KeyValue[];
  url = Url;
  hasData = false;
  isDeleteDialogBoxOpen = false;
  theme = Line100By50Theme;
  placeholderList = range(6);

  constructor(
    private locationService: LocationService,
    private route: ActivatedRoute,
    private router: Router,
    private snackbarService: SnackBarService
  ) {
    this.breadcrumbs = [
      { key: PageTitle.LOCATION, value: this.url.LOCATION },
      { key: PageTitle.DETAILS, value: '' },
    ];
    this.locationId = this.route.snapshot.params['id'];
    this.onLocationView();
  }

  onLocationView() {
    this.hasData = false;
    this.locationService.view(this.locationId).then((response: ViewResponse) => {
      this.locationView = response.view as Location;
    }).finally(() => {
      this.hasData = true;
    });
  }

  onEdit() {
    this.router.navigate([Url.LOCATION_EDIT + '/' + this.locationId]);
  }

  submitDelete(event: any) {
    if(event) {
      this.locationService.delete(this.locationView.id).then(() => {
        this.snackbarService.successSnackBar('Location deleted successfully.');
        this.router.navigate([Url.LOCATION]);
      }).finally(() => {
        this.isDeleteDialogBoxOpen = false;
      });
    }
  }
}
