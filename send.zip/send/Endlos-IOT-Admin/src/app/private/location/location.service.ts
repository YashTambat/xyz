import { ClientService } from './../clients/clients.service';
import { Injectable } from '@angular/core';
import { Pagination } from 'src/app/common/interfaces/entities/entity';
import { ListResponse, ViewResponse } from 'src/app/common/interfaces/response';
import { ApiUrl } from 'src/app/constant/app-url';
import { HttpService } from 'src/app/services/http.service'; 
import { Location } from 'src/app/shared/entities/Location';


@Injectable()
export class LocationService {
  constructor(private httpService: HttpService) {}

  list(pagination: Pagination, data: any): Promise<ListResponse> {
      const params = `start=${pagination.pageIndex * pagination.pageSize}&recordSize=${pagination.pageSize}`;
      return this.httpService.postAuth<ListResponse>(`${ApiUrl.LOCATION_SEARCH}?${params}`, data, true).then((listResponse: ListResponse) => {
          pagination.length = listResponse.records;
          return listResponse;
      });
  }
 

  delete(id: number): Promise<ListResponse> {
      return this.httpService.deleteAuth(`${ApiUrl.LOCATION_DELETE}/${id}`);
  }

  view(locationId: number): Promise<ViewResponse> {
      return this.httpService.getAuth(`${ApiUrl.LOCATION_VIEW}/${locationId}`, true);
  }

  save(locationView: Location): Promise<ViewResponse> {
      return this.httpService.postAuth(`${ApiUrl.LOCATION_SAVE}`, locationView);
  }

  update(locationView: Location): Promise<ViewResponse> {
      return this.httpService.putAuth(`${ApiUrl.LOCATION_UPDATE}`, locationView);
  }

  cityDropDown(id:any): Promise<ListResponse> {
    return this.httpService.getAuth(`${ApiUrl.CITY_DROPDOWN}${id}`);
  }
  
  stateDropDown(id:number): Promise<ListResponse> {
    return this.httpService.getAuth(`${ApiUrl.STATE_DROPDOWN}${id}`);
  }
  clientsDropDown(): Promise<ListResponse> {
    return this.httpService.postAuth(`${ApiUrl.CLIENT_SEARCH}?start=0&recordSize=10`,{}); 
  }
  portDropDown(): Promise<ListResponse> {
      return this.httpService.getAuth(`${ApiUrl.PORT_DROPDOWN}`);
  }
}
