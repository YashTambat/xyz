import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ViewResponse, ListResponse } from 'src/app/common/interfaces/response';
import { Url } from 'src/app/constant/app-url';
import { PageTitle } from 'src/app/constant/page-title';
import { Line100By50Theme } from 'src/app/constant/skeleton-theme';
import Utils from 'src/app/public/utils/utils';
import { SnackBarService } from 'src/app/shared/components/services/snackbar.service';
import { IdName, KeyValue } from 'src/app/common/interfaces/entities/entity'; 
import { LocationService } from '../location.service';
import { range } from 'lodash';
import { Location } from 'src/app/shared/entities/Location';
import { Constant } from 'src/app/constant/constant';
import { Pattern } from 'src/app/constant/pattern';

@Component({
  selector: 'app-location-add-edit',
  templateUrl: './location-add-edit.component.html', 
  providers: [LocationService]
})
export class LocationAddEditComponent implements OnInit {

  breadcrumbs: KeyValue[];
  locationAddEditForm: FormGroup;
  url = Url;
  locationEditId!: number;
  clicked = false;
  locationView = new Location();
  hasData = false;
  theme = Line100By50Theme;
  placeholderList = range(15);
  portList: Location[] = [];
  stateList: Location[] = [];
  cityList: Location[] = [];
  clientList: Location[] = [];
  utils = Utils;

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private locationService: LocationService,
    private snackbarService: SnackBarService
  ) {
    this.locationEditId = this.route.snapshot.params['id'];
    this.breadcrumbs = [
      { key: PageTitle.LOCATION, value: this.url.LOCATION },
      { key: this.locationEditId ? PageTitle.EDIT : PageTitle.ADD , value: '' },
    ];
    this.locationAddEditForm = this.fb.group({
      clientView: [null, Validators.required], 
      name: [null, Validators.compose([Validators.required, Validators.maxLength(Constant.mediumNameLength)])],
      locationId: [null, Validators.compose([Validators.required, Validators.maxLength(Constant.nameLength)])],
      address: [null, Validators.compose([Validators.required, Validators.maxLength(Constant.maxNameLength)])],
      area: [null, Validators.compose([Validators.maxLength(Constant.maxNameLength)])],
      block: [null, Validators.compose([Validators.maxLength(Constant.maxNameLength)])],
      panchayat: [null, Validators.compose([Validators.maxLength(Constant.maxNameLength)])],
      village: [null, Validators.compose([Validators.maxLength(Constant.maxNameLength)])],
      stateView:  [null, Validators.required],
      cityView:  [null, Validators.required],
      pincode: [null, Validators.compose([Validators.required, Validators.pattern(Pattern.onlyNumeric.pattern),Validators.minLength(Constant.minPinCodeLength) ,Validators.maxLength(Constant.maxPinCodeLength)])],
      latitude: [null, Validators.compose([Validators.maxLength(Constant.nameLength)])],
      longitude: [null, Validators.compose([Validators.maxLength(Constant.nameLength)])],
      altitude: [null, Validators.compose([Validators.maxLength(Constant.nameLength)])],


      gid: [null],
      ipadd: [null],
      mqttHost: [null],
      port: [null],
      mac: [null],
      code: [null],
    });
  }

  ngOnInit(): void {
    this.hasData = false;
    if(this.locationEditId) {
      this.locationService.view(this.locationEditId).then((response: ViewResponse) => {
        this.locationView = response.view as Location;
        if(this.locationView.stateView.key){
          this.onStateChange(this.locationView.stateView);
        }
      }).finally(() => {
        this.hasData = true;
      });
    }
    else {
      this.hasData = true;
      this.locationService.clientsDropDown().then((response: ListResponse) => {
        this.clientList = response.list as Location[];
      });
    }
    this.onCountryChange(96);   
    
    
  }

  onSubmit() {
    if(this.locationAddEditForm.invalid) {
      return;
    }
    if(this.locationEditId) {
      this.locationService.update(this.locationView).then((response: ViewResponse) => {
        this.snackbarService.successSnackBar(response.message);
        this.closeAddEditForm();
      });  
    }
    else {
      this.locationService.save(this.locationAddEditForm.value).then((response: ViewResponse) => {
        this.snackbarService.successSnackBar(response.message);
        this.closeAddEditForm();
      });
    }
  }
  onStateChange(view:KeyValue){
    this.locationService.cityDropDown(view.key).then((response: ListResponse) => {
      this.cityList = response.list as Location[];
    });
  }
  onCountryChange(id:number){
    this.locationService.stateDropDown(id).then((response: ListResponse) => {
      this.stateList = response.list as Location[];
    });
  }
  closeAddEditForm() {
    this.router.navigate([Url.LOCATION]);
  }
}
