import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/auth-guard';
import { AppUrlConstant } from 'src/app/constant/app-url';
import { RoleListComponent } from './role-list/role-list.component';
import { RoleAddEditComponent } from './role-add-edit/role-add-edit.component';

const routes: Routes = [
    { path: '', component: RoleListComponent, canActivate: [AuthGuard] },
    { path: 'add', component: RoleAddEditComponent, canActivate: [AuthGuard] },
    { path: AppUrlConstant.EDIT + '/:id', component: RoleAddEditComponent, canActivate: [AuthGuard] }
    //{ path: AppUrlConstant.VIEW + '/:id', component: RoleViewComponent, canActivate: [AuthGuard] }

];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class RoleRouting {}
