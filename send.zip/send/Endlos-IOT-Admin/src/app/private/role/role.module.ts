import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RoleListComponent } from './role-list/role-list.component';
import { RoleAddEditComponent } from './role-add-edit/role-add-edit.component';
import { RoleRouting } from './role-routing';

const COMPONENTS = [
  RoleListComponent,
  RoleAddEditComponent
]

@NgModule({
  declarations: [...COMPONENTS],
  imports: [CommonModule, RoleRouting, SharedModule, FormsModule, ReactiveFormsModule],
  exports: [...COMPONENTS]
})
export class RoleModule { }
