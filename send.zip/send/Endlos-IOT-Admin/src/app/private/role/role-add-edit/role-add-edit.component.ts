import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import * as _ from 'lodash';
import { range } from 'lodash';
import { KeyValue, Pagination } from 'src/app/common/interfaces/entities/entity';
import { Url } from 'src/app/constant/app-url';
import { PageTitle } from 'src/app/constant/page-title';
import { Line100By50Theme } from 'src/app/constant/skeleton-theme';
import { SnackBarService } from 'src/app/shared/components/services/snackbar.service';
import Utils from 'src/app/public/utils/utils'; 
import { ViewResponse } from 'src/app/common/interfaces/response';
import { paginationFactory } from 'src/app/shared/entities/pagination';
import { PaginationType } from 'src/app/shared/enums/common-enums';
import { Constant } from 'src/app/constant/constant';
import { ParameterMapping } from 'src/app/shared/entities/ParameterMapping';
import { MatTableDataSource } from '@angular/material/table';
import { DeviceService } from '../../device/device.service';
import { RoleService } from '../role.service';
import { RoleView } from 'src/app/shared/entities/role-view';
import { RightsView } from 'src/app/shared/entities/rights-view';
import { ModuleView } from 'src/app/shared/entities/module-view';


@Component({
  selector: 'app-role-add-edit',
  templateUrl: './role-add-edit.component.html',
  styleUrls: ['./role-add-edit.component.scss'],
  providers: [DeviceService, RoleService]

})
export class RoleAddEditComponent implements OnInit{
  displayedColumns: string[] = ['parameter_name','registerName','unit','address','function','action'];

  breadcrumbs: KeyValue[];
  roleForm: FormGroup;
  parameterAddEditForm: FormGroup;
  url = Url;
  roleEditId!: number;
  clicked = false;
  roleView = new RoleView();
  hasData = false;
  theme = Line100By50Theme;
  placeholderList = range(15);
  
  utils = Utils;
  pagination!: Pagination;
  hasAddParameter = false;
  parameterMappingList: ParameterMapping[] = [];
  dataSource = new MatTableDataSource<ParameterMapping>();
  parameterMappingDropdownList: ParameterMapping[] = [];
  isDeleteDialogBoxOpen = false;
  selectElement: any;

  roleModel: RoleView = new RoleView();
  addEditForm: string = 'Add';
  saveUpdateBtn: string = 'Save';

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private roleService: RoleService,
    private snackbarService: SnackBarService

  ) {
    this.roleEditId = this.route.snapshot.params['id'];

    this.breadcrumbs = [
      { key: PageTitle.ROLE, value: this.url.USER_ROLE },
      { key: this.roleEditId ? PageTitle.EDIT : PageTitle.ADD , value: '' },
    ];
    this.roleForm = this.fb.group({
      name: [null, Validators.compose([Validators.required, Validators.maxLength(Constant.mediumNameLength)])],
      isAllSelected: [null],
      isSelected: [null]
      //name: new FormControl('', [Validators.required, Validators.maxLength(30), Validators.pattern(/^[a-zA-Z0-9\s]+$/)]),
      
    });
    this.pagination = paginationFactory(true ? PaginationType.table : PaginationType.card);
  }

/*   ngOnInit(): void {
    this.hasData = true;
    if(this.roleEditId) {
      this.getDependentData();
    }
    else {
      this.hasData = true;
      this.getDependentData();
    }    
  } */

  ngOnInit(): void { 
    this.hasData = false;
    if(this.roleEditId) {
      this.roleService.view(this.roleEditId).then((response: ViewResponse) => {
        this.roleModel =new RoleView(JSON.parse(JSON.stringify(response.view)));//new RoleView(JSON.parse(JSON.stringify(response.view)));
        this.getDependentData();
        //this.cdref.detectChanges();
      });
    }
    else {
      this.hasData = true;
      this.getDependentData();
      
    }    
  }

  

  onSubmit() {
    if (this.roleForm.invalid) {
      return;
    }
    if(this.roleEditId && this.roleModel != undefined) {
      
      
      this.roleModel.id = this.roleEditId;
    //if (this.roleModel != undefined && this.roleModel.id != undefined && this.roleModel.id != 0) {
      let updateRequest = Object.assign({}, this.roleModel);
      updateRequest['roleModuleRightsViews'] = [];
      for (let i = 0; i < this.roleModuleRightsCheckboxView.length; i++) {
        for (let j = 0; j < this.roleModuleRightsCheckboxView[i].roleModuleRights.length; j++) {
          if (this.roleModuleRightsCheckboxView[i].roleModuleRights[j].isSelected) {
            updateRequest['roleModuleRightsViews'].push(this.roleModuleRightsCheckboxView[i].roleModuleRights[j]);
          }
        }
      }
      //this.roleSaveUpdateBtnBlockUI.start();
      this.roleService.updateRole(updateRequest).then((response: ViewResponse) => {
        this.snackbarService.successSnackBar(response.message);
        this.router.navigate([Url.USER_ROLE]);
      }); 
    } else {
      let addRequest: any = {};
      addRequest.name = this.roleModel.name;
      //addRequest.customerRole=this.roleModel.customerRole;
      addRequest['roleModuleRightsViews'] = [];
      for (let i = 0; i < this.roleModuleRightsCheckboxView.length; i++) {
        for (let j = 0; j < this.roleModuleRightsCheckboxView[i].roleModuleRights.length; j++) {
          if (this.roleModuleRightsCheckboxView[i].roleModuleRights[j].isSelected) {
            addRequest['roleModuleRightsViews'].push(this.roleModuleRightsCheckboxView[i].roleModuleRights[j]);
          }
        }
      }
      //this.roleSaveUpdateBtnBlockUI.start();
      this.roleService.saveRole(addRequest).then((response: ViewResponse) => {
        this.snackbarService.successSnackBar(response.message);
        this.closeAddEditForm();
      },
      error => {
        this.snackbarService.errorSnackBar(error)      
      }); 

     /*  
      this.roleService.saveRole(addRequest).subscribe(response => {
        if (response.code >= 1000 && response.code < 2000) {
          this.snackbarService.successSnackBar(response.message)
          this.router.navigate(['/' + this.appUrl.ROLE + '/' + this.appUrl.LIST_OPERATION]);
        } else {
          this.snackbarService.errorSnackBar(response.message)        
        }
        this.roleSaveUpdateBtnBlockUI.stop();
      }, error => {
        this.snackBarService.errorSnackBar(error)        
        this.roleSaveUpdateBtnBlockUI.stop();
      }); */
    }
  }

  inverseSelectionOfRight(roleModuleCheckbox: any) {
    if(roleModuleCheckbox['isDisable'] == false){
      roleModuleCheckbox.isSelected = !roleModuleCheckbox.isSelected;
    }
  }

  closeAddEditForm() {
    this.router.navigate([Url.USER_ROLE]);
  }

  rightslist: RightsView[] = [];
  roleModuleRightsCheckboxView: any[] = [];
  cdref: any;

  selectAllCheckbox(moduleRow: any) {
    moduleRow.selectAllRights = !moduleRow.selectAllRights;
    this.rightslist.forEach(rights => {
      this.roleModuleRightsCheckboxView.forEach(checkBoxView => {
        checkBoxView.roleModuleRights.forEach((roleModuleRightsValue: { isDisable: boolean; moduleView: { id: any; }; rightsView: { id: number; }; isSelected: boolean; }) => {
          if (!roleModuleRightsValue.isDisable) {
            if (moduleRow.moduleId == roleModuleRightsValue.moduleView.id
              && rights.id == roleModuleRightsValue.rightsView.id) {
              if (moduleRow.selectAllRights) {
                roleModuleRightsValue.isSelected = true;
                roleModuleRightsValue.isDisable = false;
              } else {
                roleModuleRightsValue.isSelected = false;
                // roleModuleRightsValue.isDisable = true;
              }
            }    
            //this.cdref.detectChanges();
          }
        });
      });
    });
  }


  moduleList: ModuleView[] = [];
  getDependentData(){
    this.roleService.requestDataFromMultipleSources().subscribe(responseList =>{
      this.moduleList = responseList[0].list;
      this.rightslist = responseList[1].list;
      this.getRoleModuleRights();
      this.getDropdownTypeList();
      // this.cdref.detectChanges();
      this.hasData = true;
    })
  }

  getRoleModuleRights() {
    this.moduleList.forEach(moduleValue => {
      const singleRoleModuleRights: any = {};
      singleRoleModuleRights['selectAllRights'] = false;
      singleRoleModuleRights['moduleName'] = moduleValue.name;
      singleRoleModuleRights['moduleId'] = moduleValue.id;
      let rightsList: any = [];
      this.rightslist.forEach(rightsValue => {
        rightsList.push({
          'rightsView': { id: rightsValue.id },
          'moduleView': { id: moduleValue.id },
          'isSelected': false,
          'isDisable': true
        })
      })
      singleRoleModuleRights['roleModuleRights'] = rightsList;
      this.roleModuleRightsCheckboxView.push(singleRoleModuleRights);
      //this.cdref.detectChanges();
    });
    this.viewRole();
  }
 
  roleTypeList: KeyValue[] = [];
  getDropdownTypeList() {
    this.roleService.getDropdownType().then((response: any) => {
      if (response.code >= 1000 && response.code < 2000) {
        this.roleTypeList.push({
          'key': '',
          'value': 'Select Role Type'
        })
        response.list.forEach((object : KeyValue) => {
          this.roleTypeList.push(object)
        });
       } else 
       {
        this.snackbarService.errorSnackBar(response.message)        
      }
    }, error => {
      this.snackbarService.errorSnackBar(error)        
    })
  }

  /* viewRole() {
    const existingRoleModuleRightView = this.roleModel?.roleModuleRightsViews;
    for (let i = 0; i < this.roleModuleRightsCheckboxView.length; i++) {
      const roleModule = Object.assign({}, this.roleModuleRightsCheckboxView[i]);
      for (let j = 0; j < this.roleModuleRightsCheckboxView[i].roleModuleRights.length; j++) {
        const roleModuleRight = Object.assign({}, this.roleModuleRightsCheckboxView[i].roleModuleRights[j]);
        roleModuleRight.isSelected = false;
        if (existingRoleModuleRightView != undefined && existingRoleModuleRightView.length > 0) {
          for (let k = 0; k < existingRoleModuleRightView.length; k++) {
            if (roleModuleRight.rightsView.id === existingRoleModuleRightView[k].rightsView.id &&
              roleModuleRight.moduleView.id === existingRoleModuleRightView[k].moduleView.id) {
              roleModuleRight.isSelected = true;
            }
          }
        }
        for (let m = 0; m < this.moduleList.length; m++) {
          if (roleModule.moduleId === this.moduleList[m].id) {
            for (let n = 0; n < this.moduleList[m].rightsViews.length; n++) {
              if (roleModuleRight.rightsView.id === this.moduleList[m].rightsViews[n].id) {
                roleModuleRight.isDisable = false;
              }
            }
          }
        }
        this.roleModuleRightsCheckboxView[i].roleModuleRights[j] = roleModuleRight;
      }
    }
    //this.cdref.detectChanges();
  } */

  viewRole() {
    const existingRoleModuleRightView = this.roleModel?.roleModuleRightsViews;
    for (let i = 0; i < this.roleModuleRightsCheckboxView.length; i++) {
      const roleModule = Object.assign({}, this.roleModuleRightsCheckboxView[i]);
      for (let j = 0; j < this.roleModuleRightsCheckboxView[i].roleModuleRights.length; j++) {
        const roleModuleRight = Object.assign({}, this.roleModuleRightsCheckboxView[i].roleModuleRights[j]);
        roleModuleRight.isSelected = false;
        if (existingRoleModuleRightView != undefined && existingRoleModuleRightView.length > 0) {
          for (let k = 0; k < existingRoleModuleRightView.length; k++) {
            
            if (roleModuleRight.rightsView.id === existingRoleModuleRightView[k].rightsView.id &&
              roleModuleRight.moduleView.id === existingRoleModuleRightView[k].moduleView.id) {
              roleModuleRight.isSelected = true;
            }
          }
        }
        for (let m = 0; m < this.moduleList.length; m++) {
          if (roleModule.moduleId === this.moduleList[m].id) {
            for (let n = 0; n < this.moduleList[m].rightsViews.length; n++) {
              if (roleModuleRight.rightsView.id === this.moduleList[m].rightsViews[n].id) {
                roleModuleRight.isDisable = false;
              }
            }
          }
        }
        this.roleModuleRightsCheckboxView[i].roleModuleRights[j] = roleModuleRight;
      }
    }
    //this.cdref.detectChanges();
  }
}
