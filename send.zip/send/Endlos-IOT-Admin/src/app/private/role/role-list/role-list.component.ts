import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { range } from 'lodash';
import { KeyValue, Pagination } from 'src/app/common/interfaces/entities/entity';
import { ListResponse } from 'src/app/common/interfaces/response';
import { Url } from 'src/app/constant/app-url';
import { PageTitle } from 'src/app/constant/page-title';
import { Line100By50Theme, Line100PercentBy300Theme } from 'src/app/constant/skeleton-theme';
import { SnackBarService } from 'src/app/shared/components/services/snackbar.service';
import { paginationFactory } from 'src/app/shared/entities/pagination';
import { PaginationType } from 'src/app/shared/enums/common-enums';
import { RoleService } from '../role.service';
import { RoleView } from 'src/app/shared/entities/role-view';
import { ListContainer } from 'src/app/Interface/list-container';
import { SharedService } from 'src/app/shared/shared.service';
import { Modules } from 'src/app/constant/constant';

@Component({
  selector: 'app-role-list',
  templateUrl: './role-list.component.html',
  styleUrls: ['./role-list.component.scss'],
  providers: [RoleService]

})
export class RoleListComponent {
  pagination!: Pagination;
  roleList: RoleView[] = [];
  hasData = false;
  breadcrumbs: KeyValue[];
  isListView = false;
  hasAppliedFilter = false;
  searchedData = '';
  placeholderList = range(24);
  cardPlaceholderList = range(9);
  theme = Line100By50Theme;
  cardTheme = Line100PercentBy300Theme;
  selectElement = new RoleView();
  isDeleteDialogBoxOpen = false;

  public listContainer: ListContainer = {
    accessRightsJson: this.sharedService.getAccessRights(Modules.Role),
};

  constructor(
    private router: Router,
    private snackbarService: SnackBarService,
    private roleService: RoleService,
    private sharedService: SharedService
  ) {
    this.breadcrumbs = [
      { key: PageTitle.ROLE, value: '' }
    ];
    const viewTypeData = sessionStorage.getItem('viewType');
    if(viewTypeData) {
      this.isListView = viewTypeData === 'grid' ? false : true;
    }
    this.pagination = paginationFactory(this.isListView ? PaginationType.table : PaginationType.card);
  }

  ngOnInit(): void {
    const data: any = sessionStorage.getItem('deviceFilter');
    const filterData = JSON.parse(data);
    if(filterData && (filterData.searchedData)) {
      this.searchedData = filterData.searchedData ? filterData.searchedData : null;
      this.hasAppliedFilter = true;
    }
    this.onSearch();
  }

  onSearch() {
    this.hasData = false;
    const data: any = {};
    if(this.searchedData) {
      data.name = this.searchedData;
    }
    this.roleService.list(this.pagination, data).then((response: ListResponse) => {
      this.roleList = response.list as RoleView[];
    }).finally(() => {
      this.hasData = true;
    });
  }

  changeView(type: string) {
    this.isListView = type === 'grid' ? false : true;
    this.pagination = paginationFactory(this.isListView ? PaginationType.table : PaginationType.card);
    this.onSearch();
  }

  onSearched(event: any) {
    if(event) {
      this.searchedData = event;
      this.hasAppliedFilter = true;
      this.setFilterStorage();
    }
    else {
      this.onCancel(1);
    }
  }

  setFilterStorage() {
    const data: any = {};
    data.searchedData = this.searchedData;
    sessionStorage.setItem('deviceFilter', JSON.stringify(data));
    this.onSearch();
  }

  onCancel(index: number) {
    switch(index) {
      case 1:
        this.searchedData = '';
        break;
      case 2:
        this.searchedData = '';
        this.hasAppliedFilter = false;
        break;
    }
    if(!this.searchedData) {
      this.hasAppliedFilter = false;
    }
    this.setFilterStorage();
  }

  gotoEdit(Id: number) {
    this.router.navigate([Url.ROLE_EDIT + '/' + Id]);
  }

  onDelete(roleData: RoleView) {
    this.selectElement = roleData;
    this.isDeleteDialogBoxOpen = true;
  }

  submitDelete(event: any) {
    if(event) {
      this.roleService.delete(this.selectElement.id).then(() => {
        this.snackbarService.successSnackBar('Role deleted successfully.');
        //this.router.navigate([Url.USER_ROLE]);
        this.onSearch();
      }).finally(() => {
        this.isDeleteDialogBoxOpen = false;
      });
    }
  }

}
