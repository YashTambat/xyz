import { Injectable } from '@angular/core';
import { Observable, forkJoin } from 'rxjs';
import { Pagination } from 'src/app/common/interfaces/entities/entity';
import { ListResponse, ViewResponse} from 'src/app/common/interfaces/response';
import { ApiUrl } from 'src/app/constant/app-url';
import { HttpService } from 'src/app/services/http.service';
import { RoleView } from 'src/app/shared/entities/role-view';

@Injectable()
export class RoleService {
    constructor(private httpService: HttpService) {}

    list(pagination: Pagination, data: any): Promise<ListResponse> {
        const params = `start=${pagination.pageIndex * pagination.pageSize}&recordSize=${pagination.pageSize}`;
        return this.httpService.postAuth<ListResponse>(`${ApiUrl.USER_ROLE_SEARCH}?${params}`, data, true).then((listResponse: ListResponse) => {
            pagination.length = listResponse.records;
            return listResponse;
        });
    }

    userRoleDropdown(): Promise<ListResponse> {
        return this.httpService.getAuth<ListResponse>(`${ApiUrl.DROPDOWN_ROLE}`, true).then((listResponse: ListResponse) => {
            return listResponse;
        });
    }

    view(roleId: number): Promise<ViewResponse> {
        return this.httpService.getAuth(`${ApiUrl.ROLE_VIEW}/${roleId}`, true);
    }

    public requestDataFromMultipleSources(): Observable<any[]> {
        let responsemodulelist = this.getModuleList();
        let responserightslist = this.getRightsList()
        // Observable.forkJoin (RxJS 5) changes to just forkJoin() in RxJS 6
        return forkJoin([responsemodulelist, responserightslist]);
      }

      getModuleList() {
        return this.httpService.getAuth<ListResponse>(`${ApiUrl.MODULE_ALL}`, true).then((listResponse: ListResponse) => {
            return listResponse;
        });
      }
    
      getRightsList() {
        return this.httpService.getAuth<ListResponse>(`${ApiUrl.RIGHTS_ALL}`, true).then((listResponse: ListResponse) => {
            return listResponse;
        });
      }

      getDropdownType(): Promise<ListResponse> {
        return this.httpService.getAuth<ListResponse>(`${ApiUrl.ROLE_DROPDOWN_TYPE}`, true).then((listResponse: ListResponse) => {
            return listResponse;
        });
    }

    delete(id: number): Promise<ListResponse> {
        return this.httpService.deleteAuth(`${ApiUrl.ROLE_DELETE}/${id}`);
    }

    updateRole(roleView: RoleView): Promise<ViewResponse> {
        return this.httpService.putAuth(`${ApiUrl.ROLE_UPDATE}`, roleView);
    }
    
    saveRole(roleView: RoleView): Promise<ViewResponse> {
        return this.httpService.postAuth(`${ApiUrl.USER_ROLE_SAVE}`, roleView);
    }
    addRole() {
        return this.httpService.getAuth(`${ApiUrl.ROLE_ADD}`, true);
      }
}