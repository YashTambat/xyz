import { Component, Renderer2 } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { HttpService } from 'src/app/services/http.service';
import { ViewResponse } from 'src/app/common/interfaces/response';
import { environment } from 'src/environments/environment';
import { SnackBarService } from 'src/app/shared/components/services/snackbar.service';
import { ConfirmPasswordValidator } from 'src/app/shared/validator/confirm-password.validator';
import { Url } from 'src/app/constant/app-url';
import { Router } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
    selector: 'app-change-password',
    templateUrl: './change-password.component.html',
    styleUrls: ['./change-password.component.scss'],
})
export class ChangePasswordComponent {
    oldHide = true;
    hide = true;
    hideConfirmPass = true;
    changePasswordForm: FormGroup;
    clicked = false;

    constructor(
        private fb: FormBuilder,
        public activeModal: NgbActiveModal,
        private httpService: HttpService,
        private snackbarService: SnackBarService,
        private renderer: Renderer2,
        private router: Router
    ) {
        this.changePasswordForm = this.fb.group(
            {
                oldPassword: new FormControl(null, [Validators.required]),
                password: new FormControl(null, [Validators.required]),
                confirmPassword: new FormControl(null, [Validators.required]),
            },
            {
                validator: ConfirmPasswordValidator('password', 'confirmPassword'),
            }
        );
    }

    onSubmit() {
        if (this.changePasswordForm.invalid) {
            return;
        } else {
            this.clicked = true;
            this.httpService
                .postAuth<ViewResponse>(`${environment.apiUrl}/private/user/change-password`, this.changePasswordForm.value)
                .then((response: ViewResponse) => {
                    this.closeModal();
                    this.snackbarService.successSnackBar(response.message);
                    this.router.navigate([Url.LOGIN]);
                    const themeData: any = localStorage.getItem('theme');
                    localStorage.clear();
                    localStorage.setItem('theme', themeData);
                })
                .finally(() => {
                    this.clicked = false;
                });
        }
    }

    closeModal() {
        this.activeModal.dismiss();
    }
}
