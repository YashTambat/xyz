import { ChangeDetectorRef, Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { range } from 'lodash';
import { ImageCroppedEvent } from 'ngx-image-cropper';
import { KeyValue } from 'src/app/common/interfaces/entities/entity';
import { ListResponse, ViewResponse } from 'src/app/common/interfaces/response';
import { ApiUrl, Url } from 'src/app/constant/app-url';
import { Constant } from 'src/app/constant/constant';
import { PageTitle } from 'src/app/constant/page-title';
import { Pattern } from 'src/app/constant/pattern';
import { Line100By50Theme } from 'src/app/constant/skeleton-theme';
import Utils from 'src/app/public/utils/utils';
import { SnackBarService } from 'src/app/shared/components/services/snackbar.service';
import { User } from 'src/app/shared/entities/User';
import { Client } from 'src/app/shared/entities/client';
import { ClientService } from '../clients.service';
@Component({
  selector: 'app-clients-add-edit',
  templateUrl: './clients-add-edit.component.html',
  styleUrls: ['./clients-add-edit.component.scss'],
  providers: [ClientService]
})
export class ClientsAddEditComponent {
  // cityList = [
  //   {key: 1, value: 'Ahmedabad'},
  //   {key: 2, value: 'Gandhinagar'},
  //   {key: 3, value: 'Rajkot'}
  // ];
  // stateList = [
  //   {key: 1, value: 'Gujarat'},
  //   {key: 2, value: 'Delhi'},
  //   {key: 3, value: 'Goa'}
  // ];
  // countryList = [
  //   {key: 1, value: 'India'},
  //   {key: 2, value: 'Australia'}
  // ]
  breadcrumbs: KeyValue[];
  url = Url;
  clientAddEditForm: FormGroup;
  hideImageCropArial = true;
  imageBrowseFile = true;
  imageChangedEvent: any;
  croppedImage: string | null | undefined = '';
  imageShowHide = true;
  clicked = false;
  clientEditId!: number;
  clientView = new Client(); 
  stateList: Client[] = [];
  cityList: Client[] = [];
  utils = Utils;
  hasData = false;
  theme = Line100By50Theme;
  placeholderList = range(15);
  fileView!:any;
  apiUrl = ApiUrl;
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private clientService: ClientService,
    private snackbarService: SnackBarService,
    private cdref: ChangeDetectorRef,
  ) {
    this.clientEditId = this.route.snapshot.params['id'];
    this.breadcrumbs = [
      { key: PageTitle.CLIENT, value: this.url.CLIENTS },
      { key: this.clientEditId ? PageTitle.EDIT + ' Client' : PageTitle.ADD + ' Client', value: '' }, 
    ];
    this.clientAddEditForm = this.fb.group({
      name: [null, Validators.compose([Validators.required, Validators.maxLength(Constant.mediumNameLength)])],
      email: [null, Validators.compose([Validators.required, Validators.pattern(Pattern.email.pattern), Validators.maxLength(Constant.mediumNameLength)])],
      mobile: [null, Validators.compose([Validators.required, Validators.pattern(Pattern.onlyNumeric.pattern),Validators.minLength(Constant.minMobileNumberLength) ,Validators.maxLength(Constant.maxMobileNumberLength)])],
      address: [null, Validators.compose([Validators.required, Validators.maxLength(Constant.maxNameLength)])],
      area: [null, Validators.compose([Validators.maxLength(Constant.maxNameLength)])],
      stateView: [null, Validators.required],
      cityView:  [null, Validators.required],
      pincode:[null, Validators.compose([Validators.required, Validators.pattern(Pattern.onlyNumeric.pattern),Validators.minLength(Constant.minPinCodeLength) ,Validators.maxLength(Constant.maxPinCodeLength)])],   
      contactPersonName: [null, Validators.compose([Validators.required, Validators.maxLength(Constant.mediumNameLength)])],
      profileImage: [null]
    });
  }

  imageFileChangeEvent(event: any): void {
    this.imageChangedEvent = event;
    this.imageBrowseFile = false;
  }

  imageCropped(event: ImageCroppedEvent) {
    this.croppedImage = event.base64;
  }
  imageCropperReady() {
    this.imageShowHide = false;
  }

  uploadImage() {
    this.hideImageCropArial = false;
    const imageBlob = this.imageDataURItoBlob(this.croppedImage?.toString().split('data:image/jpeg;base64,')[1]);
    const imageFile = new File([imageBlob], this.imageChangedEvent.target.files[0].name, { type: 'image/jpeg' });
    // this.onUpload(imageFile, 1);
    const formData = new FormData();
    formData.append("file",imageFile)
    this.clientService.uploadImage(formData).then((response: ViewResponse) => {
      this.snackbarService.successSnackBar(response.message);
      this.fileView = response.view;
      this.clientView.logo=this.fileView;
    });
  }

  imageDataURItoBlob(dataURI: any) {
    const byteString = window.atob(dataURI);
    const arrayBuffer = new ArrayBuffer(byteString.length);
    const int8Array = new Uint8Array(arrayBuffer);
    for (let i = 0; i < byteString.length; i++) {
        int8Array[i] = byteString.charCodeAt(i);
    }
    const blob = new Blob([int8Array], { type: 'image/jpeg' });
    return blob;
  }

  openImageCropper() {
    this.imageBrowseFile = true;
    this.clientAddEditForm.controls['profileImage'].setValue(null);
    delete this.imageChangedEvent;
    this.imageShowHide = true;
    this.hideImageCropArial = true;
    // let defaultData!: any;
    // this.articleView.thumbnailImageView = defaultData;
  }


  ngOnInit(): void { 
    this.hasData = false;
    if(this.clientEditId) {
      this.clientService.view(this.clientEditId).then((response: ViewResponse) => {
        this.clientView = response.view as Client;
        if(!this.clientView?.userView){
          this.clientView.userView = new User();
        }
        this.cdref.detectChanges();
        if(this.clientView.stateView.key){
          this.onStateChange(this.clientView.stateView);
        }
        if (this.clientView.logo) {
          this.hideImageCropArial = false;
          this.croppedImage = this.apiUrl.IMAGE_DOWNLOAD_API + this.clientView.logo.fileId;
        }
      }).finally(() => {
        this.hasData = true;
      });
    }
    else {
      this.clientView.userView = new User();
      this.hasData = true;
    }
    this.onCountryChange(96);   
    
  }
  onSubmit() {
    console.log("call")
    if(this.clientAddEditForm.invalid) {
      return;
    }
    // let clientUserView: any = this.clientAddEditForm.value;
    // clientUserView.userView = {};
    // clientUserView.userView.name = this.clientAddEditForm.controls['userName'].value;
    // clientUserView.userView.email = this.clientAddEditForm.controls['email'].value;
    // clientUserView.userView.mobile = this.clientAddEditForm.controls['mobile'].value;
    // clientUserView.userView.address = this.clientAddEditForm.controls['address'].value;
    // clientUserView.userView.landmark = this.clientAddEditForm.controls['area'].value;
    // clientUserView.userView.stateView = this.clientAddEditForm.controls['stateView'].value;
    // clientUserView.userView.cityView = this.clientAddEditForm.controls['cityView'].value;
    // console.log(clientUserView);



    if(this.clientEditId) {
      this.clientService.update(this.clientView).then((response: ViewResponse) => {
        this.snackbarService.successSnackBar(response.message);
        this.closeAddEditForm();
      });  
    }
    else {
      this.clientService.save(this.clientView).then((response: ViewResponse) => {
        this.snackbarService.successSnackBar(response.message);
        this.closeAddEditForm();
      });
    }

  }
  onStateChange(view:KeyValue){
    this.clientService.cityDropDown(view.key).then((response: ListResponse) => {
      this.cityList = response.list as Client[];
    });
  }
  onCountryChange(id:number){
    this.clientService.stateDropDown(id).then((response: ListResponse) => {
      this.stateList = response.list as Client[];
    });
  }
  closeAddEditForm() {
    this.router.navigate([Url.CLIENTS]);
  }
}
