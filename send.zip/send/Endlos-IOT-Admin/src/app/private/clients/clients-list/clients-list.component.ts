import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatBottomSheet } from '@angular/material/bottom-sheet';
import { Router } from '@angular/router';
import { KeyValue, Pagination } from 'src/app/common/interfaces/entities/entity';
import { ApiUrl, Url } from 'src/app/constant/app-url';
import { PageTitle } from 'src/app/constant/page-title';
import Utils from 'src/app/public/utils/utils';
import { ActiveMenuService } from 'src/app/shared/components/services/active-menu.service';
import { ClientService } from '../clients.service';
import { ListResponse } from 'src/app/common/interfaces/response';
import { paginationFactory } from 'src/app/shared/entities/pagination';
import { PaginationType } from 'src/app/shared/enums/common-enums';
import { SnackBarService } from 'src/app/shared/components/services/snackbar.service';
import { Line100By50Theme, Line100PercentBy300Theme } from 'src/app/constant/skeleton-theme';
import { range } from 'lodash';
import { Client } from 'src/app/shared/entities/client';
@Component({
  selector: 'app-clients-list',
  templateUrl: './clients-list.component.html', 
  styleUrls: ['./clients-list.component.scss'],
  providers: [ClientService]
})
export class ClientsListComponent implements OnInit{

  pagination!: Pagination;
  clientList: Client[] = [];
  hasData = false;
  theme = Line100By50Theme;
  cardTheme = Line100PercentBy300Theme;
  placeholderList = range(24);
  cardPlaceholderList = range(9);
  breadcrumbs: KeyValue[];
  searchFilterForm: FormGroup;
  hasAppliedFilter = false;
  searchedData = '';
  utils = Utils;
  isDialogBoxOpen = false;
  isDeleteDialogBoxOpen = false;
  displayedColumns: string[] = ['name', 'role', 'email', 'mobile', 'address', 'status', 'action'];
  isListView = false;
  selectElement = new Client();
  imgDownloadUrl = ApiUrl.IMAGE_DOWNLOAD_API;
  
  constructor(
    private activeMenuService: ActiveMenuService,
    private fb: FormBuilder,
    private _bottomSheet: MatBottomSheet,
    private router: Router,
    private clientService: ClientService,
    private snackbarService: SnackBarService
  ) {
    this.activeMenuService.changeActiveMenu(true);
    this.breadcrumbs = [
      { key: PageTitle.CLIENT, value: '' }
    ];
    this.searchFilterForm = this.fb.group({
      status: null,
      state: null,
      city: null,
      role: null,
    });
    const viewTypeData = sessionStorage.getItem('viewType');
    if(viewTypeData) {
      this.isListView = viewTypeData === 'grid' ? false : true;
    }
    this.pagination = paginationFactory(this.isListView ? PaginationType.table : PaginationType.card);
  }

  ngOnInit(): void {
    const data: any = sessionStorage.getItem('userFilter');
    const filterData = JSON.parse(data);
    if(filterData && (filterData.status || filterData.states.length !== 0 || filterData.city || filterData.role || filterData.searchedData)) {
      this.searchedData = filterData.searchedData ? filterData.searchedData : null;
      this.hasAppliedFilter = true;
    }
    this.onSearch();
  }

  onSearch() {
    this.hasData = false;
    this.clientService.list(this.pagination).then((response: ListResponse) => {
      this.clientList = response.list as Client[];
    }).finally(() => {
      this.hasData = true;
    });
  }

  changeView(type: string) {
    this.isListView = type === 'grid' ? false : true;
    this.pagination = paginationFactory(this.isListView ? PaginationType.table : PaginationType.card);
    this.onSearch();
  }

  openFilterBox(filterPopup: any) {
    this._bottomSheet.open(filterPopup, {disableClose: true});
  }

  closeFilter() {
    this._bottomSheet.dismiss();
  }

  onSubmit() {
    // if(this.states.length !== 0 || this.status || this.city || this.role || this.searchedData) {
    //   this.hasAppliedFilter = true;
    // }
    this.setFilterStorage();
    this.closeFilter();
  }

  setFilterStorage() {
    const data: any = {};
    data.searchedData = this.searchedData;
    sessionStorage.setItem('userFilter', JSON.stringify(data));
  }

  onSearched(event: any) {
    if(event) {
      this.searchedData = event;
      this.hasAppliedFilter = true;
      this.setFilterStorage();
    }
    else {
      this.onCancel(1);
    }
  }

  onCancel(index: number, state?: any) {
    // const filterStateList: any[] = [];
    // let dummy!: any;
    // switch(index) {
    //   case 1:
    //     this.searchedData = '';
    //     break;
    //   case 2:
    //     this.status = dummy;
    //     break;
    //   case 3:
    //     this.city = dummy;
    //     break;
    //   case 4:
    //     this.states.forEach((element: any, index: number) => {
    //       element.key !== state.key ? filterStateList.push(element) : '';
    //       if(index === this.states.length - 1) {
    //         this.states = filterStateList;
    //         console.log(this.states);
    //       }
    //     });
    //     break;
    //   case 5:
    //     this.role = dummy;
    //     break;
    //   case 6:
    //     this.searchedData = '';
    //     this.status = dummy;
    //     this.states = filterStateList;
    //     this.city = dummy;
    //     this.role = dummy;
    //     this.hasAppliedFilter = false;
    //     break;
    // }
    // if(this.states.length === 0 && !this.status && !this.city && !this.role && !this.searchedData) {
    //   this.hasAppliedFilter = false;
    // }
    // this.setFilterStorage();
  }

  gotoEdit(clientId: number) {
    this.router.navigate([Url.CLIENTS_EDIT + '/' + clientId]);
  }

  gotoView(clientId: number) {
    this.router.navigate([Url.CLIENTS_VIEW + '/' + clientId]);
  }

  onToggleChange(element: Client) {
    this.isDialogBoxOpen = true;
    this.selectElement = element;
  }

  onChangeStatus(event: any) {
    if (event) {
      console.log(event);
      this.clientService.activeInactive(this.selectElement.id).then(() => {
        this.snackbarService.successSnackBar('User status successfully changed.');
        this.onSearch();
      });
    }
  }

  onCloseActiveModal() {
    this.isDialogBoxOpen = false;
    this.onSearch();
  }

  onDelete(client: Client) {
    this.selectElement = client;
    this.isDeleteDialogBoxOpen = true;
  }

  submitDelete(event: any) {
    if(event) {
      this.clientService.deleteClient(this.selectElement.id).then(() => {
        this.snackbarService.successSnackBar('Client deleted successfully.');
        this.onSearch();
      }).finally(() => {
        this.isDeleteDialogBoxOpen = false;
      });
    }
  }
}
