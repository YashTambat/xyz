import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { KeyValue } from 'src/app/common/interfaces/entities/entity';
import { ApiUrl, Url } from 'src/app/constant/app-url';
import { PageTitle } from 'src/app/constant/page-title';
import { ClientService } from '../clients.service';
import { ViewResponse } from 'src/app/common/interfaces/response';
import { Client } from 'src/app/shared/entities/client';
import { Line100By50Theme } from 'src/app/constant/skeleton-theme';
import { range } from 'lodash';

@Component({
  selector: 'app-clients-view',
  templateUrl: './clients-view.component.html',
  providers: [ClientService]
})
export class ClientsViewComponent {
  

  clientId!: number;
  clientView = new Client();
  hasData = false;
  breadcrumbs: KeyValue[];
  url = Url;
  isDeleteDialogBoxOpen = false;
  displayedColumns: string[] = ['title', 'details'];
  imgDownloadUrl = ApiUrl.IMAGE_DOWNLOAD_API;
  userShowList: any[] = []; 
  theme = Line100By50Theme;
  cardPlaceholderList = range(9);
  placeholderList = range(6);

  constructor(private router: Router, private route: ActivatedRoute, private clientService: ClientService) {
    this.breadcrumbs = [
      { key: PageTitle.CLIENT, value: this.url.CLIENTS },
      { key: PageTitle.CLIENT + ' Details', value: '' },
    ];
    this.clientId = this.route.snapshot.params['id'];
    this.onUserView();
  }

  onUserView() {
    this.hasData = false;
    this.clientService.viewUser(this.clientId).then((response: ViewResponse) => {
      this.clientView = response.view as Client;
      const roleList = '';
      this.hasData = true;
      // this.clientView.roleViews.forEach((role, index) => {
      //   if(index !== this.userView.roleViews.length - 1) {
      //     roleList += role.name + ', ';
      //   }
      //   else {
      //     roleList += role.name;
      //     this.userShowList = [
      //       {id: 1, title: 'User Name', value: this.userView.firstName + ' ' + this.userView.lastName, profile: 'assets/images/default-profile-picture.png'},
      //       {id: 2, title: 'Email', value: (this.userView.email ? this.userView.email : 'NA')},
      //       {id: 3, title: 'Country Code', value: '+91'},
      //       {id: 4, title: 'Roles', value: roleList},
      //       {id: 5, title: 'Mobile No.', value: this.userView.mobile ? this.userView.mobile : 'NA'},
      //       {id: 6, title: 'Address', value: this.userView.address ? this.userView.address : 'NA'},
      //       {id: 7, title: 'Pincode', value: this.userView.pinCode ? this.userView.pinCode : 'NA'},
      //       {id: 8, title: 'Status', status: this.userView.active},
      //     ]
      //     this.hasData = true;
      //   }
      // });
    });
  }

 
  onEdit() {
    this.router.navigate([Url.CLIENTS_EDIT + '/' + this.clientId]);
  }

  onDelete() {
    this.isDeleteDialogBoxOpen = true;
  }

  submitDelete(event: any) {
    console.log("status", event);
    this.isDeleteDialogBoxOpen = false;
  }

}
