import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ClientsListComponent } from './clients-list/clients-list.component';
import { ClientsAddEditComponent } from './clients-add-edit/clients-add-edit.component';
import { ClientsViewComponent } from './clients-view/clients-view.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'; 
import { ClientsRouting } from './clients-routing';
import { ImageCropperModule } from 'ngx-image-cropper';
import { SharedModule } from 'src/app/shared/shared.module';

const COMPONENTS = [
  ClientsListComponent,
  ClientsAddEditComponent,
  ClientsViewComponent
]

@NgModule({
  declarations: [...COMPONENTS],
  imports: [
    CommonModule,
    ClientsRouting,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    ImageCropperModule
  ],
  exports: [...COMPONENTS]
})
export class ClientsModule { }
