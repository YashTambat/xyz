import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/auth-guard';
 
import { AppUrlConstant } from 'src/app/constant/app-url'; 
import { ClientsAddEditComponent } from './clients-add-edit/clients-add-edit.component';
import { ClientsListComponent } from './clients-list/clients-list.component';
import { ClientsViewComponent } from './clients-view/clients-view.component';
 

const routes: Routes = [
    { path: '', component: ClientsListComponent, canActivate: [AuthGuard] },
    { path: 'add', component: ClientsAddEditComponent, canActivate: [AuthGuard] },
    { path: AppUrlConstant.EDIT + '/:id', component: ClientsAddEditComponent, canActivate: [AuthGuard] },
    { path: AppUrlConstant.VIEW + '/:id', component: ClientsViewComponent, canActivate: [AuthGuard] }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class ClientsRouting {}