import { Injectable } from '@angular/core';
import { Pagination } from 'src/app/common/interfaces/entities/entity';
import { ListResponse, ViewResponse } from 'src/app/common/interfaces/response';
import { ApiUrl } from 'src/app/constant/app-url';
import { HttpService } from 'src/app/services/http.service';
import { Client } from 'src/app/shared/entities/client';

@Injectable()
export class ClientService {
    constructor(private httpService: HttpService) { }

    list(pagination: Pagination): Promise<ListResponse> {
        const params = `start=${pagination.pageIndex * pagination.pageSize}&recordSize=${pagination.pageSize}`;
        return this.httpService.postAuth<ListResponse>(`${ApiUrl.CLIENT_SEARCH}?${params}`, {}, true).then((listResponse: ListResponse) => {
            pagination.length = listResponse.records;
            return listResponse;
        });
    }
    save(clientView: Client): Promise<ViewResponse> {
        return this.httpService.postAuth(`${ApiUrl.CLIENT_SAVE}`, clientView);
    }

    update(clientView: Client): Promise<ViewResponse> {
        return this.httpService.putAuth(`${ApiUrl.CLIENT_UPDATE}`, clientView);
    }
    activeInactive(id: number): Promise<ListResponse> {
        return this.httpService.putAuth(`${ApiUrl.CLIENT_ACTIVE_INACTIVE}?id=${id}`, {});
    }

    deleteClient(clientId: number): Promise<ListResponse> {
        return this.httpService.deleteAuth(`${ApiUrl.CLIENT_DELETE}/${clientId}`);
    }

    viewUser(clientId: number): Promise<ViewResponse> {
        return this.httpService.getAuth(`${ApiUrl.CLIENT_VIEW}/${clientId}`, true);
    }
    cityDropDown(id: any): Promise<ListResponse> {
        return this.httpService.getAuth(`${ApiUrl.CITY_DROPDOWN}${id}`);
    }

    stateDropDown(id: number): Promise<ListResponse> {
        return this.httpService.getAuth(`${ApiUrl.STATE_DROPDOWN}${id}`);
    }

    view(clientId: number): Promise<ViewResponse> {
        return this.httpService.getAuth(`${ApiUrl.CLIENT_VIEW}/${clientId}`, true);
    }

    uploadImage(clientView: FormData): Promise<ViewResponse> {
        return this.httpService.postAuth(`${ApiUrl.UPLOAD_IMAGE_API}`, clientView);
    }
}
