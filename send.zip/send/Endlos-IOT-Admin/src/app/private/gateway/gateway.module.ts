import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GatewayListComponent } from './gateway-list/gateway-list.component';
import { GatewayRouting } from './gateway-routing';
import { SharedModule } from 'src/app/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { GatewayViewComponent } from './gateway-view/gateway-view.component';
import { GatewayAddEditComponent } from './gateway-add-edit/gateway-add-edit.component';

const COMPONENTS = [
  GatewayListComponent,
  GatewayViewComponent,
  GatewayAddEditComponent
]

@NgModule({
  declarations: [...COMPONENTS],
  imports: [
    CommonModule,
    GatewayRouting,
    SharedModule,
    FormsModule,
    ReactiveFormsModule
  ],
  exports: [...COMPONENTS]
})
export class GatewayModule { }