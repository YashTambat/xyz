import { Injectable } from '@angular/core';
import { Pagination } from 'src/app/common/interfaces/entities/entity';
import { ListResponse, ViewResponse } from 'src/app/common/interfaces/response';
import { ApiUrl } from 'src/app/constant/app-url';
import { HttpService } from 'src/app/services/http.service';
import { Gateway } from 'src/app/shared/entities/Gateway';

@Injectable()
export class GatewayService {
    constructor(private httpService: HttpService) {}

    list(pagination: Pagination, data: any): Promise<ListResponse> {
        const params = `start=${pagination.pageIndex * pagination.pageSize}&recordSize=${pagination.pageSize}`;
        return this.httpService.postAuth<ListResponse>(`${ApiUrl.GATEWAY_SEARCH}?${params}`, data, true).then((listResponse: ListResponse) => {
            pagination.length = listResponse.records;
            return listResponse;
        });
    }

    delete(id: number): Promise<ListResponse> {
        return this.httpService.deleteAuth(`${ApiUrl.GATEWAY_DELETE}/${id}`);
    }

    view(gatewayId: number): Promise<ViewResponse> {
        return this.httpService.getAuth(`${ApiUrl.GATEWAY_VIEW}/${gatewayId}`, true);
    }

    save(gatewayView: Gateway): Promise<ViewResponse> {
        return this.httpService.postAuth(`${ApiUrl.GATEWAY_SAVE}`, gatewayView);
    }

    update(gatewayView: Gateway): Promise<ViewResponse> {
        return this.httpService.putAuth(`${ApiUrl.GATEWAY_UPDATE}`, gatewayView);
    }

    portDropDown(): Promise<ListResponse> {
        return this.httpService.getAuth(`${ApiUrl.PORT_DROPDOWN}`);
    }
}