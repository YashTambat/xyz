import { Component, OnInit } from '@angular/core';
import { range } from 'lodash';
import { KeyValue, Pagination } from 'src/app/common/interfaces/entities/entity';
import { Line100By50Theme, Line100PercentBy300Theme } from 'src/app/constant/skeleton-theme';
import { Gateway } from 'src/app/shared/entities/Gateway';
import { GatewayService } from '../gateway.service';
import { PageTitle } from 'src/app/constant/page-title';
import { paginationFactory } from 'src/app/shared/entities/pagination';
import { PaginationType } from 'src/app/shared/enums/common-enums';
import { ListResponse } from 'src/app/common/interfaces/response';
import { Router } from '@angular/router';
import { Url } from 'src/app/constant/app-url';
import { SnackBarService } from 'src/app/shared/components/services/snackbar.service';

@Component({
  selector: 'app-gateway-list',
  templateUrl: './gateway-list.component.html',
  providers: [GatewayService]
})
export class GatewayListComponent implements OnInit {

  pagination!: Pagination;
  gatewayList: Gateway[] = [];
  hasData = false;
  breadcrumbs: KeyValue[];
  isListView = false;
  hasAppliedFilter = false;
  searchedData = '';
  placeholderList = range(24);
  cardPlaceholderList = range(9);
  theme = Line100By50Theme;
  cardTheme = Line100PercentBy300Theme;
  displayedColumns: string[] = ['id', 'gateway_name', 'mac_address', 'action'];
  selectElement = new Gateway();
  isDeleteDialogBoxOpen = false;

  constructor(
    private gatewayService: GatewayService,
    private router: Router,
    private snackbarService: SnackBarService
  ) {
    this.breadcrumbs = [
      { key: PageTitle.GATEWAY, value: '' }
    ];
    const viewTypeData = sessionStorage.getItem('viewType');
    if(viewTypeData) {
      this.isListView = viewTypeData === 'grid' ? false : true;
    }
    this.pagination = paginationFactory(this.isListView ? PaginationType.table : PaginationType.card);
  }

  ngOnInit(): void {
    const data: any = sessionStorage.getItem('gatewayFilter');
    const filterData = JSON.parse(data);
    if(filterData && (filterData.searchedData)) {
      this.searchedData = filterData.searchedData ? filterData.searchedData : null;
      this.hasAppliedFilter = true;
    }
    this.onSearch();
  }

  onSearch() {
    this.hasData = false;
    const data: any = {};
    if(this.searchedData) {
      data.name = this.searchedData;
    }
    this.gatewayService.list(this.pagination, data).then((response: ListResponse) => {
      this.gatewayList = response.list as Gateway[];
    }).finally(() => {
      this.hasData = true;
    });
  }

  changeView(type: string) {
    this.isListView = type === 'grid' ? false : true;
    this.pagination = paginationFactory(this.isListView ? PaginationType.table : PaginationType.card);
    this.onSearch();
  }

  onSearched(event: any) {
    if(event) {
      this.searchedData = event;
      this.hasAppliedFilter = true;
      this.setFilterStorage();
    }
    else {
      this.onCancel(1);
    }
  }

  setFilterStorage() {
    const data: any = {};
    data.searchedData = this.searchedData;
    sessionStorage.setItem('gatewayFilter', JSON.stringify(data));
    this.onSearch();
  }

  onCancel(index: number) {
    switch(index) {
      case 1:
        this.searchedData = '';
        break;
      case 2:
        this.searchedData = '';
        this.hasAppliedFilter = false;
        break;
    }
    if(!this.searchedData) {
      this.hasAppliedFilter = false;
    }
    this.setFilterStorage();
  }

  gotoView(gatewayId: number) {
    this.router.navigate([Url.GATEWAY_VIEW + '/' + gatewayId]);
  }

  gotoEdit(gatewayId: number) {
    this.router.navigate([Url.GATEWAY_EDIT + '/' + gatewayId]);
  }

  onDelete(gatewayData: Gateway) {
    this.selectElement = gatewayData;
    this.isDeleteDialogBoxOpen = true;
  }

  submitDelete(event: any) {
    if(event) {
      this.gatewayService.delete(this.selectElement.id).then(() => {
        this.snackbarService.successSnackBar('Gateway deleted successfully.');
        this.onSearch();
      }).finally(() => {
        this.isDeleteDialogBoxOpen = false;
      });
    }
  }
}