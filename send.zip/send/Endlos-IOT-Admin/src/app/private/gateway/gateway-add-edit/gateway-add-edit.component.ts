import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { range } from 'lodash';
import { KeyValue, Pagination } from 'src/app/common/interfaces/entities/entity';
import { Url } from 'src/app/constant/app-url';
import { Line100By50Theme } from 'src/app/constant/skeleton-theme';
import { Gateway } from 'src/app/shared/entities/Gateway';
import { GatewayService } from '../gateway.service';
import { SnackBarService } from 'src/app/shared/components/services/snackbar.service';
import { PageTitle } from 'src/app/constant/page-title';
import { ListResponse, ViewResponse } from 'src/app/common/interfaces/response';
import Utils from 'src/app/public/utils/utils';
import { LocationService } from '../../location/location.service';
import { paginationFactory } from 'src/app/shared/entities/pagination';
import { PaginationType } from 'src/app/shared/enums/common-enums';
import { Location } from 'src/app/shared/entities/Location';
import { Constant } from 'src/app/constant/constant';

@Component({
  selector: 'app-gateway-add-edit',
  templateUrl: './gateway-add-edit.component.html',
  providers: [GatewayService,LocationService]
})
export class GatewayAddEditComponent implements OnInit {

  breadcrumbs: KeyValue[];
  gatewayAddEditForm: FormGroup;
  url = Url;
  gatewayEditId!: number;
  clicked = false;
  gatewayView = new Gateway();
  hasData = false;
  theme = Line100By50Theme;
  placeholderList = range(15);
  portList: Gateway[] = [];
  utils = Utils;
  locationList: Location[] = [];
  pagination!: Pagination;

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private gatewayService: GatewayService,
    private snackbarService: SnackBarService,
    private locationService:LocationService
  ) {
    this.gatewayEditId = this.route.snapshot.params['id'];
    this.breadcrumbs = [
      { key: PageTitle.GATEWAY, value: this.url.GATEWAY },
      { key: this.gatewayEditId ? PageTitle.EDIT : PageTitle.ADD , value: '' },
    ];
    this.gatewayAddEditForm = this.fb.group({
      name: [null, Validators.compose([Validators.required, Validators.maxLength(Constant.mediumNameLength)])],
      gatewayId: [null, Validators.compose([Validators.required, Validators.maxLength(Constant.nameLength)])],
      ipAddress: [null, Validators.compose([Validators.maxLength(Constant.nameLength)])],
      macAddress:[null, Validators.compose([Validators.maxLength(Constant.nameLength)])],
      locationView: [null, Validators.required], 
      latitude: [null, Validators.compose([Validators.maxLength(Constant.nameLength)])],
      longitude: [null, Validators.compose([Validators.maxLength(Constant.nameLength)])],

      gid: [null],
      ipadd: [null],
      mqttHost: [null],
      port: [null],
      mac: [null],
      code: [null],
    });
    this.pagination = paginationFactory(false ? PaginationType.table : PaginationType.card);
  
  }

  ngOnInit(): void {
    this.hasData = false;
    if(this.gatewayEditId) {
      this.gatewayService.view(this.gatewayEditId).then((response: ViewResponse) => {
        this.gatewayView = response.view as Gateway;
        console.log("gatewayView",this.gatewayView);
        
      }).finally(() => {
        this.hasData = true;
      });
    }
    else {
      this.hasData = true;
    }
    // this.gatewayService.portDropDown().then((response: ListResponse) => {
    //   this.portList = response.list as Gateway[];
    // });
    this.locationService.list(this.pagination, {}).then((response: ListResponse) => {
      this.locationList = response.list as Location[];
    }).finally(() => {
      this.hasData = true;
    });

  }

  onSubmit() {
    if(this.gatewayAddEditForm.invalid) {
      return;
    }
    if(this.gatewayEditId) {
      this.gatewayService.update(this.gatewayView).then((response: ViewResponse) => {
        this.snackbarService.successSnackBar(response.message);
        this.closeAddEditForm();
      });  
    }
    else {
      this.gatewayService.save(this.gatewayAddEditForm.value).then((response: ViewResponse) => {
        this.snackbarService.successSnackBar(response.message);
        this.closeAddEditForm();
      });
    }
  }

  closeAddEditForm() {
    this.router.navigate([Url.GATEWAY]);
  }
}