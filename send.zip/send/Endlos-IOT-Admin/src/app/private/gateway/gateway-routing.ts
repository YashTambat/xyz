import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/auth-guard';
import { GatewayListComponent } from './gateway-list/gateway-list.component';
import { AppUrlConstant } from 'src/app/constant/app-url';
import { GatewayViewComponent } from './gateway-view/gateway-view.component';
import { GatewayAddEditComponent } from './gateway-add-edit/gateway-add-edit.component';

const routes: Routes = [
    { path: '', component: GatewayListComponent, canActivate: [AuthGuard] },
    { path: 'add', component: GatewayAddEditComponent, canActivate: [AuthGuard] },
    { path: AppUrlConstant.EDIT + '/:id', component: GatewayAddEditComponent, canActivate: [AuthGuard] },
    { path: AppUrlConstant.VIEW + '/:id', component: GatewayViewComponent, canActivate: [AuthGuard] }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class GatewayRouting {}