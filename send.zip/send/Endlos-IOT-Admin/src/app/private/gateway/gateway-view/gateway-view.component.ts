import { Component } from '@angular/core';
import { range } from 'lodash';
import { KeyValue } from 'src/app/common/interfaces/entities/entity';
import { Url } from 'src/app/constant/app-url';
import { Line100By50Theme } from 'src/app/constant/skeleton-theme';
import { Gateway } from 'src/app/shared/entities/Gateway';
import { GatewayService } from '../gateway.service';
import { ActivatedRoute, Router } from '@angular/router';
import { SnackBarService } from 'src/app/shared/components/services/snackbar.service';
import { PageTitle } from 'src/app/constant/page-title';
import { ViewResponse } from 'src/app/common/interfaces/response';
import { LocationService } from '../../location/location.service';

@Component({
  selector: 'app-gateway-view',
  templateUrl: './gateway-view.component.html',
  providers: [GatewayService,LocationService]
})
export class GatewayViewComponent {
  gatewayId!: number;
  gatewayView = new Gateway();
  breadcrumbs: KeyValue[];
  url = Url;
  hasData = false;
  isDeleteDialogBoxOpen = false;
  theme = Line100By50Theme;
  placeholderList = range(6);

  constructor(
    private gatewayService: GatewayService,
    private route: ActivatedRoute,
    private router: Router,
    private snackbarService: SnackBarService
  ) {
    this.breadcrumbs = [
      { key: PageTitle.GATEWAY, value: this.url.GATEWAY },
      { key: PageTitle.DETAILS, value: '' },
    ];
    this.gatewayId = this.route.snapshot.params['id'];
    this.onGatewayView();
  }

  onGatewayView() {
    this.hasData = false;
    this.gatewayService.view(this.gatewayId).then((response: ViewResponse) => {
      this.gatewayView = response.view as Gateway;
    }).finally(() => {
      this.hasData = true;
    });
  }

  onEdit() {
    this.router.navigate([Url.GATEWAY_EDIT + '/' + this.gatewayId]);
  }

  submitDelete(event: any) {
    if(event) {
      this.gatewayService.delete(this.gatewayView.id).then(() => {
        this.snackbarService.successSnackBar('Gateway deleted successfully.');
        this.router.navigate([Url.GATEWAY]);
      }).finally(() => {
        this.isDeleteDialogBoxOpen = false;
      });
    }
  }
}