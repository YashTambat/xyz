import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/auth-guard'; 
import { AppUrlConstant } from 'src/app/constant/app-url'; 
import { AlarmListComponent } from './alarm-list/alarm-list.component';
import { AlarmViewComponent } from './alarm-view/alarm-view.component';

const routes: Routes = [
    { path: '', component: AlarmListComponent, canActivate: [AuthGuard] },
    // { path: 'add', component: AlarmAddEditComponent, canActivate: [AuthGuard] },
    // { path: AppUrlConstant.EDIT + '/:id', component: AlarmAddEditComponent, canActivate: [AuthGuard] },
    { path: AppUrlConstant.VIEW + '/:id', component: AlarmViewComponent, canActivate: [AuthGuard] }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class AlarmRouting {}