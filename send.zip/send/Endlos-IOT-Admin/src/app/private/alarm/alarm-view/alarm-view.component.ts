import { KeyValue } from 'src/app/common/interfaces/entities/entity';
import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ViewResponse } from 'src/app/common/interfaces/response';
import { Url } from 'src/app/constant/app-url';
import { PageTitle } from 'src/app/constant/page-title';
import { Line100By50Theme } from 'src/app/constant/skeleton-theme';
import { SnackBarService } from 'src/app/shared/components/services/snackbar.service';
import { Alarm } from 'src/app/shared/entities/Alarm';
import { AlarmService } from '../alarm.service';
import { range } from 'lodash';


@Component({
  selector: 'app-alarm-view',
  templateUrl: './alarm-view.component.html',
  providers: [AlarmService] 
})
export class AlarmViewComponent {
  alarmId!: number;
  alarmView = new Alarm();
  breadcrumbs: KeyValue[];
  url = Url;
  hasData = false;
  isDeleteDialogBoxOpen = false;
  theme = Line100By50Theme;
  placeholderList = range(24);

  constructor(
    private alarmService: AlarmService,
    private route: ActivatedRoute,
    private router: Router,
    private snackbarService: SnackBarService
  ) {
    this.breadcrumbs = [
      { key: PageTitle.ALARM, value: this.url.ALARM },
      { key: PageTitle.DETAILS, value: '' },
    ];
    this.alarmId = this.route.snapshot.params['id'];
    this.onAlarmView();
  }

  onAlarmView() {
    this.hasData = false;
    this.alarmService.view(this.alarmId).then((response: ViewResponse) => {
      this.alarmView = response.view as Alarm;
    }).finally(() => {
      this.hasData = true;
    });
  }

  onEdit() {
    // this.router.navigate([Url.ALARM_EDIT + '/' + this.alarmId]);
  }

  submitDelete(event: any) {
    if(event) {
      this.alarmService.delete(this.alarmView.id).then(() => {
        this.snackbarService.successSnackBar('Alarm deleted successfully.');
        this.router.navigate([Url.ALARM]);
      }).finally(() => {
        this.isDeleteDialogBoxOpen = false;
      });
    }
  }
}
