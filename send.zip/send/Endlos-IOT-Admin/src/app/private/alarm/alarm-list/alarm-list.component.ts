import { Component, OnInit } from '@angular/core';
import { range } from 'lodash';
import { KeyValue, Pagination } from 'src/app/common/interfaces/entities/entity';
import { Line100By50Theme, Line100PercentBy300Theme } from 'src/app/constant/skeleton-theme';
import { PageTitle } from 'src/app/constant/page-title';
import { paginationFactory } from 'src/app/shared/entities/pagination';
import { PaginationType } from 'src/app/shared/enums/common-enums';
import { ListResponse } from 'src/app/common/interfaces/response';
import { Router } from '@angular/router';
import { Url } from 'src/app/constant/app-url';
import { SnackBarService } from 'src/app/shared/components/services/snackbar.service';
import { AlarmService } from '../alarm.service';
import { Alarm } from 'src/app/shared/entities/Alarm';
import * as _ from 'lodash';

@Component({
  selector: 'app-alarm-list',
  templateUrl: './alarm-list.component.html',
  providers: [AlarmService]
})
export class AlarmListComponent implements OnInit {

  pagination!: Pagination;
  alarmList: Alarm[] = [];
  hasData = false;
  breadcrumbs: KeyValue[]; 
  hasAppliedFilter = false;
  searchedData = '';
  placeholderList = range(24);
  cardPlaceholderList = range(9);
  theme = Line100By50Theme;
  cardTheme = Line100PercentBy300Theme;
  activeColumns: string[] = ['device_name', 'alaram_type', 'generated_date_and_time', 'message'];
  displayedColumns: string[] = this.activeColumns;
  historicalColumns: string[] = ['device_name', 'alaram_type', 'generated_date_and_time','closed_date_and_time','duration', 'message'];
  selectElement = new Alarm();
  isDeleteDialogBoxOpen = false; 
  navigationButtonList = [
    {id:1,name:'Active Alarm',active:true},
    {id:2,name:'Historical Alarm',active:false}
  ];
  constructor(
    private alarmService: AlarmService,
    private router: Router,
    private snackbarService: SnackBarService
  ) {
    this.breadcrumbs = [
      { key: PageTitle.ALARM, value: '' }
    ];
    this.pagination = paginationFactory(PaginationType.table);
  }

  ngOnInit(): void {
    const data: any = sessionStorage.getItem('alarmFilter');
    const filterData = JSON.parse(data);
    if(filterData && (filterData.searchedData)) {
      this.searchedData = filterData.searchedData ? filterData.searchedData : null;
      this.hasAppliedFilter = true;
    }
    this.onSearch();
  }

  onSearch() {
    this.hasData = false;
    const data: any = {};
    if(this.searchedData) {
      data.name = this.searchedData;
    }
    this.alarmService.list(this.pagination, data).then((response: ListResponse) => {
      this.alarmList = response.list as Alarm[];
    }).finally(() => {
      this.hasData = true;
    });
  }

  changeView(type: string) {
    // this.isListButtonName = type === 'grid' ? false : true;
    // this.pagination = paginationFactory(this.isListButtonName ? PaginationType.table : PaginationType.card);
    this.onSearch();
  }

  onSearched(event: any) {
    if(event) {
      this.searchedData = event;
      this.hasAppliedFilter = true;
      this.setFilterStorage();
    }
    else {
      this.onCancel(1);
    }
  }

  setFilterStorage() {
    const data: any = {};
    data.searchedData = this.searchedData;
    sessionStorage.setItem('alarmFilter', JSON.stringify(data));
    this.onSearch();
  }

  onCancel(index: number) {
    switch(index) {
      case 1:
        this.searchedData = '';
        break;
      case 2:
        this.searchedData = '';
        this.hasAppliedFilter = false;
        break;
    }
    if(!this.searchedData) {
      this.hasAppliedFilter = false;
    }
    this.setFilterStorage();
  }

  gotoView(alarmId: number) {
    this.router.navigate([Url.ALARM_VIEW + '/' + alarmId]);
  }

  gotoEdit(alarmId: number) {
    // this.router.navigate([Url.ALARM_EDIT + '/' + alarmId]);
  }

  onDelete(alarmData: Alarm) {
    this.selectElement = alarmData;
    this.isDeleteDialogBoxOpen = true;
  }

  submitDelete(event: any) {
    if(event) {
      this.alarmService.delete(this.selectElement.id).then(() => {
        this.snackbarService.successSnackBar('Alarm deleted successfully.');
        this.onSearch();
      }).finally(() => {
        this.isDeleteDialogBoxOpen = false;
      });
    }
  }
  changeNavigationButtonClick(data:any){
    if(data[1].active){
      this.displayedColumns = this.historicalColumns;
    }
    if(data[0].active){
      this.displayedColumns = this.activeColumns;
    }
    console.log(this.displayedColumns)
  }
}
