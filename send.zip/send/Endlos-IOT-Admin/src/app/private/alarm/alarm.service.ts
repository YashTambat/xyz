import { Injectable } from '@angular/core';
import { Pagination } from 'src/app/common/interfaces/entities/entity';
import { ListResponse, ViewResponse } from 'src/app/common/interfaces/response';
import { ApiUrl } from 'src/app/constant/app-url';
import { HttpService } from 'src/app/services/http.service';
import { Alarm } from 'src/app/shared/entities/Alarm';

@Injectable()
export class AlarmService {

  constructor(private httpService: HttpService) {}

  list(pagination: Pagination, data: any): Promise<ListResponse> {
      const params = `start=${pagination.pageIndex * pagination.pageSize}&recordSize=${pagination.pageSize}`;
      return this.httpService.postAuth<ListResponse>(`${ApiUrl.ALARM_SEARCH}?${params}`, data, true).then((listResponse: ListResponse) => {
          pagination.length = listResponse.records;
          return listResponse;
      });
  }

  delete(id: number): Promise<ListResponse> {
      return this.httpService.deleteAuth(`${ApiUrl.ALARM_DELETE}?id=${id}`);
  }

  view(alarmId: number): Promise<ViewResponse> {
      return this.httpService.getAuth(`${ApiUrl.ALARM_VIEW}?id=${alarmId}`, true);
  }

  save(alarmView: Alarm): Promise<ViewResponse> {
      return this.httpService.postAuth(`${ApiUrl.ALARM_SAVE}`, alarmView);
  }

  update(alarmView: Alarm): Promise<ViewResponse> {
      return this.httpService.putAuth(`${ApiUrl.ALARM_UPDATE}`, alarmView);
  }

  portDropDown(): Promise<ListResponse> {
      return this.httpService.getAuth(`${ApiUrl.PORT_DROPDOWN}`);
  }
}
