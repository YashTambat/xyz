import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AlarmListComponent } from './alarm-list/alarm-list.component';
import { AlarmViewComponent } from './alarm-view/alarm-view.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AlarmRouting } from './alarm-routing';
import { SharedModule } from 'src/app/shared/shared.module';



@NgModule({
  declarations: [
    AlarmListComponent,
    AlarmViewComponent
  ],
  imports: [
    CommonModule,
    AlarmRouting,
    SharedModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class AlarmModule { }
