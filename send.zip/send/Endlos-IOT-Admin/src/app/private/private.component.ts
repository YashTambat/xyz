import { Component } from '@angular/core';

@Component({
    selector: 'app-private',
    templateUrl: './private.component.html',
})
export class PrivateComponent {}
