import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { range } from 'lodash';
import { Subscription } from 'rxjs';
import { KeyValue, Pagination } from 'src/app/common/interfaces/entities/entity';
import { ViewResponse } from 'src/app/common/interfaces/response';
import { ApiUrl, Url } from 'src/app/constant/app-url';
import { PageTitle } from 'src/app/constant/page-title';
import { Line100PercentBy300Theme } from 'src/app/constant/skeleton-theme';
import { DataServices } from 'src/app/services/data.service';
import { HttpService } from 'src/app/services/http.service';
import { ActiveMenuService } from 'src/app/shared/components/services/active-menu.service';
import { BreadcrumbService } from 'src/app/shared/components/services/breadcrumb.service';
import { paginationFactory } from 'src/app/shared/entities/pagination';
import { PaginationType } from 'src/app/shared/enums/common-enums';

@Component({
  selector: 'app-dashboard-view',
  templateUrl: './dashboard-view.component.html',
})
export class DashboardViewComponent implements OnInit {
  clientData$!: Subscription;

  breadcrumbs: KeyValue[] = [];
  hasData = true;
  cardPlaceholderList = range(9);
  cardTheme = Line100PercentBy300Theme;
  dashboardViewChartFilterForm: FormGroup;
  url = Url;
  dashboardViewId:number;
  dashboardView: any;
  pagination: Pagination;
  selectedLocation: any;

  constructor(
    private breadcrumbService: BreadcrumbService,
    private activeMenuService: ActiveMenuService,
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private httpService: HttpService,
    private dataServices: DataServices

  ) {
    this.dashboardViewId = parseInt(this.route.snapshot.params['id']);
    this.activeMenuService.changeActiveMenu(true);
    this.dashboardViewChartFilterForm = this.fb.group(
      { dateFilter: new FormControl(null), }
    );
    this.pagination = paginationFactory(PaginationType.card);

    this.clientData$ = this.dataServices.clientData.subscribe(client => {
      if (client) {
          this.selectedLocation = client;
          this.getDashboardViewData(this.dashboardViewId, this.pagination);
        }
  })
  }

  ngOnInit(): void {
    this.breadcrumbService.changePageTitle(this.breadcrumbs);
    this.breadcrumbs = [
      { key: PageTitle.DASHBOARD, value: this.url.DASHBOARD },
      { key: this.getLocationName(), value: '' },
    ];
  }

  getLocationName() {
    switch (this.dashboardViewId) {
      case 1:
        return 'Flow Meter'
      case 2:
        return 'Chlorine Sensor'
      case 3:
        return 'Turbidity Sensor'
      case 4:
        return 'Pressure Transmitter'
      case 5:
        return 'Level Sensor'
      default:
        return ''
    }
  }

  getDashboardViewData(id: number, pagination: Pagination) {
    const params = `?locationId=${this.selectedLocation.id}&parameterId=${id}&start=${pagination.pageIndex * pagination.pageSize}&recordSize=${pagination.pageSize}`;
    this.httpService.getAuth(ApiUrl.DASHBOARD_VIEW_API + params).then((response: ViewResponse) => {
      this.dashboardView = response.view;
        switch (this.dashboardViewId) {
          case 1:
            pagination.length = this.dashboardView?.flowMeterViews?.length ?? 0;
            break;
          case 2:
            pagination.length = this.dashboardView?.chlorineSensorViews?.length ?? 0;
            break;
          case 3:
            pagination.length = this.dashboardView?.turbiditySensorViews?.length ?? 0;
            break;
          case 4:
            pagination.length = this.dashboardView?.pressureTransmitterViews?.length ?? 0;
            break;
          case 5:
            pagination.length = this.dashboardView?.levelSensorViews?.length ?? 0;
            break;
          default:
            pagination.length = 0;
            break;
        }
    });
  }
  onSearch() { }

  ngOnDestroy(): void {
    this.clientData$.unsubscribe();
}
}
