import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/shared/shared.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DashboardRouting } from './dashboard-routing';
import { DashboardViewComponent } from './dashboard-view/dashboard-view.component';
import { ZingChartModule } from 'src/app/shared/components/zing-chart/zing-chart.module';
import { GoogleMapsModule } from '@angular/google-maps';
import { DashboardPressureChartComponent } from './dashboard-chart/dashboard-pressure-chart.component';
import { DashboardLevelChartComponent } from './dashboard-chart/dashboard-level-chart.component';
import { DashboardFlowChartComponent } from './dashboard-chart/dashboard-flow-chart.component';

const COMPONENTS = [
  DashboardComponent,
  DashboardViewComponent,
  DashboardPressureChartComponent,
  DashboardLevelChartComponent,
  DashboardFlowChartComponent
]

@NgModule({
  declarations: [...COMPONENTS],
  imports: [
    CommonModule,
    DashboardRouting,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    ZingChartModule,
    GoogleMapsModule
    ],
  exports: [...COMPONENTS]
})
export class DashboardModule { }