import { Component, Inject, Input, OnInit, SimpleChanges } from '@angular/core';
import { Observable } from 'rxjs';
import * as _ from 'lodash';
import { ChartQuery, ChartService, ChartEntity } from 'src/app/shared/components/zing-chart/akita/chart';
import { CHART_WRAPPER_SERVICE } from 'src/app/shared/components/zing-chart/chart-services/chart-wrapper-service';
import { Constants } from 'src/app/shared/components/zing-chart/constants';
import { ChartType } from 'src/app/shared/components/zing-chart/enums';
import { ChartTypeSelector } from 'src/app/shared/components/zing-chart/interface';
import { DashboardLevelChartWrapperService } from 'src/app/shared/components/zing-chart/chart-services/dashboard-level-chart-wrapper.service';

@Component({
  selector: 'app-dashboard-level-chart',
  template: `<app-column-chart  [chartId]=id [noDataText]="'No data found'" scaleYLabel="" [minItemsDisplayWOAngle]="12"></app-column-chart>`,
  providers: [{ provide: CHART_WRAPPER_SERVICE, useClass: DashboardLevelChartWrapperService }],
})
export class DashboardLevelChartComponent implements OnInit {
  chartType$: Observable<ChartTypeSelector>;
  chartType = ChartType;
  @Input() selectedArray ;
  @Input() labels:string[]=["Today", "Yesterday"];
  @Input() className:string[] =['#007bff','#6c99ff'];
  @Input() id:string;
  data:any;
  
  constructor(@Inject(CHART_WRAPPER_SERVICE) private chartWrapperService: DashboardLevelChartWrapperService,
    private chartQuery: ChartQuery,
    private chartService: ChartService
  ) { 
    this.data = {
      "id": this.id,
      "chartRawData": {
          "labels": this.labels,
          "series": [],
          "legends": [],
          "classNames": this.className
      },
      "filter": { },
      "chartTypeSelector": { "type": 4, "name": "Stacked Column Chart", "icon": "stacked_bar_chart" },
  }
  }


  ngOnInit(): void {
    this.chartType$ = this.chartQuery.getChartTypeSelectorObservable(this.chartWrapperService.getChartEntityId());
    this.updateAkita()
  }

  ngOnChanges(changes: SimpleChanges): void {
    // Log the value of inputVariable when it changes
    const data = _.cloneDeep(this.data)
    if (this.selectedArray) {
        const series = [];
        _.forEach(this.selectedArray,element => {
          series.push({"values": [parseInt(element.TotalFlow)], "data": [parseInt(element.TotalFlow)]})
        });        
        data.chartRawData.series = series;
        data.chartRawData.labels=this.labels;
        data.chartRawData.classNames=this.className;
        data.id=this.id;
        if(this.labels) data.chartRawData.legends= [
          { "id": 1, "name": this.labels[0], "className": this.className[0], "isSelected": true },
          { "id": 2, "name": this.labels[1], "className": this.className[1], "isSelected": false }
      ]
        this.data = data;
        this.updateAkita();
    }

  }
  updateAkita() { 
    const id = `${Constants.DashboardLevelChart}`;
    const chartEntityModel = this.chartQuery.get(id);
    const chartTypeSelector =
      chartEntityModel?.chartTypeSelector ??
      _.find(Constants.chartTypeSelectors, (c: ChartTypeSelector) => c.type === ChartType.LineArea);
    const chartEntity: ChartEntity = {
      id,
      chartRawData: this.data.chartRawData,
      hasLegend: !!this.data.chartRawData?.legends?.length,
      filter: this.data.filter,
      chartTypeSelector,
    };
    if (chartEntityModel) {
      this.chartService.update(id, chartEntity);
    } else {
      this.chartService.add(chartEntity);
    }
  }
}
