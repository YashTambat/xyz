import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { range } from 'lodash';
import * as moment from 'moment-timezone';
import { KeyValue } from 'src/app/common/interfaces/entities/entity';
import { ViewResponse } from 'src/app/common/interfaces/response';
import { ApiUrl, Url } from 'src/app/constant/app-url';
import { PageTitle } from 'src/app/constant/page-title';
import { Line100By50Theme, Line100PercentBy300Theme } from 'src/app/constant/skeleton-theme';
import { HttpService } from 'src/app/services/http.service';
import { ActiveMenuService } from 'src/app/shared/components/services/active-menu.service';
import { BreadcrumbService } from 'src/app/shared/components/services/breadcrumb.service';
import { DashboardEnum } from '../dashboard-enum';
import { DataServices } from 'src/app/services/data.service';
import { min, Subscription } from 'rxjs';
import { MapInfoWindow, MapMarker } from '@angular/google-maps';
import { ScreenService } from '../../screen/screen.service';
import { Screen } from 'src/app/shared/entities/Screen';
import { SnackBarService } from 'src/app/shared/components/services/snackbar.service';
import { SharedService } from 'src/app/shared/shared.service';
import { ListContainer } from 'src/app/Interface/list-container';
import { Modules } from 'src/app/constant/constant';

@Component({
    selector: 'app-dashboard',
    templateUrl: './dashboard.component.html',
})
export class DashboardComponent implements OnInit {
    breadcrumbs: KeyValue[] = [];
    hasData = true;
    cardPlaceholderList = range(9);
    cardTheme = Line100PercentBy300Theme;
    chartFilterForm: FormGroup;
    moment1:any = moment();
    moment2:any = moment();
    dashboardEnum = DashboardEnum;
    flowActiveFilter = DashboardEnum.DAY;
    PTActiveFilter = DashboardEnum.DAY;
    dashboard: any;
    isMapView = false;
    startDate = this.moment1._d;
    endDate = moment().format('M/D/YYYY');
    PTStartDate = this.moment1._d;
    PTEndDate = moment().format('M/D/YYYY');
    flowSelectedArray:any[] = [{ 'TotaFlow': '0' }, { 'TotaFlow': '0' }];
    pteSelectedArray:any[] = [{ 'TotaFlow': '0' }, { 'TotaFlow': '0' }];
    levelSelectedArray:any[] = [{ 'TotaFlow': '0' }, { 'TotaFlow': '0' }];

    // map view
    clientData$!: Subscription;
    selectedClient: any;
    center: google.maps.LatLngLiteral = { lat: 20.5937, lng: 78.9629 };
    zoom = 2;
    markerOptions: google.maps.MarkerOptions = { draggable: false ,};
    markerPositions: any = [];
    deviceLatLongData: any;
    flowChartLabels: string[];
    ptaChartLabels: string[];
    levelChartLabels=['High','Low'];
    @ViewChild(MapInfoWindow) infoWindow: MapInfoWindow | undefined;
    mapInfoDetails: any;
    refreshInterval: any;

    public listContainer: ListContainer = {
        accessRightsJson: this.sharedService.getAccessRights(Modules.Dashboard),
    };

    theme = Line100By50Theme;
    screenList: any[] = [];
    constructor(
        private breadcrumbService: BreadcrumbService,
        private activeMenuService: ActiveMenuService,
        private fb: FormBuilder,
        private router: Router,
        private httpService: HttpService,
        private dataServices: DataServices,
        private screenService: ScreenService,
        private snackbarService: SnackBarService,
        private sharedService: SharedService
    ) {
        this.activeMenuService.changeActiveMenu(true);
        this.chartFilterForm = this.fb.group({
            startDate: new FormControl(this.moment1._d)
        });
        this.clientData$ = this.dataServices.clientData.subscribe(client => {
            if (client) {
                this.selectedClient = client;
                this.getDeviceLatLong();
                this.getDashboardData();
            }
        })
    }

    ngOnInit(): void {
        this.breadcrumbs = [{ key: PageTitle.DASHBOARD, value: '' }];
        this.breadcrumbService.changePageTitle(this.breadcrumbs);    

        this.onScreenDropDown();
    }

    gotoDashboardView(id:number) {
        this.router.navigate([Url.DASHBOARD_VIEW + '/'+ id])
    }

    onFlowDateChange(date) {
        if (this.flowActiveFilter === this.dashboardEnum.DAY) {
            this.startDate = moment(date);
            this.endDate = moment(date).format('M/D/YYYY');
        }
        this.getDashboardData();
    }
    onPTDateChange(date) {
        if (this.PTActiveFilter === this.dashboardEnum.DAY) {
            this.PTStartDate = moment(date);
            this.PTEndDate = moment(date).format('M/D/YYYY');
        }
        this.getDashboardData();
    }

    onDay(id:number) {
        if (this.flowActiveFilter !== this.dashboardEnum.DAY || this.PTActiveFilter !== this.dashboardEnum.DAY) {
            const moment1:any = moment();
            this.startDate = moment1._d;
        }
        if (id === 1) {
            this.flowActiveFilter = this.dashboardEnum.DAY;
        } else if (id === 4){
            this.PTActiveFilter = this.dashboardEnum.DAY
        }
        this.getDates(id);
        this.getDashboardData();
    }

    onWeek(id: number) {
        if (id === 1) {
            this.flowActiveFilter = this.dashboardEnum.WEEK;
        } else if (id === 4) {
            this.PTActiveFilter = this.dashboardEnum.WEEK
        }
        this.getDates(id);
        this.getDashboardData();
    }

    onMonth(id: number) {
        if (id === 1) {
            this.flowActiveFilter = this.dashboardEnum.MONTH;
        } else if (id === 4) {
            this.PTActiveFilter = this.dashboardEnum.MONTH
        }
        this.getDates(id);
        this.getDashboardData();
    }

    onYear(id: number) {
        if (id === 1) {
            this.flowActiveFilter = this.dashboardEnum.YEAR;
        } else if (id === 4) {
            this.PTActiveFilter = this.dashboardEnum.YEAR;
        }
        this.getDates(id);
        this.getDashboardData();
    }

    onClick() {
        let undefinedNumber!: number;
        this.flowActiveFilter = undefinedNumber;
        this.PTActiveFilter = undefinedNumber;
    }

    getDates(id:number) {
        switch (id === 1 ? this.flowActiveFilter : this.PTActiveFilter) {
            case this.dashboardEnum.DAY:
                const endDate = moment(this.startDate);
                this.setDate(id, moment(this.startDate), moment(endDate).format('M/D/YYYY'));
                break;
            case this.dashboardEnum.WEEK:
                this.setDate(id, moment().startOf('week'), moment().endOf('week').format('M/D/YYYY'));
                break;
            case this.dashboardEnum.MONTH:
                this.setDate(id, moment().startOf('month'), moment().endOf('month').format('M/D/YYYY'));
                break;
            case this.dashboardEnum.YEAR:
                this.setDate(id, moment().startOf('year'), moment().endOf('year').format('M/D/YYYY'));
                break;
        }
    }

    setDate(id:number,startDate,endDate) {
        switch (id) {
            case 1:
                this.startDate = startDate._d;
                this.endDate = moment(endDate).format('M/D/YYYY');
                break;
            case 4:
                this.PTStartDate = startDate._d;
                this.PTEndDate = moment(endDate).format('M/D/YYYY');
                break;

            default:
                break;
        }
    }
    onPrevious() {
        const startDate = this.chartFilterForm.controls['startDate'].value;
        const endDate = this.chartFilterForm.controls['endDate'].value;
        switch(this.flowActiveFilter) {
            case this.dashboardEnum.DAY:
                this.moment1 = moment(startDate).subtract(1, 'days');
                this.moment2 = moment(endDate).subtract(1, 'days');
                this.chartFilterForm.controls['startDate'].setValue(this.moment1._d);
                this.chartFilterForm.controls['endDate'].setValue(this.moment2._d);
                break;
            case this.dashboardEnum.WEEK:
                this.moment1 = moment(startDate).subtract(1, 'week').startOf('week');
                this.moment2 = moment(endDate).subtract(1, 'week').endOf('week');
                this.chartFilterForm.controls['startDate'].setValue(this.moment1._d);
                this.chartFilterForm.controls['endDate'].setValue(this.moment2._d);
                break;
            case this.dashboardEnum.MONTH:
                this.moment1 = moment(startDate).subtract(1, 'month').startOf('month');
                this.moment2 = moment(endDate).subtract(1, 'month').endOf('month');
                this.chartFilterForm.controls['startDate'].setValue(this.moment1._d);
                this.chartFilterForm.controls['endDate'].setValue(this.moment2._d);
                break;
            case this.dashboardEnum.YEAR:
                this.moment1 = moment(startDate).subtract(1, 'year').startOf('year');
                this.moment2 = moment(endDate).subtract(1, 'year').endOf('year');
                this.chartFilterForm.controls['startDate'].setValue(this.moment1._d);
                this.chartFilterForm.controls['endDate'].setValue(this.moment2._d);
                break;
        }
    }

    onNext() {
        const startDate = this.chartFilterForm.controls['startDate'].value;
        const endDate = this.chartFilterForm.controls['endDate'].value;
        switch(this.flowActiveFilter) {
            case this.dashboardEnum.DAY:
                this.moment1 = moment(startDate).add(1, 'days');
                this.moment2 = moment(endDate).add(1, 'days');
                this.chartFilterForm.controls['startDate'].setValue(this.moment1._d);
                this.chartFilterForm.controls['endDate'].setValue(this.moment2._d);
                break;
            case this.dashboardEnum.WEEK:
                this.moment1 = moment(startDate).add(1, 'week').startOf('week');
                this.moment2 = moment(endDate).add(1, 'week').endOf('week');
                this.chartFilterForm.controls['startDate'].setValue(this.moment1._d);
                this.chartFilterForm.controls['endDate'].setValue(this.moment2._d);
                break;
            case this.dashboardEnum.MONTH:
                this.moment1 = moment(startDate).add(1, 'month').startOf('month');
                this.moment2 = moment(endDate).add(1, 'month').endOf('month');
                this.chartFilterForm.controls['startDate'].setValue(this.moment1._d);
                this.chartFilterForm.controls['endDate'].setValue(this.moment2._d);
                break;
            case this.dashboardEnum.YEAR:
                this.moment1 = moment(startDate).add(1, 'year').startOf('year');
                this.moment2 = moment(endDate).add(1, 'year').endOf('year');
                this.chartFilterForm.controls['startDate'].setValue(this.moment1._d);
                this.chartFilterForm.controls['endDate'].setValue(this.moment2._d);
                break;
        }
    }

    onMapView(data:any){
        if(data === 'map'){
            this.isMapView = true;
        }else{
            this.isMapView = false;
        }
    }

    getDashboardData() {
        const data:any = {};
        data.flowMeterView = {
            "isDay": this.flowActiveFilter === this.dashboardEnum.DAY,
            // "startEpoch": 1706725800,
            // "endEpoch": 1706725800,
            "isWeek": this.flowActiveFilter === this.dashboardEnum.WEEK,
            "isMonth": this.flowActiveFilter === this.dashboardEnum.MONTH,
            "isYear": this.flowActiveFilter === this.dashboardEnum.YEAR
        }
        data.pressureTransmitterView ={
            "isDay": this.PTActiveFilter === this.dashboardEnum.DAY,
            // "startEpoch": 1706725800,
            // "endEpoch": 1706725800,
            "isWeek": this.PTActiveFilter === this.dashboardEnum.WEEK,
            "isMonth": this.PTActiveFilter === this.dashboardEnum.MONTH,
            "isYear": this.PTActiveFilter === this.dashboardEnum.YEAR
        }
        if (this.startDate && this.endDate) {
            data.flowMeterView.startEpoch = moment(this.startDate).startOf('day').unix();
            data.flowMeterView.endEpoch = moment(this.endDate).endOf('day').unix();
        }
        if (this.PTStartDate && this.PTEndDate) {
            data.pressureTransmitterView.startEpoch = moment(this.PTStartDate).startOf('day').unix();
            data.pressureTransmitterView.endEpoch = moment(this.PTEndDate).endOf('day').unix();
        }
        data.locationView={id:this.selectedClient.id};
  
        this.httpService.postAuth(`${ApiUrl.DASHBOARD_API}`, data).then((response: ViewResponse) => {
            this.dashboard = response.view;
            this.setChartData();
        })
    }

    setChartData() {
        this.getLabels();
        this.flowSelectedArray= [{ 'TotalFlow': this.dashboard?.totalFlow ?? 0 }, { 'TotalFlow': this.dashboard?.yesterdayFlow ?? 0 }];
        this.pteSelectedArray= [{ 'TotalFlow': this.dashboard?.minPressureTransmitter ?? 0 }, { 'TotalFlow': this.dashboard?.maxPressureTransmitter ?? 0 }];
        this.levelSelectedArray= [{ 'TotalFlow': this.dashboard?.lowLevelTanks ?? 0 }, { 'TotalFlow': this.dashboard?.higLevelTanks ?? 0 }];
    }
    
    getLabels(){
        switch (this.flowActiveFilter) {
            case this.dashboardEnum.DAY: this.flowChartLabels=["Today","Yesterday"];break;
            case this.dashboardEnum.WEEK: this.flowChartLabels=["Current Week","Prev Week"];break;
            case this.dashboardEnum.MONTH: this.flowChartLabels=["Current Month","Prev Month"];break;
            case this.dashboardEnum.YEAR: this.flowChartLabels=["Current Year","Prev Year"];break;
        }  
        switch (this.PTActiveFilter) {
            case this.dashboardEnum.DAY: this.ptaChartLabels=["Today","Yesterday"];break;
            case this.dashboardEnum.WEEK: this.ptaChartLabels=["Current Week","Prev Week"];break;
            case this.dashboardEnum.MONTH: this.ptaChartLabels=["Current Month","Prev Month"];break;
            case this.dashboardEnum.YEAR: this.ptaChartLabels=["Current Year","Prev Year"];break;
        }        
    }
    

    getDeviceLatLong() {
        this.markerPositions = [];
        this.httpService.getAuth(`${ApiUrl.DASHBOARD_Lat_Long_API}?locationId=${this.selectedClient.id}`).then((response: any) => {
            this.deviceLatLongData = response.list;
            if (this.deviceLatLongData.length > 0) {
                this.center = { lat: Number(this.deviceLatLongData[0].latitude), lng: Number(this.deviceLatLongData[0].longitude) };
                this.deviceLatLongData.forEach((data) => {
                    if (data.latitude && data.longitude) {
                        this.zoom=15;
                        const info={latitude:data.latitude, longitude:data.longitude, name:data.name, state:data.stateName, district:data.districtName, block:data.block, panchayat:data.panchayat, village:data.village }
                        const icon='assets/images/Device.png';
                        this.markerPositions.push({ lat: Number(data.latitude), lng: Number(data.longitude), options: {...this.markerOptions,icon},info });
                        data.deviceParameterViewList.forEach((element,i) => {
                            if (element.latitude && element.longitude) {
                                const info={latitude:element.latitude, longitude:element.longitude,name:element.registerName,state:data.stateName, district:data.districtName, block:data.block, panchayat:data.panchayat, village:data.village}
                                let icon='';
                                if(element.parameterMasterView.id==1) { icon= 'assets/images/Map-Flow-Marker.png';}
                                if(element.parameterMasterView.id==2) {icon= 'assets/images/Map-Chlorine-Marker.png';}
                                if(element.parameterMasterView.id==3){ icon= 'assets/images/Map-Turbidity-Marker.png';}
                                if(element.parameterMasterView.id==4){ icon= 'assets/images/Map-Pressure-Marker.png';}
                                if(element.parameterMasterView.id==5){ icon= 'assets/images/Map-Level-Marker.png';} 
                                this.markerPositions.push({ lat: Number(element.latitude), lng: Number(element.longitude), options:{...this.markerOptions,icon},info });
                            }
                        });
                    }
                });
            }
                    });
    }

    openInfoWindow(marker: MapMarker,event) {
        this.mapInfoDetails=event.info
        if (this.infoWindow != undefined) this.infoWindow.open(marker);
    }
    
    ngOnDestroy(): void {
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
        }
        this.clientData$.unsubscribe();
    }

    mapOptions: google.maps.MapOptions = {
        styles: [
            {
              "featureType": "administrative",
              "elementType": "geometry",
              "stylers": [
                {
                  "visibility": "off"
                }
              ]
            },
            {
              "featureType": "poi",
              "stylers": [
                {
                  "visibility": "off"
                }
              ]
            },
            {
              "featureType": "road",
              "elementType": "labels.icon",
              "stylers": [
                {
                  "visibility": "off"
                }
              ]
            },
            {
              "featureType": "transit",
              "stylers": [
                {
                  "visibility": "off"
                }
              ]
            }
          ]
      };
      
      onScreenDropDown() {
        this.screenService.screenDropDown().then((response: any) => {
          this.screenList = response.list as any[];
        });
      }

      screenId:number;
      selectedDevice: any;
      onScreenChange(event: any) {
        this.screenId = event.value;
        this.onScreenView();
        this.refreshInterval = setInterval(() => {
            this.onScreenView();
          }, 10000);        
      }

        screenView = new Screen();
        screenName: string = '';
        titleText: string = '';
        rowNumber: number = 0;
        colNumber: number = 0;
        screenParameters: any;
        columns: string[] = [];
        rows: { name: string, cells: { value: string; readOnly:boolean; id:any; min:any; max:any; unit:any,function:any,zeroButtonText:any,oneButtonText :any,showValueMessage:any }[] }[] = [];

        /* onScreenView() {

            this.hasData = false;
            this.screenService.view(this.screenId).then((response: ViewResponse) => {
            this.screenView = response.view as Screen;
            this.screenName = this.screenView.screenName;
            this.titleText = this.screenView.titleText;
            this.rowNumber = this.screenView.rowNumber;
            this.colNumber = this.screenView.colNumber;

            if (this.screenView.rows && this.screenView.rows.length > 0) {
            // Assuming columns are the same for all rows based on the example
            this.columns = this.screenView.rows[0].columns.map(col => col.column);

            this.rows = this.screenView.rows.map(row => ({
            name: row.row,
            cells: row.columns.map(col => ({ value: col.value }))
            }));
            }
            }).finally(() => {
            this.hasData = true;
            });
        } */

        onScreenView() {
            // this.hasData = false;
            this.screenService.view(this.screenId).then((response: ViewResponse) => {
                this.screenView = response.view as Screen;
                this.screenName = this.screenView.screenName;
                this.titleText = this.screenView.titleText;
                this.rowNumber = this.screenView.rowNumber;
                this.colNumber = this.screenView.colNumber;
        
                if (this.screenView.rows && this.screenView.rows.length > 0) {
                    // Assuming columns are the same for all rows based on the example
                    this.columns = this.screenView.rows[0].columns.map(col => col.column);
        
                    this.rows = this.screenView.rows.map(row => ({
                        name: row.row,
                        cells: row.columns.map(col => ({
                            value: col.value,
                            readOnly: col.readOnly,
                            id: col.id, // Include readOnly property here
                            min:col.min,
                            max:col.max,
                            unit:col.unit,
                            function:col.function,
                            showValueMessage:col.showValueMessage,
                            zeroButtonText :col.zeroButtonText,
                            oneButtonText :col.oneButtonText
                        }))
                    }));
                }
            })
            // .finally(() => {
            //     this.hasData = true;
            // });
        }

        extractValue(value: string): string {
            const match = value.match(/^\d+(\.\d+)?/);
            return match ? match[0] : 'NA';
          }

          paraId:any;
          paravalue:any;

    onEnter(event: any, cell: any) {
        const inputValue = Number(event.target.value);
        if (inputValue < cell.min || inputValue > cell.max) {
            if (inputValue < cell.min) {
                this.snackbarService.errorSnackBar(`Value cannot be less than ${cell.min}`);
            } else if (inputValue > cell.max) {
                this.snackbarService.errorSnackBar(`Value cannot be greater than ${cell.max}`);
            }
        } else {
            let val = event.target.value;
            const match = val.match(/^-?\d+(\.\d+)?$/);
            let finalVal = match ? val : 'NA';
            console.log(finalVal);
            this.screenService.saveRawData(cell.id, finalVal).then((response: any) => {
                this.snackbarService.successSnackBar(response.message);
            });
        }
    }

    toggleValue(val:any, cell: any) {
        console.log(val)
        this.screenService.saveRawData(cell.id, val).then((response: any) => {
            this.snackbarService.successSnackBar(response.message);
        });
    }
}
