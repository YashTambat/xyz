export enum DashboardEnum {
    DAY = 1,
    WEEK = 2,
    MONTH = 3,
    YEAR = 4
}