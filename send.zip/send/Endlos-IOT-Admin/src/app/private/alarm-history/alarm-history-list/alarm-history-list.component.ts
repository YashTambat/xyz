import { Component } from '@angular/core';
import { KeyValue, Pagination } from 'src/app/common/interfaces/entities/entity';
import { PageTitle } from 'src/app/constant/page-title';
import { SnackBarService } from 'src/app/shared/components/services/snackbar.service';
import { paginationFactory } from 'src/app/shared/entities/pagination';
import { PaginationType } from 'src/app/shared/enums/common-enums';
import { AlarmHistoryService } from '../alarm-history.service';
import { Modules } from 'src/app/constant/constant';
import { ListContainer } from 'src/app/Interface/list-container';
import { SharedService } from 'src/app/shared/shared.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import * as moment from 'moment';
import { DeviceDiagnosisService } from '../../diagnosis/device-diagnosis/device-diagnosis.service';
import { DeviceService } from '../../device/device.service';

@Component({
  selector: 'app-alarm-history-list',
  templateUrl: './alarm-history-list.component.html',
  providers: [AlarmHistoryService,DeviceService]
})
export class AlarmHistoryListComponent {
  alarmHistorySearchForm: FormGroup;
  rawDataList: any[] = [];
  hasData = true;
  hasFilter = false;
  listRefreshTimer: any;
  displayedColumns: string[] = [];
  dynamicColumns: string[] = [];
  deviceId: string = '';
  pagination!: Pagination;
  deviceList: any[] = [];
  theme: { [k: string]: any } = { color: 'primary' };
  placeholderList: number[] = Array(10).fill(0);
  deviceParameterList: any[] = [];
  noData = true;
  breadcrumbs: KeyValue[];
  isListView = false;
  refreshInterval: any;
  startEpoch: any;
  endEpoch: any;
  deviceDropdownParameterList: any[] = [];
  moment1: any = moment();
  // selectedDeviceParameters: any[] = []; // or appropriate type

  public listContainer: ListContainer = {
    accessRightsJson: this.sharedService.getAccessRights(Modules.Device),
  };

  constructor(private alarmHistoryService: AlarmHistoryService, private deviceService: DeviceService, private fb: FormBuilder, private sharedService: SharedService, private snackbarService: SnackBarService) {
    this.breadcrumbs = [
      { key: PageTitle.ALARM_HISTORY, value: '' }
    ];
    const viewTypeData = sessionStorage.getItem('viewType');
    if (viewTypeData) {
      this.isListView = viewTypeData === 'grid' ? false : true;
    }
    this.pagination = paginationFactory(this.isListView ? PaginationType.table : PaginationType.card);
    this.alarmHistorySearchForm = this.fb.group({
      device: [null],
    });
  }

  dateRangeForm: FormGroup;

  ngOnInit(): void {
    this.onDeviceDropDown();

    // Initialize form with date and time controls
    this.dateRangeForm = this.fb.group({
      start: [''],  // Start Date
      end: [''],    // End Date
      startTime: ['12:00'], // Default to 12:00 PM (noon)
      endTime: ['23:59']    // Default to 11:59 PM
    });

    this.dateRangeForm.valueChanges.subscribe(dateRange => {
      this.onFlowDateChange(dateRange);
    });
  }

  onSearch(deviceId: string, startDate: String, endDate: String) {
    // console.log(this.selectedDeviceParameters)
    let body: any = {};
    // if (this.selectedDeviceParameters != undefined) {
    //   body.deviceParameterViewList = this.selectedDeviceParameters;
    // }
    // this.hasData = false;

    // this.deviceService.getDataParameterWise(Number(deviceId), body).then((response: any) => {
    //   this.deviceParameterList = response.view.deviceParameterViewList;

    //   this.dynamicColumns = this.deviceParameterList.map((param: any) => param.registerName);
    //   this.displayedColumns = this.dynamicColumns;
    //   this.dynamicColumns.push('date')
    // })
    this.dynamicColumns = ['deviceName', 'registerName', 'address', 'createdate', 'resolvedate'];

    this.alarmHistoryService.getRawData(this.pagination, deviceId, startDate, endDate).then((response: any) => {
      this.rawDataList = response.list.flat();
    })
  }

  getAddressForRegisterName(registerName: string): string {
    const parameter = this.deviceParameterList.find(param => param.registerName === registerName);
    return parameter ? parameter.address : '';
  }

  onSubmit() {
    this.deviceId = this.alarmHistorySearchForm.value.device;
    this.hasFilter = true;

    // Perform the search with combined start and end epoch
    this.onSearch(this.deviceId, this.startEpoch, this.endEpoch);

    this.refreshInterval = setInterval(() => {
      this.onSearch(this.deviceId, this.startEpoch, this.endEpoch);
    }, 10000);
    this.noData = false;
  }

  onCancel() {
    this.alarmHistorySearchForm.reset();
    this.rawDataList = [];
    this.startEpoch = null;
    this.endEpoch = null;
    this.hasData = true;
    this.dateRangeForm.reset();
  }

  ngOnDestroy() {
    if (this.refreshInterval) {
      clearInterval(this.refreshInterval);
    }
  }

  onDeviceDropDown() {
    this.alarmHistoryService.deviceDropDown().then((response: any) => {
      this.deviceList = response.list as any[];
    });
  }


  // onExportToXcel() {
  //   if (!this.deviceId) {
  //     this.snackbarService.errorSnackBar('Please select Device and Generate Diagnosis');
  //   } else {
  //     const filter: any = {
  //       deviceView: {
  //         id: this.deviceId,
  //         deviceParameterViewList: this.selectedDeviceParameters
  //       },
  //       startDate: this.startEpoch,  // Combined Start Date and Time
  //       endDate: this.endEpoch       // Combined End Date and Time
  //     };

  //     this.deviceService.downloadReport(filter).then((response: any) => {
  //       const url = window.URL.createObjectURL(response);

  //       // Create a temporary anchor element
  //       const a = document.createElement('a');
  //       a.href = url;
  //       a.download = `${new Date().getTime()}_Diagnosis.xlsx`; // Set the file name
  //       document.body.appendChild(a);
  //       a.click();

  //       window.URL.revokeObjectURL(url);
  //       document.body.removeChild(a);

  //       this.snackbarService.successSnackBar("Device Diagnosis Report Exported successfully");
  //     });
  //   }
  // }

  onFlowDateChange(dateRange: { start: string, end: string, startTime: string, endTime: string }) {
    // Assuming dateRange is an object that holds your start and end date/time
    const startDate = new Date(dateRange.start);
    const endDate = new Date(dateRange.end);

    // Add the start time and end time to the respective dates
    const [startHour, startMinute] = dateRange.startTime.split(':').map(Number);
    startDate.setHours(startHour, startMinute);

    const [endHour, endMinute] = dateRange.endTime.split(':').map(Number);
    endDate.setHours(endHour, endMinute);

    // Get the epoch time in seconds (dividing by 1000 to convert from milliseconds)
    this.startEpoch = Math.floor(startDate.getTime() / 1000);
    this.endEpoch = Math.floor(endDate.getTime() / 1000);
  }

}
