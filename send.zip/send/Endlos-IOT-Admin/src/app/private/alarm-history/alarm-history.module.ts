import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AlarmHistoryListComponent } from './alarm-history-list/alarm-history-list.component';
import { AlarmHistoryRouting } from './alarm-history-routing';
const COMPONENTS = [
  AlarmHistoryListComponent
]

@NgModule({
  declarations: [...COMPONENTS],
  imports: [CommonModule, AlarmHistoryRouting, SharedModule, FormsModule, ReactiveFormsModule],
  exports: [...COMPONENTS]
})
export class AlarmHistoryModule { }
