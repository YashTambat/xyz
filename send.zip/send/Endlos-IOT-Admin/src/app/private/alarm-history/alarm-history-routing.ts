import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/auth-guard';
import { AlarmHistoryListComponent } from './alarm-history-list/alarm-history-list.component';
const routes: Routes = [
    { path: '', component: AlarmHistoryListComponent, canActivate: [AuthGuard] }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class AlarmHistoryRouting {}
