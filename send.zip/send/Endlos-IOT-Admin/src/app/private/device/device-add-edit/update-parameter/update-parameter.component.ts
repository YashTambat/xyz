import { AfterViewInit, Component, ElementRef, Input, Output, TemplateRef, ViewChild, EventEmitter, Renderer2, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { KeyValue } from 'src/app/common/interfaces/entities/entity';
import { ListResponse, ViewResponse } from 'src/app/common/interfaces/response';
import { Url } from 'src/app/constant/app-url';
import { Pattern } from 'src/app/constant/pattern';
import { DeviceDiagnosisService } from 'src/app/private/diagnosis/device-diagnosis/device-diagnosis.service';
import { HttpService } from 'src/app/services/http.service';
import { SnackBarService } from 'src/app/shared/components/services/snackbar.service';
import { DeviceParameter } from 'src/app/shared/entities/DeviceParameter';
import { ParameterMapping } from 'src/app/shared/entities/ParameterMapping';
import { ConfirmPasswordValidator } from 'src/app/shared/validator/confirm-password.validator';
import { environment } from 'src/environments/environment';
import { DeviceService } from '../../device.service';
import Utils from 'src/app/public/utils/utils';

@Component({
    selector: 'app-update-parameter',
    templateUrl: './update-parameter.component.html',
    providers: [DeviceDiagnosisService]
})
export class UpdateParameterComponent implements OnInit {
    @ViewChild('openSuccessPopup') openSuccessPopup!: TemplateRef<ElementRef>;
    @Input() heading!: string;
    @Input() deviceParameter!: DeviceParameter;
    @Output() dialogBox = new EventEmitter();
    @Output() dialogBoxResponse = new EventEmitter();
    deviceList: any[] = [];
    deviceParameterList: any[] = [];
    selectedDevice: any;
    parameterAddEditForm: FormGroup;
    // parameterMapping = new ParameterMapping();
    parameterMappingDropdownList: ParameterMapping[] = [];
    utils = Utils;
    constructor(public dialog: MatDialog, private deviceDiagnosisService: DeviceDiagnosisService,private deviceService:DeviceService , private fb: FormBuilder      ) {
      this.parameterAddEditForm = this.fb.group({
        parameterMasterView: [null, Validators.required],
        registerName: [null, Validators.required],
        address: [null, Validators.compose([Validators.required, Validators.pattern(Pattern.onlyNumeric.pattern)])],
      });
    }

    getParameterMappingDropdown() {
      const response = this.deviceService.parameterMappingMachineDropdown().then((response: ListResponse) => {
        this.parameterMappingDropdownList = response.list as ParameterMapping[];
      })
    }

    ngAfterViewInit(): void {
        const dialogRef = this.dialog.open(this.openSuccessPopup);
        dialogRef.afterClosed().subscribe(() => {
            this.dialogBox.emit();
        });
    }

    // onSubmit(event: any) {
    //     console.log("In Popup Submit"+event)
    //     var res = "{value:"+this.selectedDevice+", id: "+event+"}";

    //     this.dialogBoxResponse.emit(event);
        
    // }
    ngOnInit(): void {
      this.getParameterMappingDropdown();

      console.log(this.deviceParameter);
      // this.parameterMapping = this.description;
    }
    onSubmit() {
        console.log(this.deviceParameter);
        // var res = "{value:"+this.selectedDevice+", id: "+event+"}";

        // this.dialogBoxResponse.emit(event);
        this.dialogBoxResponse.emit(event);
    }

    onCancel(){
      console.log("dsa")
      this.dialogBox.emit(event);
    }
}
