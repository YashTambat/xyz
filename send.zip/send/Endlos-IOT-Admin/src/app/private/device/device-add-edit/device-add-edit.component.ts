import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import * as _ from 'lodash';
import { range } from 'lodash';
import { KeyValue, Pagination } from 'src/app/common/interfaces/entities/entity';
import { Url } from 'src/app/constant/app-url';
import { PageTitle } from 'src/app/constant/page-title';
import { Line100By50Theme } from 'src/app/constant/skeleton-theme';
import { SnackBarService } from 'src/app/shared/components/services/snackbar.service';
import { DeviceService } from '../device.service';  
import { Device } from 'src/app/shared/entities/Device';
import Utils from 'src/app/public/utils/utils'; 
import { GatewayService } from '../../gateway/gateway.service';
import { ListResponse, ViewResponse } from 'src/app/common/interfaces/response';
import { paginationFactory } from 'src/app/shared/entities/pagination';
import { PaginationType } from 'src/app/shared/enums/common-enums';
import { Constant } from 'src/app/constant/constant';
import { ParameterMapping } from 'src/app/shared/entities/ParameterMapping';
import { MatTableDataSource } from '@angular/material/table';
import { ClientService } from '../../clients/clients.service';
import { LocationService } from '../../location/location.service';
import { Pattern } from 'src/app/constant/pattern';
import { DeviceParameter } from 'src/app/shared/entities/DeviceParameter';

@Component({
  selector: 'app-device-add-edit',
  templateUrl: './device-add-edit.component.html',
  providers: [DeviceService,GatewayService,ClientService,LocationService]
})
export class DeviceAddEditComponent implements OnInit{
  displayedColumns: string[] = ['parameter_name','registerName','address','action'];

  breadcrumbs: KeyValue[];
  deviceAddEditForm: FormGroup;
  parameterAddEditForm: FormGroup;
  url = Url;
  deviceEditId!: number;
  clicked = false;
  deviceView = new Device();
  hasData = false;
  theme = Line100By50Theme;
  placeholderList = range(15);
  
  utils = Utils;
  pagination!: Pagination;
  hasAddParameter = false;
  parameterMappingList: ParameterMapping[] = [];
  dataSource = new MatTableDataSource<ParameterMapping>();
  parameterMappingDropdownList: ParameterMapping[] = [];
  isDeleteDialogBoxOpen = false;
  selectElement: any;
  isDialogBoxOpen: boolean = false;
  deviceParameter = new DeviceParameter();
  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private deviceService: DeviceService,
    private snackbarService: SnackBarService

  ) {
    this.deviceEditId = this.route.snapshot.params['id'];
    this.breadcrumbs = [
      { key: PageTitle.DEVICE, value: this.url.DEVICE },
      { key: this.deviceEditId ? PageTitle.EDIT : PageTitle.ADD , value: '' },
    ];
    this.deviceAddEditForm = this.fb.group({
      name: [null, Validators.compose([Validators.required, Validators.maxLength(Constant.mediumNameLength)])],
      imei:  [null, Validators.compose([Validators.required, Validators.maxLength(Constant.nameLength)])],
      deviceParameterViewList: [null]
    });
    this.pagination = paginationFactory(true ? PaginationType.table : PaginationType.card);
    this.parameterAddEditForm = this.fb.group({
      parameterMasterView: [null, Validators.required],
      registerName: [null, Validators.required],
      address: [null, Validators.compose([Validators.required, Validators.pattern(Pattern.onlyNumeric.pattern)])],
      // min:[null],
      // max:[null]
    });
  }

  ngOnInit(): void {
    this.getParameterMappingDropdown();
    this.hasData = false;
    if(this.deviceEditId) {
      this.deviceService.view(this.deviceEditId).then((response: ViewResponse) => {
        this.deviceView = response.view as Device;
        // if(this.deviceView.stateView.key){
        //   this.onStateChange(this.deviceView.stateView);
        // }
      }).finally(() => {
        this.hasData = true;
      });
      this.onEdit();
    }
    else {
      this.hasData = true;
    }
    // this.onCountryChange(96);
  }


  onEdit() {
    this.hasData = false;
    this.deviceService.view(this.deviceEditId).then((response: ViewResponse) => {
      this.deviceView = response.view as Device;
      if (this.deviceView.deviceParameterViewList && this.deviceView.deviceParameterViewList.length !== 0) {
        this.parameterMappingList = this.deviceView.deviceParameterViewList;
        /* this.parameterMappingDropdownList = _.map(this.parameterMappingDropdownList, l => ({
          ...l,
          disabled: !!_.find(this.parameterMappingList, (d: any) => d?.parameterMasterView?.id === l.id)
        })) */
        this.dataSource.data = this.parameterMappingList;
      }
    }).finally(() => {
      this.hasData = true;
    });
  }
  
  getParameterMappingDropdown() {
    const response = this.deviceService.parameterMappingMachineDropdown().then((response: ListResponse) => {
      this.parameterMappingDropdownList = response.list as ParameterMapping[];
    })
  }

  onParameterSubmit() {
    this.hasAddParameter = false;
    if (this.parameterAddEditForm.invalid) {
      this.hasAddParameter = true;
      this.parameterAddEditForm.markAllAsTouched();
      return;
    }
    this.parameterMappingList.push(this.parameterAddEditForm.value);
    this.dataSource.data = this.parameterMappingList;
    /* this.parameterMappingDropdownList = _.map(this.parameterMappingDropdownList, l => ({
      ...l,
      disabled: !!_.find(this.parameterMappingList, (d: any) => d?.parameterMasterView?.id === l.id)
    })) */
    this.parameterAddEditForm.reset();
  }

  onClear() {
    this.parameterAddEditForm.reset();
    if (this.hasAddParameter) {
      this.parameterAddEditForm.markAllAsTouched();
    }
  }

  onSubmit() {
    if(this.deviceAddEditForm.invalid) {
      return;
    }
    if(this.deviceEditId) {
      this.deviceView.deviceParameterViewList = this.parameterMappingList;

      this.deviceService.update(this.deviceView).then((response: ViewResponse) => {
        this.snackbarService.successSnackBar(response.message);
        this.closeAddEditForm();
      });  
    }
    else {
      this.deviceAddEditForm.controls['deviceParameterViewList'].setValue(this.parameterMappingList);
      this.deviceService.save(this.deviceAddEditForm.value).then((response: ViewResponse) => {
        this.snackbarService.successSnackBar(response.message);
        this.closeAddEditForm();
      });
    }
  }

 /*  onDelete(deviceData: any) {
    this.selectElement = deviceData;
    this.isDeleteDialogBoxOpen = true;
  } */
  onDelete(deviceData: any) {
    const index = this.parameterMappingList.indexOf(deviceData);
    if (index > -1) {
      this.parameterMappingList.splice(index, 1);
      this.dataSource.data = [...this.parameterMappingList];
    }
  }

  submitDelete(event: any) {
    if(event) {
      _.remove(this.parameterMappingList, (parameter: any) => {
        return parameter.parameterMasterView.id === this.selectElement.parameterMasterView.id;
      });
        this.snackbarService.successSnackBar('Device/Parameter  deleted successfully.');
        this.parameterMappingDropdownList = _.map(this.parameterMappingDropdownList, l => ({
          ...l,
          disabled: !!_.find(this.parameterMappingList, (d: any) => d?.parameterMasterView?.id === l.id)
        }))
        this.dataSource.data = this.parameterMappingList;
    }
  }

  onUpdateParameter(deviceData : any){
    this.deviceParameter = deviceData;
    console.log(deviceData)
    this.isDialogBoxOpen = true;
  }

  closeAddEditForm() {
    this.router.navigate([Url.DEVICE]);
  }

  onChangeStatus(response: any) {
    console.log("done")
  }

  onCloseActiveModal() {
    console.log("close")
    this.isDialogBoxOpen = false;
  }
}
