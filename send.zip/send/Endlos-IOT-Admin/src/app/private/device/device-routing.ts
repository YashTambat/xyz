import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/auth-guard';
import { AppUrlConstant } from 'src/app/constant/app-url';
import { DeviceListComponent } from './device-list/device-list.component';
import { DeviceAddEditComponent } from './device-add-edit/device-add-edit.component';
import { DeviceViewComponent } from './device-view/device-view.component';

const routes: Routes = [
    { path: '', component: DeviceListComponent, canActivate: [AuthGuard] },
    { path: 'add', component: DeviceAddEditComponent, canActivate: [AuthGuard] },
    { path: AppUrlConstant.EDIT + '/:id', component: DeviceAddEditComponent, canActivate: [AuthGuard] },
    { path: AppUrlConstant.VIEW + '/:id', component: DeviceViewComponent, canActivate: [AuthGuard] },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class DeviceRouting {}
