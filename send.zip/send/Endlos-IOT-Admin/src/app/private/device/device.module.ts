import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DeviceRouting } from './device-routing';
import { SharedModule } from 'src/app/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DeviceListComponent } from './device-list/device-list.component';
import { DeviceAddEditComponent } from './device-add-edit/device-add-edit.component';
import { DeviceViewComponent } from './device-view/device-view.component';
import { UpdateParameterComponent } from './device-add-edit/update-parameter/update-parameter.component';

const COMPONENTS = [
  DeviceListComponent,
  DeviceAddEditComponent,
  DeviceViewComponent
]

@NgModule({
  declarations: [...COMPONENTS,UpdateParameterComponent],
  imports: [CommonModule, DeviceRouting, SharedModule, FormsModule, ReactiveFormsModule],
  exports: [...COMPONENTS]
})
export class DeviceModule { }
