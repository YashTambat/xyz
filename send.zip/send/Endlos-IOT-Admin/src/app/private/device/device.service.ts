import { Injectable } from '@angular/core';
import { Pagination } from 'src/app/common/interfaces/entities/entity';
import { ListResponse, ViewResponse } from 'src/app/common/interfaces/response';
import { ApiUrl } from 'src/app/constant/app-url';
import { HttpService } from 'src/app/services/http.service';
import { Device } from 'src/app/shared/entities/Device';

@Injectable()
export class DeviceService {
    constructor(private httpService: HttpService) {}

    list(pagination: Pagination, data: any): Promise<ListResponse> {
        const params = `start=${pagination.pageIndex * pagination.pageSize}&recordSize=${pagination.pageSize}`;
        return this.httpService.postAuth<ListResponse>(`${ApiUrl.DEVICE_SEARCH}?${params}`, data, true).then((listResponse: ListResponse) => {
            pagination.length = listResponse.records;
            return listResponse;
        });
    }

    device_type(): Promise<ListResponse> {
        return this.httpService.getAuth(ApiUrl.DEVICE_TYPE);
    }

    delete(id: number): Promise<ListResponse> {
        return this.httpService.deleteAuth(`${ApiUrl.DEVICE_DELETE}/${id}`);
    }

    view(deviceId: number): Promise<ViewResponse> {
        return this.httpService.getAuth(`${ApiUrl.DEVICE_VIEW}/${deviceId}`, true);
    }

    save(deviceView: Device): Promise<ViewResponse> {
        return this.httpService.postAuth(`${ApiUrl.DEVICE_SAVE}`, deviceView);
    }

    update(deviceView: Device): Promise<ViewResponse> {
        return this.httpService.putAuth(`${ApiUrl.DEVICE_UPDATE}`, deviceView);
    }

    portDropDown(): Promise<ListResponse> {
        return this.httpService.getAuth(`${ApiUrl.PORT_DROPDOWN}`);
    }

    gatewayNameDropdown(): Promise<ListResponse> {
        return this.httpService.getAuth(`${ApiUrl.DROPDOWN_GATEWAY_NAME}`);
    }

    parameterMappingMachineDropdown(): Promise<ListResponse> {
        return this.httpService.getAuth(`${ApiUrl.DROPDOWN_PARAMETER_MAPPING}`);
    }

    getRawData(pagination: Pagination, deviceId:string, startDate: String, endDate: String): Promise<ListResponse> {
        const params = `deviceId=${deviceId}&startDate=${startDate}&endDate=${endDate}&start=${pagination.pageIndex * pagination.pageSize}&recordSize=${pagination.pageSize}`;
        return this.httpService.getAuth<ListResponse>(`${ApiUrl.DEVICE_DIAGNOSIS_DATA}?${params}`, true).then((listResponse: ListResponse) => {
            pagination.length = listResponse.records;
            return listResponse;
        });
    }

    downloadReport(filter: any): Promise<any> {
        return this.httpService.postAuthBlob(`${ApiUrl.DEVICE_EXPORT}`, filter);
      }
    
    getDataParameterWise(deviceId: number,data: any){
        return this.httpService.postAuth(`${ApiUrl.DEVICE_PARAMETERID_WISE_LIST}/${deviceId}`,data, true).then((listResponse: ListResponse) => {
            return listResponse;
        });
    }

}