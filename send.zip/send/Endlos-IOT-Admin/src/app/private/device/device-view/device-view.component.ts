import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { range } from 'lodash';
import { KeyValue } from 'src/app/common/interfaces/entities/entity';
import { ViewResponse } from 'src/app/common/interfaces/response';
import { Url } from 'src/app/constant/app-url';
import { PageTitle } from 'src/app/constant/page-title';
import { Line100By50Theme } from 'src/app/constant/skeleton-theme';
import { SnackBarService } from 'src/app/shared/components/services/snackbar.service';
import { Device } from 'src/app/shared/entities/Device';
import { DeviceService } from '../device.service';
import { ListContainer } from 'src/app/Interface/list-container';
import { Modules } from 'src/app/constant/constant';
import { SharedService } from 'src/app/shared/shared.service';

@Component({
  selector: 'app-device-view',
  templateUrl: './device-view.component.html',
  providers: [DeviceService]
})
export class DeviceViewComponent implements OnInit {

  deviceId!: number;
  deviceView = new Device();
  breadcrumbs: KeyValue[];
  url = Url;
  hasData = false;
  isDeleteDialogBoxOpen = false;
  theme = Line100By50Theme;
  placeholderList = range(6);
  displayedColumns: string[] = ['parameter_name', 'registerName', 'unit', 'address','function'];
  public listContainer: ListContainer = {
    accessRightsJson: this.sharedService.getAccessRights(Modules.Device),
  };
  constructor(
    private deviceService: DeviceService,
    private route: ActivatedRoute,
    private router: Router,
    private snackbarService: SnackBarService,
    private sharedService: SharedService
  ) {
    this.breadcrumbs = [
      { key: PageTitle.DEVICE, value: this.url.DEVICE },
      { key: PageTitle.DETAILS, value: '' },
    ];
    this.deviceId = this.route.snapshot.params['id'];
  }
  
  ngOnInit(): void {
    this.onDeviceView();
  }

  onDeviceView() {
    this.hasData = false;
    this.deviceService.view(this.deviceId).then((response: ViewResponse) => {
      this.deviceView = response.view as Device;
    }).finally(() => {
      this.hasData = true;
    });
  }

  onEdit() {
    this.router.navigate([Url.DEVICE_EDIT + '/' + this.deviceId]);
  }

  submitDelete(event: any) {
    if(event) {
      this.deviceService.delete(this.deviceView.id).then(() => {
        this.snackbarService.successSnackBar('Device deleted successfully.');
        this.router.navigate([Url.DEVICE]);
      }).finally(() => {
        this.isDeleteDialogBoxOpen = false;
      });
    }
  }

}
