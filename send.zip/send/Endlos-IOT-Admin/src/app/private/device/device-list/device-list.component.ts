import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { range } from 'lodash';
import { KeyValue, Pagination } from 'src/app/common/interfaces/entities/entity';
import { ListResponse } from 'src/app/common/interfaces/response';
import { Url } from 'src/app/constant/app-url';
import { PageTitle } from 'src/app/constant/page-title';
import { Line100By50Theme, Line100PercentBy300Theme } from 'src/app/constant/skeleton-theme';
import { SnackBarService } from 'src/app/shared/components/services/snackbar.service';
import { Device } from 'src/app/shared/entities/Device';
import { paginationFactory } from 'src/app/shared/entities/pagination';
import { PaginationType } from 'src/app/shared/enums/common-enums';
import { DeviceService } from '../device.service';
import { Modules } from 'src/app/constant/constant';
import { ListContainer } from 'src/app/Interface/list-container';
import { SharedService } from 'src/app/shared/shared.service';

@Component({
  selector: 'app-device-list',
  templateUrl: './device-list.component.html',
  providers: [DeviceService]
})
export class DeviceListComponent {

  pagination!: Pagination;
  deviceList: Device[] = [];
  hasData = false;
  breadcrumbs: KeyValue[];
  isListView = false;
  hasAppliedFilter = true;
  searchedData = '';
  placeholderList = range(24);
  cardPlaceholderList = range(9);
  theme = Line100By50Theme;
  cardTheme = Line100PercentBy300Theme;
  displayedColumns: string[] = ['id', 'device_name', 'machine_name', 'gateway', 'location', 'status', 'action'];
  selectElement = new Device();
  isDeleteDialogBoxOpen = false;
  public listContainer: ListContainer = {
    accessRightsJson: this.sharedService.getAccessRights(Modules.Device),
  };

  constructor(
    private deviceService: DeviceService,
    private router: Router,
    private snackbarService: SnackBarService, 
    private sharedService: SharedService
  ) {
    this.breadcrumbs = [
      { key: PageTitle.DEVICE, value: '' }
    ];
    const viewTypeData = sessionStorage.getItem('viewType');
    if(viewTypeData) {
      this.isListView = viewTypeData === 'grid' ? false : true;
    }
    this.pagination = paginationFactory(this.isListView ? PaginationType.table : PaginationType.card);
  }

  ngOnInit(): void {
    const data: any = sessionStorage.getItem('deviceFilter');
    const filterData = JSON.parse(data);
    if(filterData && (filterData.searchedData)) {
      this.searchedData = filterData.searchedData ? filterData.searchedData : null;
      this.hasAppliedFilter = true;
    }
    this.onSearch();
  }

  onSearch() {
    this.hasData = false;
    const data: any = {};
    if(this.searchedData) {
      data.name = this.searchedData;
    }
    this.deviceService.list(this.pagination, data).then((response: ListResponse) => {
      this.deviceList = response.list as Device[];
    }).finally(() => {
      this.hasData = true;
    });
  }

  changeView(type: string) {
    this.isListView = type === 'grid' ? false : true;
    this.pagination = paginationFactory(this.isListView ? PaginationType.table : PaginationType.card);
    this.onSearch();
  }

  onSearched(event: any) {
    if(event) {
      this.searchedData = event;
      this.hasAppliedFilter = true;
      this.setFilterStorage();
    }
    else {
      this.onCancel(1);
    }
  }

  setFilterStorage() {
    const data: any = {};
    data.searchedData = this.searchedData;
    sessionStorage.setItem('deviceFilter', JSON.stringify(data));
    this.onSearch();
  }

  onCancel(index: number) {
    switch(index) {
      case 1:
        this.searchedData = '';
        break;
      case 2:
        this.searchedData = '';
        this.hasAppliedFilter = false;
        break;
    }
    if(!this.searchedData) {
      this.hasAppliedFilter = false;
    }
    this.setFilterStorage();
  }

  gotoView(Id: number) {
    this.router.navigate([Url.DEVICE_VIEW + '/' + Id]);
  }

  gotoEdit(Id: number) {
    this.router.navigate([Url.DEVICE_EDIT + '/' + Id]);
  }

  onDelete(deviceData: Device) {
    this.selectElement = deviceData;
    this.isDeleteDialogBoxOpen = true;
  }

  submitDelete(event: any) {
    if(event) {
      this.deviceService.delete(this.selectElement.id).then(() => {
        this.snackbarService.successSnackBar('Device deleted successfully.');
        this.onSearch();
      }).finally(() => {
        this.isDeleteDialogBoxOpen = false;
      });
    }
  }

}
