import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/shared/shared.module';
import { DiagnosisRouting } from './diagnosis-routing';


@NgModule({
  imports: [CommonModule, DiagnosisRouting, SharedModule],
  exports: [],
})
export class DiagnosisModule { }