import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/auth-guard';
import { AppUrlConstant } from 'src/app/constant/app-url';

const routes: Routes = [
    { path: '', redirectTo: 'device-diagnosis', pathMatch: 'full' },
    { path: AppUrlConstant.DEVICE_DIAGNOSIS, loadChildren: () => import('src/app/private/diagnosis/device-diagnosis/device-diagnosis.module').then(m => m.DeviceDiagnosisModule), canActivate: [AuthGuard] },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class DiagnosisRouting {}