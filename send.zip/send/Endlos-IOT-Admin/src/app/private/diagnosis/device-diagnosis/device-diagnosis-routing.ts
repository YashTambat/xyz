import { DeviceDiagnosisListComponent } from './device-diagnosis-list/device-diagnosis-list.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/auth-guard';

const routes: Routes = [
    { path: '', component: DeviceDiagnosisListComponent, canActivate: [AuthGuard] },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class DeviceDiagnosisRouting {}