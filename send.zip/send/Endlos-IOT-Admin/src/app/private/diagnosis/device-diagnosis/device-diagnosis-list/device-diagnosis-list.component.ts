import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import * as _ from 'lodash';
import { KeyValue, Pagination } from 'src/app/common/interfaces/entities/entity';
import { PageTitle } from 'src/app/constant/page-title';
import { paginationFactory } from 'src/app/shared/entities/pagination';
import { PaginationType } from 'src/app/shared/enums/common-enums';
import { DeviceDiagnosisService } from '../device-diagnosis.service';
import { DeviceService } from 'src/app/private/device/device.service';
import { SharedService } from 'src/app/shared/shared.service';
import { ListContainer } from 'src/app/Interface/list-container';
import { Modules } from 'src/app/constant/constant';
import { SnackBarService } from 'src/app/shared/components/services/snackbar.service';
import * as moment from 'moment-timezone';

@Component({
  selector: 'app-device-diagnosis-list',
  templateUrl: './device-diagnosis-list.component.html',
  providers: [DeviceDiagnosisService, DeviceService]
})
export class DeviceDiagnosisListComponent implements OnInit, OnDestroy {
  deviceDiagnosisSearchForm: FormGroup;
  rawDataList: any[] = [];
  hasData = true;
  hasFilter = false;
  listRefreshTimer: any;
  displayedColumns: string[] = [];
  dynamicColumns: string[] = [];
  deviceId: string = '';
  pagination!: Pagination;
  deviceList: any[] = [];
  theme: { [k: string]: any } = { color: 'primary' };
  placeholderList: number[] = Array(10).fill(0);
  deviceParameterList: any[] = [];
  noData = true;
  breadcrumbs: KeyValue[];
  isListView = false;
  refreshInterval: any;
  startEpoch: any;
  endEpoch: any;
  deviceDropdownParameterList: any[] = [];
  moment1: any = moment();
  selectedDeviceParameters: any[] = []; // or appropriate type

  public listContainer: ListContainer = {
    accessRightsJson: this.sharedService.getAccessRights(Modules.Device),
  };

  constructor(private deviceDiagnosisService: DeviceDiagnosisService, private deviceService: DeviceService, private fb: FormBuilder, private sharedService: SharedService, private snackbarService: SnackBarService) {
    this.breadcrumbs = [
      { key: PageTitle.DEVICE_DIAGNOSIS, value: '' }
    ];
    const viewTypeData = sessionStorage.getItem('viewType');
    if (viewTypeData) {
      this.isListView = viewTypeData === 'grid' ? false : true;
    }
    this.pagination = paginationFactory(this.isListView ? PaginationType.table : PaginationType.card);
    this.deviceDiagnosisSearchForm = this.fb.group({
      device: [null],
    });
  }

  dateRangeForm: FormGroup;

  ngOnInit(): void {
    this.onDeviceDropDown();

    // Initialize form with date and time controls
    this.dateRangeForm = this.fb.group({
      start: [''],  // Start Date
      end: [''],    // End Date
      startTime: ['12:00'], // Default to 12:00 PM (noon)
      endTime: ['23:59']    // Default to 11:59 PM
    });

    this.dateRangeForm.valueChanges.subscribe(dateRange => {
      this.onFlowDateChange(dateRange);
    });
  }

  onSearch(deviceId: string, startDate: String, endDate: String) {
    console.log(this.selectedDeviceParameters)
    let body: any = {};
    if (this.selectedDeviceParameters != undefined) {
      body.deviceParameterViewList = this.selectedDeviceParameters;
    }
    // this.hasData = false;

    this.deviceService.getDataParameterWise(Number(deviceId), body).then((response: any) => {
      this.deviceParameterList = response.view.deviceParameterViewList;

      this.dynamicColumns = this.deviceParameterList.map((param: any) => param.registerName);
      this.displayedColumns = this.dynamicColumns;
      this.dynamicColumns.push('date')
    })

    this.deviceService.getRawData(this.pagination, deviceId, startDate, endDate).then((response: any) => {
      this.rawDataList = response.list.flat();

      //this.deviceParameterList = response.view.deviceView.deviceParameterViewList;

      /* this.dynamicColumns = this.deviceParameterList.map((param: any) => param.registerName);
      this.displayedColumns = this.dynamicColumns;
      this.dynamicColumns.push('date') */

    })
    // .finally(() => {
    //   this.hasData = true;
    // });
  }

  getValueFromJson(jsonContent: string, address: string) {
    const parsedContent = JSON.parse(jsonContent);
    return parsedContent[address] || 'NA';
  }


  getAddressForRegisterName(registerName: string): string {
    const parameter = this.deviceParameterList.find(param => param.registerName === registerName);
    return parameter ? parameter.address : '';
  }

  onSubmit() {
    this.deviceId = this.deviceDiagnosisSearchForm.value.device;
    this.hasFilter = true;

    // Perform the search with combined start and end epoch
    this.onSearch(this.deviceId, this.startEpoch, this.endEpoch);

    this.refreshInterval = setInterval(() => {
      this.onSearch(this.deviceId, this.startEpoch, this.endEpoch);
    }, 10000);
    this.noData = false;
  }

  onCancel() {
    this.deviceDiagnosisSearchForm.reset();
    this.rawDataList = [];
    this.startEpoch = null;
    this.endEpoch = null;
    this.hasData = true;
    this.dateRangeForm.reset();
    /* if (this.listRefreshTimer) {
      clearInterval(this.listRefreshTimer);
    } */
  }

  ngOnDestroy() {
    // if (this.listRefreshTimer) {
    //   clearInterval(this.listRefreshTimer);
    // }
    if (this.refreshInterval) {
      clearInterval(this.refreshInterval);
    }
  }

  onDeviceDropDown() {
    this.deviceDiagnosisService.deviceDropDown().then((response: any) => {
      this.deviceList = response.list as any[];
    });
  }


  onExportToXcel() {
    if (!this.deviceId) {
      this.snackbarService.errorSnackBar('Please select Device and Generate Diagnosis');
    } else {
      const filter: any = {
        deviceView: {
          id: this.deviceId,
          deviceParameterViewList: this.selectedDeviceParameters
        },
        startDate: this.startEpoch,  // Combined Start Date and Time
        endDate: this.endEpoch       // Combined End Date and Time
      };

      this.deviceService.downloadReport(filter).then((response: any) => {
        const url = window.URL.createObjectURL(response);

        // Create a temporary anchor element
        const a = document.createElement('a');
        a.href = url;
        a.download = `${new Date().getTime()}_Diagnosis.xlsx`; // Set the file name
        document.body.appendChild(a);
        a.click();

        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);

        this.snackbarService.successSnackBar("Device Diagnosis Report Exported successfully");
      });
    }
  }

  onFlowDateChange(dateRange: { start: string, end: string, startTime: string, endTime: string }) {
    console.log('Selected Start Date:', dateRange.start);
    console.log('Selected End Date:', dateRange.end);
    console.log('Selected Start Time:', dateRange.startTime);
    console.log('Selected End Time:', dateRange.endTime);
    // Assuming dateRange is an object that holds your start and end date/time
    const startDate = new Date(dateRange.start);
    const endDate = new Date(dateRange.end);

    // Add the start time and end time to the respective dates
    const [startHour, startMinute] = dateRange.startTime.split(':').map(Number);
    startDate.setHours(startHour, startMinute);

    const [endHour, endMinute] = dateRange.endTime.split(':').map(Number);
    endDate.setHours(endHour, endMinute);

    // Get the epoch time in seconds (dividing by 1000 to convert from milliseconds)
    this.startEpoch = Math.floor(startDate.getTime() / 1000);
    this.endEpoch = Math.floor(endDate.getTime() / 1000);

    console.log('Start Date Epoch:', this.startEpoch);
    console.log('End Date Epoch:', this.endEpoch);
  }


  onDeviceChange(event: any) {
    console.log(event)
    this.deviceDiagnosisService.parameterDropDown(event.value).then((response: any) => {
      this.deviceDropdownParameterList = response.list as any[];
    });
    /* this.clientService.cityDropDown(view.key).then((response: ListResponse) => {
        this.deviceParameterList = response.list as any[];
    }); */
  }

  onDeviceParaChange(event: any) {
    this.selectedDeviceParameters = event.value.map((id: number) => ({ id }));
    console.log(this.selectedDeviceParameters);


    // const selectedDeviceId = event.value;
    // let selectedDevice = this.deviceDropdownParameterList.find(device => device.id === selectedDeviceId);

    // if (selectedDevice) {
    //   console.log(selectedDevice)
    // this.selectedDeviceParameters.push(selectedDevice)
    // }
    // const selectedDeviceId = event.value;
    // let selectedDevice = this.deviceDropdownParameterList.find(device => device.id === selectedDeviceId);

    // if (selectedDevice) {
    //   console.log(selectedDevice); // This will log the selected device object
    //   // Do something with the selected device, e.g., update the table cell
    //   /* if (this.selectedCell) {
    //     const { rowIndex, colIndex } = this.selectedCell;
    //     this.rows[rowIndex].cells[colIndex].value = selectedDevice.registerName;
    //     this.rows[rowIndex].cells[colIndex].id = selectedDevice.id;
    //   } */
    // }
  }
}