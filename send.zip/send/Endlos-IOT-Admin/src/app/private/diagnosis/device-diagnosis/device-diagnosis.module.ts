import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DeviceDiagnosisListComponent } from './device-diagnosis-list/device-diagnosis-list.component';
import { DeviceDiagnosisRouting } from './device-diagnosis-routing';
import { SharedModule } from 'src/app/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

const COMPONENTS = [
  DeviceDiagnosisListComponent,
]

@NgModule({
  declarations: [...COMPONENTS],
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    DeviceDiagnosisRouting
  ],
  exports: [...COMPONENTS]
})
export class DeviceDiagnosisModule { }
