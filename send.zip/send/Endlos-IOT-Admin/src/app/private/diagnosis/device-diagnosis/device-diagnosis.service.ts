import { Injectable } from '@angular/core';
import { Pagination } from 'src/app/common/interfaces/entities/entity';
import { ListResponse } from 'src/app/common/interfaces/response';
import { ApiUrl } from 'src/app/constant/app-url';
import { HttpService } from 'src/app/services/http.service';

@Injectable()
export class DeviceDiagnosisService {
    constructor(private httpService: HttpService) { }

    list(pagination: Pagination, deviceId: string): Promise<ListResponse> {
        const params = `deviceId=${deviceId}&start=${pagination.pageIndex * pagination.pageSize}&recordSize=${pagination.pageSize}`;
        return this.httpService.getAuth<ListResponse>(`${ApiUrl.DEVICE_DIAGNOSIS_SEARCH}?${params}`, true).then((listResponse: ListResponse) => {
            pagination.length = listResponse.records;
            return listResponse;
        });
    }

    deviceDropDown(): Promise<ListResponse> {
        return this.httpService.getAuth<ListResponse>(`${ApiUrl.DEVICE_DIAGNOSIS_DROPDOWN}`, true).then((listResponse: ListResponse) => {
            return listResponse;
        });
    }

    parameterDropDown(id: string): Promise<ListResponse> {
        return this.httpService.getAuth<ListResponse>(`${ApiUrl.DEVICE_DIAGNOSIS_PARAMETER_MAPPING_DROPDOWN}${id}`, true).then((listResponse: ListResponse) => {
            return listResponse;
        });
    }

    reportTypeDropDown(): Promise<ListResponse> {
        return this.httpService.getAuth<ListResponse>(`${ApiUrl.REPORT_TYPE_DROPDOWN}`, true).then((listResponse: ListResponse) => {
            return listResponse;
        });
    }

}