import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { range } from 'lodash';
import { KeyValue, Pagination } from 'src/app/common/interfaces/entities/entity';
import { ListResponse, ViewResponse } from 'src/app/common/interfaces/response';
import { PageTitle } from 'src/app/constant/page-title';
import { Line100By50Theme, Line100PercentBy300Theme } from 'src/app/constant/skeleton-theme';
import { SnackBarService } from 'src/app/shared/components/services/snackbar.service';
import { paginationFactory } from 'src/app/shared/entities/pagination';
import { PaginationType } from 'src/app/shared/enums/common-enums';
import { DeviceDataService } from '../device-data.service';
import { DeviceData } from 'src/app/shared/entities/DeviceData';

@Component({
  selector: 'app-device-data-list',
  templateUrl: './device-data-list.component.html',
  styleUrls: ['./device-data.component.scss'],
  providers: [DeviceDataService]
})
export class DeviceDataListComponent {

  pagination!: Pagination;
  deviceDataList: DeviceData[] = [];
  hasData = false;
  breadcrumbs: KeyValue[];
  isListView = true;
  hasAppliedFilter = false;
  searchedData = '';
  placeholderList = range(24);
  cardPlaceholderList = range(9);
  theme = Line100By50Theme;
  cardTheme = Line100PercentBy300Theme;
  displayedColumns: string[] = ['plus', 'analog1', 'analog2', 'turbodity', 'chlorine', 'dateCreate'];
  selectElement = new DeviceData();
  isDeleteDialogBoxOpen = false;
  isPlusButtonDisabled = false;
  isAnalog1ButtonDisabled = false;
  isAnalog2ButtonDisabled = false;
  isModbusButtonDisabled = false;
  isStopButtonDisabled = false;
  dataDeviceId!: number;

  constructor(
    private DeviceDataService: DeviceDataService,
    private router: Router,
    private route: ActivatedRoute,
    private snackbarService: SnackBarService
  ) {
    if (this.dataDeviceId = 1) {
      this.breadcrumbs = [
        { key: PageTitle.GSM_DEVIE_DATA, value: '' }
      ];
    } else {
      this.breadcrumbs = [
        { key: PageTitle.GATEWAY_DEVICE_DATA, value: '' }
      ];
    }
    const viewTypeData = sessionStorage.getItem('viewType');
    if (viewTypeData) {
      this.isListView = viewTypeData === 'grid' ? false : true;
    }
    this.pagination = paginationFactory(this.isListView ? PaginationType.table : PaginationType.card);
  }

  ngOnInit(): void {
    this.dataDeviceId = this.route.snapshot.params['id'];
    this.router.routeReuseStrategy.shouldReuseRoute = () => false
    const data: any = sessionStorage.getItem('deviceFilter');
    const filterData = JSON.parse(data);
    if (filterData && (filterData.searchedData)) {
      this.searchedData = filterData.searchedData ? filterData.searchedData : null;
      this.hasAppliedFilter = true;
    }
    setInterval(() => {
      this.onSearch();
      // this.dashboardBlockUi.stop();
    }, 2000);
  }

  onSearch() {
    const data: any = {};
    data.type = this.dataDeviceId;
    if (this.searchedData) {
      data.name = this.searchedData;
    }
    this.DeviceDataService.list(this.pagination, data).then((response: ListResponse) => {
      this.deviceDataList = response.list as DeviceData[];
    }).finally(() => {
      this.hasData = true;
    });
  }

  changeView(type: string) {
    this.isListView = type === 'grid' ? false : true;
    this.pagination = paginationFactory(this.isListView ? PaginationType.table : PaginationType.card);
    this.onSearch();
  }

  onSearched(event: any) {
    if (event) {
      this.searchedData = event;
      this.hasAppliedFilter = true;
      this.setFilterStorage();
    }
    else {
      this.onCancel(1);
    }
  }

  setFilterStorage() {
    const data: any = {};
    data.searchedData = this.searchedData;
    sessionStorage.setItem('deviceFilter', JSON.stringify(data));
    this.onSearch();
  }

  onCancel(index: number) {
    switch (index) {
      case 1:
        this.searchedData = '';
        break;
      case 2:
        this.searchedData = '';
        this.hasAppliedFilter = false;
        break;
    }
    if (!this.searchedData) {
      this.hasAppliedFilter = false;
    }
    this.setFilterStorage();
  }

  onClick(data: any) {
    if (data == 1) {
      this.isPlusButtonDisabled = false
      this.isAnalog1ButtonDisabled = true
      this.isAnalog2ButtonDisabled = true
      this.isModbusButtonDisabled = true
      this.isStopButtonDisabled = false
    } else if (data == 2) {
      this.isPlusButtonDisabled = true
      this.isAnalog1ButtonDisabled = false
      this.isAnalog2ButtonDisabled = true
      this.isModbusButtonDisabled = true
      this.isStopButtonDisabled = false
    } else if (data == 3) {
      this.isPlusButtonDisabled = true
      this.isAnalog1ButtonDisabled = true
      this.isAnalog2ButtonDisabled = false
      this.isModbusButtonDisabled = true
      this.isStopButtonDisabled = false
    } else if (data == 4) {
      this.isPlusButtonDisabled = true
      this.isAnalog1ButtonDisabled = true
      this.isAnalog2ButtonDisabled = true
      this.isModbusButtonDisabled = false
      this.isStopButtonDisabled = false
    } else if (data == 5) {
      this.isPlusButtonDisabled = false
      this.isAnalog1ButtonDisabled = false
      this.isAnalog2ButtonDisabled = false
      this.isModbusButtonDisabled = false
      this.isStopButtonDisabled = true
    }
    this.DeviceDataService.setData(data).then((response: ViewResponse) => {
      this.snackbarService.successSnackBar(response.message);

    })
  }

}
