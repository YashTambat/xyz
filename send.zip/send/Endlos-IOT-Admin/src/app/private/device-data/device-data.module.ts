import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DeviceDataRouting } from './device-data-routing';
import { SharedModule } from 'src/app/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DeviceDataListComponent } from './device-list/device-data-list.component';

const COMPONENTS = [
  DeviceDataListComponent
]

@NgModule({
  declarations: [...COMPONENTS],
  imports: [CommonModule, DeviceDataRouting, SharedModule, FormsModule, ReactiveFormsModule],
  exports: [...COMPONENTS]
})
export class DeviceDataModule { }
