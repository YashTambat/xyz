import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { range } from 'lodash';
import { ImageCroppedEvent } from 'ngx-image-cropper';
import { KeyValue, Pagination } from 'src/app/common/interfaces/entities/entity';
import { ListResponse, ViewResponse } from 'src/app/common/interfaces/response';
import { ApiUrl, Url } from 'src/app/constant/app-url';
import { PageTitle } from 'src/app/constant/page-title';
import { Line100By50Theme } from 'src/app/constant/skeleton-theme';
import Utils from 'src/app/public/utils/utils';
import { User} from 'src/app/shared/entities/User';
import { UserService } from '../user.service';
import { LocationService } from '../../location/location.service';
import { paginationFactory } from 'src/app/shared/entities/pagination';
import { PaginationType } from 'src/app/shared/enums/common-enums';
import { Location } from 'src/app/shared/entities/Location';
import { SnackBarService } from 'src/app/shared/components/services/snackbar.service';
import { ClientService } from '../../clients/clients.service';
import { Client } from 'src/app/shared/entities/client';
import { Constant, Modules } from 'src/app/constant/constant';
import { Pattern } from 'src/app/constant/pattern';
import { RoleService } from '../../role/role.service';
import { ScreenService } from '../../screen/screen.service';
import { ListContainer } from 'src/app/Interface/list-container';
import { SharedService } from 'src/app/shared/shared.service';
@Component({
  selector: 'app-user-add-edit',
  templateUrl: './user-add-edit.component.html',
  styleUrls: ['./user-add-edit.component.scss'],
  providers: [UserService, LocationService, ClientService, RoleService]
})
export class UserAddEditComponent implements OnInit{

  breadcrumbs: KeyValue[];
  url = Url;
  userAddEditForm: FormGroup;
  hideImageCropArial = true;
  imageBrowseFile = true;
  imageChangedEvent: any;
  croppedImage: string | null | undefined = '';
  imageShowHide = true;
  clicked = false;
  userEditId!: number;

  //userView = new User(); 
  userView: User = new User();
  stateList: User[] = [];
  cityList: User[] = [];
  utils = Utils;
  hasData = false;
  theme = Line100By50Theme;
  placeholderList = range(15);
  fileView!:any;
  apiUrl = ApiUrl; 
  cdref: any;
  locationList: Location[] = [];
  clientList: Client[] = [];
  pagination!: Pagination;


  userTypeList: any[] = [];
  screenList: any[] = [];

  public listContainer: ListContainer = {
    accessRightsJson: this.sharedService.getAccessRights(Modules.User)
};

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private snackbarService: SnackBarService,
    private userService : UserService, 
    private roleService: RoleService,
    private screenService: ScreenService,
    private sharedService: SharedService
  ) {
    this.userEditId = this.route.snapshot.params['id'];
    this.breadcrumbs = [
      { key: PageTitle.USER, value: this.url.USER },
      { key: this.userEditId ? PageTitle.EDIT + ' User' : PageTitle.ADD + ' User', value: '' },
    ];
    this.userAddEditForm = this.fb.group({
      name: [null, Validators.compose([Validators.required, Validators.maxLength(Constant.mediumNameLength)])],
      email: [null, Validators.compose([Validators.required, Validators.pattern(Pattern.email.pattern), Validators.maxLength(Constant.mediumNameLength)])],
      mobile: [null, Validators.compose([Validators.required, Validators.pattern(Pattern.onlyNumeric.pattern),Validators.minLength(Constant.minMobileNumberLength) ,Validators.maxLength(Constant.maxMobileNumberLength)])],
      address: [null, Validators.compose([Validators.required, Validators.maxLength(Constant.maxNameLength)])],
      stateView: [null, Validators.required],
      cityView: [null, Validators.required],
      roleViews: [null, Validators.required],
      password: [null, Validators.compose([Validators.required, Validators.maxLength(Constant.mediumNameLength)])],
      stateName: [null],
      cityName: [null],     
      countryName: [null],
      pincode: [null],
      profileImage: [null],     
      role: [null],
      screenViews: [null],
    });
    this.pagination = paginationFactory(false ? PaginationType.table : PaginationType.card);
  }
  
  imageFileChangeEvent(event: any): void {
    this.imageChangedEvent = event;
    this.imageBrowseFile = false;
  }

  imageCropped(event: ImageCroppedEvent) {
    this.croppedImage = event.base64;
  }
  imageCropperReady() {
    this.imageShowHide = false;
  }

  uploadImage() {
    this.hideImageCropArial = false;
    const imageBlob = this.imageDataURItoBlob(this.croppedImage?.toString().split('data:image/jpeg;base64,')[1]);
    const imageFile = new File([imageBlob], this.imageChangedEvent.target.files[0].name, { type: 'image/jpeg' });
    // this.onUpload(imageFile, 1);
    const formData = new FormData();
    formData.append("file",imageFile)
    this.userService.uploadImage(formData).then((response: ViewResponse) => {
      this.snackbarService.successSnackBar(response.message);
      this.fileView = response.view;
      this.userView.logo=this.fileView;
    });
  }

  imageDataURItoBlob(dataURI: any) {
    const byteString = window.atob(dataURI);
    const arrayBuffer = new ArrayBuffer(byteString.length);
    const int8Array = new Uint8Array(arrayBuffer);
    for (let i = 0; i < byteString.length; i++) {
        int8Array[i] = byteString.charCodeAt(i);
    }
    const blob = new Blob([int8Array], { type: 'image/jpeg' });
    return blob;
  }

  openImageCropper() {
    this.imageBrowseFile = true;
    this.userAddEditForm.controls['profileImage'].setValue(null);
    delete this.imageChangedEvent;
    this.imageShowHide = true;
    this.hideImageCropArial = true;
    // let defaultData!: any;
    // this.articleView.thumbnailImageView = defaultData;
  } 

  ngOnInit(): void { 

    this.onUserRoleDropDown();

    this.hasData = false;
    if(this.userEditId) {
      this.userService.view(this.userEditId).then((response: ViewResponse) => {
        this.userView = response.view as User;
        if(this.userView.stateView.key){
          this.onStateChange(this.userView.stateView);
        }
        if (this.userView.logo) {
          this.hideImageCropArial = false;
          this.croppedImage = this.apiUrl.IMAGE_DOWNLOAD_API + this.userView.logo.fileId;
        }
        //this.cdref.detectChanges();
      }).finally(() => {
        this.hasData = true;
      });
    }
    else {
      this.userService.addUser().then(response =>{
        if(response.code >= 1000 && response.code < 2000){
          this.hasData = true;
          //this.cdref.detectChanges();
        }else{
          this.snackbarService.errorSnackBar(response.message)
        }
      }, error =>{
        this.snackbarService.errorSnackBar(error)
      });

      /* this.clientService.list(this.pagination).then((response: ListResponse) => {
        this.clientList = response.list as Client[];
      }).finally(() => {
        this.hasData = true;
      }); */
      //this.userView.userView = new User(); //
      
      
    }
    /* this.locationService.list(this.pagination, {}).then((response: ListResponse) => {
      this.locationList = response.list as Location[];
    }).finally(() => {
      this.hasData = true;
    }); */
    
    this.onCountryChange(96);

    this.onScreenDropDown();
  }

  onSubmit() {
    if(this.userAddEditForm.invalid) {
      return;
    }
    //this.userView.roleViews = [];
    //this.userView.roleViews.push({id: 2})
    if(this.userEditId) {
      this.userService.update(this.userView).then((response: ViewResponse) => {
        this.snackbarService.successSnackBar(response.message);
        this.closeAddEditForm();
      });  
    }
    else {
      this.userService.save(this.userView).then((response: ViewResponse) => {
        this.snackbarService.successSnackBar(response.message);
        this.closeAddEditForm();
      });
    }

  }
  onStateChange(view:KeyValue){
    this.userService.cityDropDown(view.key).then((response: ListResponse) => {
      this.cityList = response.list as User[];
    });
  }
  onCountryChange(id:number){
    this.userService.stateDropDown(id).then((response: ListResponse) => {
      this.stateList = response.list as User[];
    });
  }
  closeAddEditForm() {
    this.router.navigate([Url.USER]);
  }

  onUserRoleDropDown() {
    this.roleService.userRoleDropdown().then((response: any) => {
      this.userTypeList = response.list as any[];
    });
  }

  onScreenDropDown() {
    this.screenService.userScreenDropDown().then((response: any) => {
      this.screenList = response.list as any[];
    });
  }
}