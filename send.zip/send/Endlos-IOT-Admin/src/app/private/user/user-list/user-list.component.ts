import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatBottomSheet } from '@angular/material/bottom-sheet';
import { Router } from '@angular/router';
import { KeyValue, Pagination } from 'src/app/common/interfaces/entities/entity';
import { ApiUrl, Url } from 'src/app/constant/app-url';
import { PageTitle } from 'src/app/constant/page-title';
import Utils from 'src/app/public/utils/utils';
import { ActiveMenuService } from 'src/app/shared/components/services/active-menu.service';
import { UserService } from '../user.service';
import { ListResponse } from 'src/app/common/interfaces/response';
import { paginationFactory } from 'src/app/shared/entities/pagination';
import { PaginationType } from 'src/app/shared/enums/common-enums';
import { User } from 'src/app/shared/entities/User';
import { SnackBarService } from 'src/app/shared/components/services/snackbar.service';
import { Line100By50Theme, Line100PercentBy300Theme } from 'src/app/constant/skeleton-theme';
import { range } from 'lodash';
import { ListContainer } from 'src/app/Interface/list-container';
import { Modules } from 'src/app/constant/constant';
import { SharedService } from 'src/app/shared/shared.service';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.scss'],
  providers: [UserService]
})
export class UserListComponent implements OnInit {

  pagination!: Pagination;
  userList: User[] = [];
  hasData = false;
  theme = Line100By50Theme;
  cardTheme = Line100PercentBy300Theme;
  placeholderList = range(24);
  cardPlaceholderList = range(9);
  breadcrumbs: KeyValue[];
  searchFilterForm: FormGroup;
  hasAppliedFilter = false;
  searchedData = '';
  utils = Utils;
  states: KeyValue[] = [];
  city: any;
  status: any;
  role: any;
  isDialogBoxOpen = false;
  isDeleteDialogBoxOpen = false;
  displayedColumns: string[] = ['name', 'role', 'email', 'mobile', 'address', 'status', 'action'];
  isListView = false;
  selectElement = new User();
  imgDownloadUrl = ApiUrl.IMAGE_DOWNLOAD_API;

  public listContainer: ListContainer = {
    accessRightsJson: this.sharedService.getAccessRights(Modules.User),
};

  statusList = [
    {key: 1, value: 'Active'},
    {key: 2, value: 'Inactive'},
  ]
  stateList = [
    {key: 1, value: 'Gujarat'},
    {key: 2, value: 'Delhi'},
    {key: 3, value: 'Goa'}
  ]
  cityList = [
    {key: 1, value: 'Ahmedabad'},
    {key: 2, value: 'Mumbai'},
    {key: 3, value: 'Bangluru'}
  ]
  roleList = [
    {key: 1, value: 'Master Admin'},
    {key: 2, value: 'Customer'}
  ]

  constructor(
    private activeMenuService: ActiveMenuService,
    private fb: FormBuilder,
    private _bottomSheet: MatBottomSheet,
    private router: Router,
    private userService: UserService,
    private snackbarService: SnackBarService,
    private sharedService: SharedService
  ) {
    this.activeMenuService.changeActiveMenu(true);
    this.breadcrumbs = [
      { key: PageTitle.USER, value: '' }
    ];
    this.searchFilterForm = this.fb.group({
      status: null,
      state: null,
      city: null,
      role: null,
    });
    const viewTypeData = sessionStorage.getItem('viewType');
    if(viewTypeData) {
      this.isListView = viewTypeData === 'grid' ? false : true;
    }
    this.pagination = paginationFactory(this.isListView ? PaginationType.table : PaginationType.card);
  }

  ngOnInit(): void {
    const data: any = sessionStorage.getItem('userFilter');
    const filterData = JSON.parse(data);
    if(filterData && (filterData.status || filterData.states.length !== 0 || filterData.city || filterData.role || filterData.searchedData)) {
      this.status = filterData.status ? filterData.status : null;
      this.states = filterData.states ? filterData.states : [];
      this.city = filterData.city ? filterData.city : null;
      this.role = filterData.role ? filterData.role : null;
      this.searchedData = filterData.searchedData ? filterData.searchedData : null;
      this.hasAppliedFilter = true;
    }
    this.onSearch();
  }

/*   onSearch() {
    this.hasData = false;
    const userView = Utils.getUserView();
    const data:any = {}
    if(this.searchedData) {
      data.name = this.searchedData;
    }
    console.log(data)
    
    console.log(data.name)
    this.userService.list(this.pagination,data).then((response: ListResponse) => {
      this.userList = response.list as User[];
    }).finally(() => {
      this.hasData = true;
    });
  } */

  onSearch() {
    this.hasData = false;
    const data: any = {};
    if(this.searchedData) {
      data.name = this.searchedData;
    }
    this.userService.list(this.pagination,data).then((response: ListResponse) => {
      this.userList = response.list as User[];
    }).finally(() => {
      this.hasData = true;
    });
  }

  changeView(type: string) {
    this.isListView = type === 'grid' ? false : true;
    this.pagination = paginationFactory(this.isListView ? PaginationType.table : PaginationType.card);
    this.onSearch();
  }

  openFilterBox(filterPopup: any) {
    this._bottomSheet.open(filterPopup, {disableClose: true});
  }

  closeFilter() {
    this._bottomSheet.dismiss();
  }

  onSubmit() {
    if(this.states.length !== 0 || this.status || this.city || this.role || this.searchedData) {
      this.hasAppliedFilter = true;
    }
    this.setFilterStorage();
    this.closeFilter();
  }

  setFilterStorage() {
    const data: any = {};
    data.searchedData = this.searchedData;
    data.status = this.status;
    data.states = this.states ? this.states : [];
    data.city = this.city;
    data.role = this.role;
    sessionStorage.setItem('userFilter', JSON.stringify(data));
    this.onSearch();
  }

  onSearched(event: any) {
    if(event) {
      this.searchedData = event;
      this.hasAppliedFilter = true;
      this.setFilterStorage();
    }
    else {
      this.onCancel(1);
    }
  }

  onCancel(index: number, state?: any) {
    const filterStateList: any[] = [];
    let dummy!: any;
    switch(index) {
      case 1:
        this.searchedData = '';
        break;
      case 2:
        this.status = dummy;
        break;
      case 3:
        this.city = dummy;
        break;
      case 4:
        this.states.forEach((element: any, index: number) => {
          element.key !== state.key ? filterStateList.push(element) : '';
          if(index === this.states.length - 1) {
            this.states = filterStateList;
          }
        });
        break;
      case 5:
        this.role = dummy;
        break;
      case 6:
        this.searchedData = '';
        this.status = dummy;
        this.states = filterStateList;
        this.city = dummy;
        this.role = dummy;
        this.hasAppliedFilter = false;
        break;
    }
    if(this.states.length === 0 && !this.status && !this.city && !this.role && !this.searchedData) {
      this.hasAppliedFilter = false;
    }
    this.setFilterStorage();
  }

  gotoEdit(userId: number) {
    this.router.navigate([Url.USER_EDIT + '/' + userId]);
  }

  gotoView(userId: number) {
    this.router.navigate([Url.USER_VIEW + '/' + userId]);
  }

  onToggleChange(element: User) {
    this.isDialogBoxOpen = true;
    this.selectElement = element;
  }

  onChangeStatus(event: any) {
    if (event) {
      this.userService.activeInactive(this.selectElement.id).then(() => {
        this.snackbarService.successSnackBar('User status successfully changed.');
        this.onSearch();
      });
    }
  }

  onCloseActiveModal() {
    this.isDialogBoxOpen = false;
    this.onSearch();
  }

  onDelete(user: User) {
    this.selectElement = user;
    this.isDeleteDialogBoxOpen = true;
  }


  submitDelete(event: any) {
    if(event) {
      this.userService.deleteUser(this.selectElement.id).then(() => {
        this.snackbarService.successSnackBar('User deleted successfully.');
        this.onSearch();
      }).finally(() => {
        this.isDeleteDialogBoxOpen = false;
      });
    }
  }
}
