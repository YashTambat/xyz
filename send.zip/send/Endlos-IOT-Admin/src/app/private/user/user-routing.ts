import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserListComponent } from './user-list/user-list.component';
import { AuthGuard } from 'src/app/auth-guard';
import { UserAddEditComponent } from './user-add-edit/user-add-edit.component';
import { UserViewComponent } from './user-view/user-view.component';
import { AppUrlConstant } from 'src/app/constant/app-url';

const routes: Routes = [
    { path: '', component: UserListComponent, canActivate: [AuthGuard] },
    { path: 'add', component: UserAddEditComponent, canActivate: [AuthGuard] },
    { path: AppUrlConstant.EDIT + '/:id', component: UserAddEditComponent, canActivate: [AuthGuard] },
    { path: AppUrlConstant.VIEW + '/:id', component: UserViewComponent, canActivate: [AuthGuard] },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class UserRouting {}
