import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { KeyValue } from 'src/app/common/interfaces/entities/entity';
import { ApiUrl, Url } from 'src/app/constant/app-url';
import { PageTitle } from 'src/app/constant/page-title';
import { UserService } from '../user.service';
import { ViewResponse } from 'src/app/common/interfaces/response';
import { User } from 'src/app/shared/entities/User'; 
import { LocationService } from '../../location/location.service';
import { ClientService } from '../../clients/clients.service';

@Component({
  selector: 'app-user-view',
  templateUrl: './user-view.component.html',
  providers: [UserService,LocationService, ClientService]
})
export class UserViewComponent {

  userId!: number;
  userView = new User();
  hasData = false;
  breadcrumbs: KeyValue[];
  url = Url;
  isDeleteDialogBoxOpen = false;
  displayedColumns: string[] = ['title', 'details'];
  imgDownloadUrl = ApiUrl.IMAGE_DOWNLOAD_API;
  userShowList: any[] = [];

  constructor(private router: Router, private route: ActivatedRoute, private userService: UserService) {
    this.breadcrumbs = [
      { key: PageTitle.USER, value: this.url.USER },
      { key: PageTitle.USER + ' Details', value: '' },
    ];
    this.userId = this.route.snapshot.params['id'];
    this.onUserView();
  }

  onUserView() {
    this.hasData = false;
    this.userService.view(this.userId).then((response: ViewResponse) => {
      this.userView = response.view as User;
      const roleList = '';
      // this.clientView.roleViews.forEach((role, index) => {
      //   if(index !== this.userView.roleViews.length - 1) {
      //     roleList += role.name + ', ';
      //   }
      //   else {
      //     roleList += role.name;
      //     this.userShowList = [
      //       {id: 1, title: 'User Name', value: this.userView.firstName + ' ' + this.userView.lastName, profile: 'assets/images/default-profile-picture.png'},
      //       {id: 2, title: 'Email', value: (this.userView.email ? this.userView.email : 'NA')},
      //       {id: 3, title: 'Country Code', value: '+91'},
      //       {id: 4, title: 'Roles', value: roleList},
      //       {id: 5, title: 'Mobile No.', value: this.userView.mobile ? this.userView.mobile : 'NA'},
      //       {id: 6, title: 'Address', value: this.userView.address ? this.userView.address : 'NA'},
      //       {id: 7, title: 'Pincode', value: this.userView.pinCode ? this.userView.pinCode : 'NA'},
      //       {id: 8, title: 'Status', status: this.userView.active},
      //     ]
      //     this.hasData = true;
      //   }
      // });
    });
  }

  onEdit() {
    this.router.navigate([this.url.USER_EDIT + '/' + this.userId]);
  }
 
  onDelete() {
    this.isDeleteDialogBoxOpen = true;
  }

  submitDelete(event: any) {
    this.isDeleteDialogBoxOpen = false;
  }
}