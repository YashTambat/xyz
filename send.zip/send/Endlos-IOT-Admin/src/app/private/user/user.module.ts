import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserListComponent } from './user-list/user-list.component';
import { UserRouting } from './user-routing';
import { SharedModule } from 'src/app/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UserAddEditComponent } from './user-add-edit/user-add-edit.component';
import { ImageCropperModule } from 'ngx-image-cropper';
import { UserViewComponent } from './user-view/user-view.component';

const COMPONENTS = [
  UserListComponent,
  UserAddEditComponent,
  UserViewComponent
]

@NgModule({
  declarations: [...COMPONENTS],
  imports: [CommonModule, UserRouting, SharedModule, FormsModule, ReactiveFormsModule, ImageCropperModule],
  exports: [...COMPONENTS]
})
export class UserModule { }
