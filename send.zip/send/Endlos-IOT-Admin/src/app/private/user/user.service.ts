import { Injectable } from '@angular/core';
import { Pagination } from 'src/app/common/interfaces/entities/entity';
import { ListResponse, ViewResponse } from 'src/app/common/interfaces/response';
import { ApiUrl } from 'src/app/constant/app-url';
import { HttpService } from 'src/app/services/http.service';
import { User } from 'src/app/shared/entities/User';

@Injectable()
export class UserService {
    constructor(private httpService: HttpService) {}

    list(pagination: Pagination,data:any): Promise<ListResponse> {
        const params = `start=${pagination.pageIndex * pagination.pageSize}&recordSize=${pagination.pageSize}`;
        return this.httpService.postAuth<ListResponse>(`${ApiUrl.USER_SEARCH}?${params}`, data, true).then((listResponse: ListResponse) => {
            pagination.length = listResponse.records;
            return listResponse;
        });
    }

    activeInactive(id: number): Promise<ListResponse> {
        return this.httpService.putAuth(`${ApiUrl.USER_ACTIVE_INACTIVE}/${id}`, {});
    }

    deleteUser(id: number): Promise<ListResponse> {
        return this.httpService.deleteAuth(`${ApiUrl.USER_DELETE}/${id}`);
    }

    view(userId: number): Promise<ViewResponse> {
        return this.httpService.getAuth(`${ApiUrl.USER_VIEW}/${userId}`, true);
    }

    cityDropDown(id:any): Promise<ListResponse> {
        return this.httpService.getAuth(`${ApiUrl.CITY_DROPDOWN}${id}`);
    }
      
    stateDropDown(id:number): Promise<ListResponse> {
        return this.httpService.getAuth(`${ApiUrl.STATE_DROPDOWN}${id}`);
    } 

     
    save(userView: User): Promise<ViewResponse> {
        return this.httpService.postAuth(`${ApiUrl.USER_SAVE}`, userView);
    }
  
    update(userView: User): Promise<ViewResponse> {
        return this.httpService.putAuth(`${ApiUrl.USER_UPDATE}`, userView);
    }
 


    uploadImage(userView: FormData): Promise<ViewResponse> {
        return this.httpService.postAuth(`${ApiUrl.UPLOAD_IMAGE_API}`, userView);
    }
    addUser() {
        return this.httpService.getAuth(`${ApiUrl.USER_ADD}`, true);
      }

}
