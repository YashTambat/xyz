import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PrivateRouting } from './private-routing';
import { RoleListComponent } from './role/role-list/role-list.component';
import { RoleAddEditComponent } from './role/role-add-edit/role-add-edit.component';

@NgModule({
    declarations: [],
    imports: [CommonModule, PrivateRouting, SharedModule, FormsModule, ReactiveFormsModule],
    exports: [],
})
export class PrivateModule {}
