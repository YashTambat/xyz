import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ImageCroppedEvent } from 'ngx-image-cropper';
import { ApiUrl } from 'src/app/constant/app-url';

@Component({
  selector: 'app-change-profile-image',
  templateUrl: './change-profile-image.component.html'
})
export class ChangeProfileImageComponent {

  changeProfileImageForm: FormGroup;
  clicked = false;
  apiUrl = ApiUrl;

  hideImageCropArial = true;
  imageBrowseFile = true;
  imageChangedEvent: any;
  croppedImage: string | null | undefined = '';
  imageShowHide = true;
  buttonNameChange = false;

  constructor(public activeModal: NgbActiveModal,  private fb: FormBuilder) {
    this.changeProfileImageForm = this.fb.group(
      {
        image: [null]
      }
    );
  }

  imageFileChangeEvent(event: any): void {
    this.imageChangedEvent = event;
    this.imageBrowseFile = false;
  }

  imageCropped(event: ImageCroppedEvent) {
    this.croppedImage = event.base64;
  }
  imageCropperReady() {
    this.imageShowHide = false;
  }

  uploadImage() {
    this.hideImageCropArial = false;
    const imageBlob = this.imageDataURItoBlob(this.croppedImage?.toString().split('data:image/jpeg;base64,')[1]);
    const imageFile = new File([imageBlob], this.imageChangedEvent.target.files[0].name, { type: 'image/jpeg' });
    // this.onUpload(imageFile, 1);
    this.buttonNameChange = true;
  }

  imageDataURItoBlob(dataURI: any) {
    const byteString = window.atob(dataURI);
    const arrayBuffer = new ArrayBuffer(byteString.length);
    const int8Array = new Uint8Array(arrayBuffer);
    for (let i = 0; i < byteString.length; i++) {
        int8Array[i] = byteString.charCodeAt(i);
    }
    const blob = new Blob([int8Array], { type: 'image/jpeg' });
    return blob;
  }

  openImageCropper() {
    this.imageBrowseFile = true;
    this.changeProfileImageForm.controls['image'].setValue(null);
    delete this.imageChangedEvent;
    this.imageShowHide = true;
    this.hideImageCropArial = true;
    this.buttonNameChange = false;
    // let defaultData!: any;
    // this.articleView.thumbnailImageView = defaultData;
  }

  closeModal() {
    this.activeModal.dismiss();
  }
}
