import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MyProfileViewComponent } from './my-profile-view/my-profile-view.component';
import { MyProfileRouting } from './my-profile-routing';
import { SharedModule } from 'src/app/shared/shared.module';
import { ChangeProfileImageComponent } from './change-profile-image/change-profile-image.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ImageCropperModule } from 'ngx-image-cropper';
import { MyProfileAddEditComponent } from './my-profile-add-edit/my-profile-add-edit.component';

const COMPONENT = [
  MyProfileViewComponent,
  ChangeProfileImageComponent,
  MyProfileAddEditComponent
]

@NgModule({
  declarations: [...COMPONENT, ],
  imports: [CommonModule, MyProfileRouting, SharedModule, FormsModule, ReactiveFormsModule, ImageCropperModule],
  exports: [...COMPONENT, ImageCropperModule],
})

export class MyProfileModule { }