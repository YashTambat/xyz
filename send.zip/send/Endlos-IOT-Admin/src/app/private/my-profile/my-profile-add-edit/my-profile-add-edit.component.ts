import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ImageCroppedEvent } from 'ngx-image-cropper';
import { KeyValue } from 'src/app/common/interfaces/entities/entity';
import { Url } from 'src/app/constant/app-url';
import { PageTitle } from 'src/app/constant/page-title';

@Component({
  selector: 'app-my-profile-add-edit',
  templateUrl: './my-profile-add-edit.component.html',
  styleUrls: ['./my-profile-add-edit.component.scss']
})
export class MyProfileAddEditComponent {
  cityList = [
    {key: 1, value: 'Ahmedabad'},
    {key: 2, value: 'Gandhinagar'},
    {key: 3, value: 'Rajkot'}
  ];
  stateList = [
    {key: 1, value: 'Gujarat'},
    {key: 2, value: 'Delhi'},
    {key: 3, value: 'Goa'}
  ];
  countryList = [
    {key: 1, value: 'India'},
    {key: 2, value: 'Australia'}
  ]
  breadcrumbs: KeyValue[];
  url = Url;
  myProfileAddEditForm: FormGroup;
  hideImageCropArial = true;
  imageBrowseFile = true;
  imageChangedEvent: any;
  croppedImage: string | null | undefined = '';
  imageShowHide = true;
  clicked = false;
  MyProfileAddEditEditId!: number;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.MyProfileAddEditEditId = this.route.snapshot.params['id'];
    this.breadcrumbs = [
      { key: PageTitle.MY_PROFILE, value: this.url.MY_PROFILE },
      { key: this.MyProfileAddEditEditId ? PageTitle.EDIT + ' Profile' : PageTitle.ADD + 'Profile', value: '' }, 
    ];
    this.myProfileAddEditForm = this.fb.group({
      firstName: [null],
      lastName: [null],
      email: [null],
      countryCode: [null],
      mobile: [null],
      role: [null],
      address: [null],
      landmark: [null],
      cityName: [null],
      stateName: [null],
      countryName: [null],
      pincode: [null],
      profileImage: [null]
    });
  }

  imageFileChangeEvent(event: any): void {
    this.imageChangedEvent = event;
    this.imageBrowseFile = false;
  }

  imageCropped(event: ImageCroppedEvent) {
    this.croppedImage = event.base64;
  }
  imageCropperReady() {
    this.imageShowHide = false;
  }

  uploadImage() {
    this.hideImageCropArial = false;
    const imageBlob = this.imageDataURItoBlob(this.croppedImage?.toString().split('data:image/jpeg;base64,')[1]);
    const imageFile = new File([imageBlob], this.imageChangedEvent.target.files[0].name, { type: 'image/jpeg' });
    // this.onUpload(imageFile, 1);
  }

  imageDataURItoBlob(dataURI: any) {
    const byteString = window.atob(dataURI);
    const arrayBuffer = new ArrayBuffer(byteString.length);
    const int8Array = new Uint8Array(arrayBuffer);
    for (let i = 0; i < byteString.length; i++) {
        int8Array[i] = byteString.charCodeAt(i);
    }
    const blob = new Blob([int8Array], { type: 'image/jpeg' });
    return blob;
  }

  openImageCropper() {
    this.imageBrowseFile = true;
    this.myProfileAddEditForm.controls['profileImage'].setValue(null);
    delete this.imageChangedEvent;
    this.imageShowHide = true;
    this.hideImageCropArial = true;
    // let defaultData!: any;
    // this.articleView.thumbnailImageView = defaultData;
  }

  closeAddEditForm() {
    this.router.navigate([Url.MY_PROFILE]);
  }
}
