import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/auth-guard';
import { MyProfileViewComponent } from './my-profile-view/my-profile-view.component';
import { MyProfileAddEditComponent } from './my-profile-add-edit/my-profile-add-edit.component';
import { AppUrlConstant } from 'src/app/constant/app-url';

const routes: Routes = [
    { path: '', component: MyProfileViewComponent, canActivate: [AuthGuard] }, 
    { path: AppUrlConstant.EDIT + '/:id', component: MyProfileAddEditComponent, canActivate: [AuthGuard] },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class MyProfileRouting {}