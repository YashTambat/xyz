import { Component } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { KeyValue } from 'src/app/common/interfaces/entities/entity';
import { PageTitle } from 'src/app/constant/page-title';
import { ActiveMenuService } from 'src/app/shared/components/services/active-menu.service';
import { ChangeProfileImageComponent } from '../change-profile-image/change-profile-image.component';
import { Url } from 'src/app/constant/app-url';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from 'src/app/shared/entities/User';
import { ViewResponse } from 'src/app/common/interfaces/response'; 
import { UserService } from '../../user/user.service';
import Utils from 'src/app/public/utils/utils';

@Component({
  selector: 'app-my-profile-view',
  templateUrl: './my-profile-view.component.html',
  styleUrls: ['./my-profile-view.component.scss'],
  providers: [UserService]
})
export class MyProfileViewComponent {

  breadcrumbs: KeyValue[];
  displayedColumns: string[] = ['title', 'details'];
  userView = new User();
  
  dummyList = [
    {id: 1, title: 'User Name', details: 'Preet Patel', profile: 'assets/images/default-profile-picture.png'},
    {id: 2, title: 'Email', details: 'preet@gmail.com'},
    {id: 3, title: 'Mobile No.', details: '7383822841'},
    {id: 4, title: 'Address', details: 'Shivalik Shilp, Isckon Cross Road, Ahmedabad'},
    {id: 5, title: 'Pincode', details: '380015'},
  ]

  constructor(
    private activeMenuService: ActiveMenuService,
    private modalService: NgbModal,
    private route: ActivatedRoute,
    private userService: UserService,
    private router: Router,
  ) {
    this.activeMenuService.changeActiveMenu(true);
    this.breadcrumbs = [
      { key: PageTitle.MY_PROFILE, value: '' }
    ];
    const user = Utils.getUserView();
    // this.userId = this.route.snapshot.params['id'];
    this.userService.view(user.id).then((response: ViewResponse) => {
      this.userView = response.view as User;
    });
  }
  editProfile() {
    this.modalService.open(ChangeProfileImageComponent, { backdrop: 'static', size: 'md', centered: true });
  }
  onEdit() {
    // this.router.navigate([Url.MY_PROFILE_EDIT + '/' + this.userId]);
  }
}
