import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/auth-guard';
import { AppUrlConstant } from 'src/app/constant/app-url';
import { ScreenListComponent } from './screen-list/screen-list.component';
import { ScreenAddEditComponent } from './screen-add-edit/screen-add-edit.component';
import { ScreenViewComponent } from './screen-view/screen-view.component';

const routes: Routes = [
    { path: '', component: ScreenListComponent, canActivate: [AuthGuard] },
    { path: 'add', component: ScreenAddEditComponent, canActivate: [AuthGuard] },
    { path: AppUrlConstant.EDIT + '/:id', component: ScreenAddEditComponent, canActivate: [AuthGuard] },
    { path: AppUrlConstant.VIEW + '/:id', component: ScreenViewComponent, canActivate: [AuthGuard] },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class ScreenRouting {}
