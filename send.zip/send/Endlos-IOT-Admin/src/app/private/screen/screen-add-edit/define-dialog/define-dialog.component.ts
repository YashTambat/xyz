import { AfterViewInit, Component, ElementRef, Input, Output, TemplateRef, ViewChild, EventEmitter, Renderer2, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { KeyValue } from 'src/app/common/interfaces/entities/entity';
import { ListResponse, ViewResponse } from 'src/app/common/interfaces/response';
import { Url } from 'src/app/constant/app-url';
import { DeviceDiagnosisService } from 'src/app/private/diagnosis/device-diagnosis/device-diagnosis.service';
import { HttpService } from 'src/app/services/http.service';
import { SnackBarService } from 'src/app/shared/components/services/snackbar.service';
import { ConfirmPasswordValidator } from 'src/app/shared/validator/confirm-password.validator';
import { environment } from 'src/environments/environment';

@Component({
    selector: 'app-define-dialog',
    templateUrl: './define-dialog.component.html',
    providers: [DeviceDiagnosisService]
})
export class DefineDialogComponent implements OnInit {
    @ViewChild('openSuccessPopup') openSuccessPopup!: TemplateRef<ElementRef>;
    @Input() heading!: string;
    @Input() description!: string;
    @Output() dialogBox = new EventEmitter();
    @Output() dialogBoxResponse = new EventEmitter();
    deviceList: any[] = [];
    deviceParameterList: any[] = [];
    selectedDevice: any;
    response: any = {};
    decimal:any;
    min:any;
    max:any;
    unit:any;
    function:any;
    zeroButtonText:any;
    oneButtonText:any;
    showValueMessage: boolean = false; // Default value

    constructor(public dialog: MatDialog, private deviceDiagnosisService: DeviceDiagnosisService) {}

    ngAfterViewInit(): void {
        const dialogRef = this.dialog.open(this.openSuccessPopup);
        dialogRef.afterClosed().subscribe(() => {
            this.dialogBox.emit();
        });
    }

    onSubmit(event: any,decimal :any,min:any,max:any,unit:any,function1:any,zeroButtonText:any,oneButtonText:any) {
        // var res = "{value:"+this.selectedDevice+", id: "+event.id+"}";
        // console.log("this.selectedDevice"+this.selectedDevice,"event"+event.id)
        console.log(event.id)
        let deviceParameter = this.deviceParameterList.find(device => device.id === event.id);
        
        console.log(deviceParameter)
        if(deviceParameter){
          this.response.id = deviceParameter.id;
          this.response.address = deviceParameter.address;
          this.response.decimal = decimal;
          this.response.min = min;
          this.response.max =max;
          this.response.function =function1;
          this.response.unit=unit;
          this.response.zeroButtonText=zeroButtonText;
          this.response.oneButtonText=oneButtonText;
          console.log(this.showValueMessage)
          this.response.showValueMessage = this.showValueMessage;
          this.dialogBoxResponse.emit(this.response);
        }

    }
    ngOnInit(): void {
        this.onDeviceDropDown(); 
    }

    onDeviceDropDown() {
        this.deviceDiagnosisService.deviceDropDown().then((response: any) => {
          this.deviceList = response.list as any[];
        });
      }
      onDeviceChange(event:any){
        this.deviceDiagnosisService.parameterDropDown(event.value).then((response: any) => {
            this.deviceParameterList = response.list as any[];
          });
        /* this.clientService.cityDropDown(view.key).then((response: ListResponse) => {
            this.deviceParameterList = response.list as any[];
        }); */
      }

      onDeviceParaChange(event: any) {
        const selectedDeviceId = event.value;
        this.selectedDevice = this.deviceParameterList.find(device => device.id === selectedDeviceId);
      
        if (this.selectedDevice) {
          console.log(this.selectedDevice); // This will log the selected device object
          // Do something with the selected device, e.g., update the table cell
          /* if (this.selectedCell) {
            const { rowIndex, colIndex } = this.selectedCell;
            this.rows[rowIndex].cells[colIndex].value = selectedDevice.registerName;
            this.rows[rowIndex].cells[colIndex].id = selectedDevice.id;
          } */
        }
      }
      onDecimalChange(event :any){
        this.decimal = event.target.value;
      }
      onMinChange(event :any){
        this.min = event.target.value;
      }
      onMaxChange(event :any){
        this.max = event.target.value;
      }
      onUnitChange(event :any){
        this.unit = event.target.value;
      }
      onFunctionChange(event :any){
        console.log(event)
        this.function = event.value;
      }
      onZeroButtonChange(event :any){
        console.log(event.target.value)
        this.zeroButtonText = event.target.value;
      }
      onOneButtonChange(event :any){
        console.log(event.target.value)
        this.oneButtonText = event.target.value;
      }
}
