import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as _ from 'lodash';
import { range } from 'lodash';
import { KeyValue, Pagination } from 'src/app/common/interfaces/entities/entity';
import { Url } from 'src/app/constant/app-url';
import { PageTitle } from 'src/app/constant/page-title';
import { Line100By50Theme } from 'src/app/constant/skeleton-theme';
import { SnackBarService } from 'src/app/shared/components/services/snackbar.service'; 
import { ViewResponse } from 'src/app/common/interfaces/response';
import { ScreenService } from '../screen.service';
import { Screen } from 'src/app/shared/entities/Screen';

@Component({
  selector: 'app-screen-add-edit',
  templateUrl: './screen-add-edit.component.html',
  styleUrls: ['./screen-add-edit.component.scss']
})

export class ScreenAddEditComponent {
  id: number;
  screenName: string = '';
  titleText: string = '';
  rowNumber: number = 0;
  colNumber: number = 0;
  screenDesc: string = '';
  screenParameters: any;
  columns: string[] = [];
  rows: { name: string, cells: { value: string; decimal?:number;id?:any; min?:number;max?:number,unit?:string,function?:string,zeroButtonText?:string,oneButtonText?:string,showValueMessage?:string}[] }[] = [];
  isDialogBoxOpen: boolean = false; // Flag to control dialog box visibility
  selectedRowIndex: number = -1; // Track selected row index for dialog
  selectedColIndex: number = -1; // Track selected column index for dialog


  breadcrumbs: KeyValue[];
  url = Url;
  pagination!: Pagination;
  screenEditId!: number;
  theme = Line100By50Theme;
  placeholderList = range(15);
  hasData = false;
  screenView = new Screen();
  clicked = false;

  constructor(
    private screenService: ScreenService,
    private snackbarService: SnackBarService,
    private route: ActivatedRoute,
    private router: Router,
  ) {
    this.screenEditId = this.route.snapshot.params['id'];
    this.breadcrumbs = [
      { key: PageTitle.SCREEN, value: this.url.SCREEN },
      { key: this.screenEditId ? PageTitle.EDIT : PageTitle.ADD , value: '' },
    ];
  }

  ngOnInit(): void {
    this.hasData = true;
    if(this.screenEditId) {
      this.onEdit();

    }
    else {
      this.hasData = true;
    }
  }
  
  onEdit() {
    this.hasData = false;
    this.screenService.view(this.screenEditId).then((response: ViewResponse) => {
      this.screenView = response.view as Screen;
     
      this.screenName = this.screenView.screenName;
      this.titleText = this.screenView.titleText;
      this.rowNumber = this.screenView.rowNumber;
      this.colNumber = this.screenView.colNumber;
      this.screenDesc = this.screenView.screenDesc;
      
      this.columns = this.screenView.rows[0]?.columns.map(col => col.column) || [];

       // Populate rows and cells
    this.rows = this.screenView.rows.map(row => ({
      name: row.row,
      cells: row.columns.map(cell => ({ value: cell.id, decimal: cell.decimal,id:cell.id ,min:cell.min,max:cell.max,unit:cell.unit,function:cell.function,zeroButtonText:cell.zeroButtonText,oneButtonText:cell.oneButtonText,showValueMessage:cell.showValueMessage }))
    }));

    // Populate response addresses for each cell
    this.responseAddresses = this.screenView.rows.map(row => 
      row.columns.map(col => col.address)
    );

    this.responseDecimal = this.screenView.rows.map(row => 
      row.columns.map(col => col.decimal)
    );

    this.responseMin = this.screenView.rows.map(row => 
      row.columns.map(col => col.min)
    );

    this.responseMax = this.screenView.rows.map(row => 
      row.columns.map(col => col.max)
    );
    this.responseUnit = this.screenView.rows.map(row => 
      row.columns.map(col => col.unit)
    );
    this.responseFunction = this.screenView.rows.map(row => 
      row.columns.map(col => col.function)
    );
    this.responseZeroButtonText = this.screenView.rows.map(row => 
      row.columns.map(col => col.zeroButtonText)
    );
    this.responseOneButtonText = this.screenView.rows.map(row => 
      row.columns.map(col => col.oneButtonText)
    );
    this.responseShowValueMessage = this.screenView.rows.map(row => 
      row.columns.map(col => col.showValueMessage)
    );
    
      
    }).finally(() => {
      this.hasData = true;
    });
  }

  submitForm() {
    this.generateTable();
  }

  generateTable() {
    this.columns = Array.from({ length: this.colNumber }, () => '');
    this.rows = Array.from({ length: this.rowNumber }, () => ({
      name: '',
      cells: Array.from({ length: this.colNumber }, () => ({ value: '' }))
    }));
  }

  saveTable() {
    if(this.screenEditId) {
      console.log(this.rows)
      const screenParameters = {
        id: this.screenEditId,
        screenName: this.screenName,
        titleText: this.titleText,
        rowNumber: this.rowNumber,
        colNumber: this.colNumber,
        columns: this.columns,
        screenDesc: this.screenDesc,
        rows: this.rows.map(row => ({
          row: row.name,
          columns: this.columns.map((col, colIndex) => ({
            column: col,
            value: row.cells[colIndex].value,
            decimal:row.cells[colIndex].decimal,
            min:row.cells[colIndex].min,
            max:row.cells[colIndex].max,
            unit:row.cells[colIndex].unit,
            function:row.cells[colIndex].function,
            zeroButtonText:row.cells[colIndex].zeroButtonText,
            oneButtonText:row.cells[colIndex].oneButtonText,
            showValueMessage:row.cells[colIndex].showValueMessage,
            id:row.cells[colIndex].id
          }))
        }))
      };
      this.screenParameters = screenParameters;

      this.screenService.update(this.screenParameters).then((response: ViewResponse) => {
        this.snackbarService.successSnackBar(response.message);
        this.router.navigate([Url.SCREEN]);
      }); 
    }
    else {
      if (this.isFormValid()) {
        const screenParameters = {
          screenName: this.screenName,
          titleText: this.titleText,
          rowNumber: this.rowNumber,
          colNumber: this.colNumber,
          columns: this.columns,
          screenDesc: this.screenDesc,
          rows: this.rows.map(row => ({
            row: row.name,
            columns: this.columns.map((col, colIndex) => ({
              column: col,
              value: row.cells[colIndex].value,
              decimal:row.cells[colIndex].decimal,
              min:row.cells[colIndex].min,
              max:row.cells[colIndex].max,
              unit:row.cells[colIndex].unit,
              function:row.cells[colIndex].function,
              zeroButtonText:row.cells[colIndex].zeroButtonText,
              oneButtonText:row.cells[colIndex].oneButtonText,
              showValueMessage:row.cells[colIndex].showValueMessage,
              id:row.cells[colIndex].id
            }))
          }))
        };
        this.screenParameters = screenParameters;
  
        this.screenService.save(this.screenParameters).then((response: ViewResponse) => {
          this.snackbarService.successSnackBar(response.message);
          this.router.navigate([Url.SCREEN]);
        });
      } else {
      }
      
    }
  }

  trackByIndex(index: number, item: any): number {
    return index;
  }
  
  isFormValid(): boolean {
    const allColumnsFilled = this.columns.every(col => !!col);
    const allRowsFilled = this.rows.every(row => !!row.name && row.cells.every(cell => !!cell.value));
    
    return allColumnsFilled && allRowsFilled;
  }

  onToggleChange(value: string, rowIndex: number, colIndex: number) {
    this.isDialogBoxOpen = true;
    this.selectedRowIndex = rowIndex;
    this.selectedColIndex = colIndex;
  }

  onCloseActiveModal() {
    this.isDialogBoxOpen = false;
  }

 
 /*  onChangeStatus(response: any) {
    if (this.selectedRowIndex !== -1 && this.selectedColIndex !== -1) {
      this.rows[this.selectedRowIndex].cells[this.selectedColIndex].value = response.id;
    }
    this.isDialogBoxOpen = false;
  } */
  
  responseAddresses: string[][] = []; 
  responseDecimal: string[][] = [];
  responseMin: string[][] = [];
  responseMax: string[][] = [];
  responseUnit: string[][] = [];
  responseFunction: string[][] = [];
  responseZeroButtonText:string[][] = [];
  responseOneButtonText:string[][] = [];
  responseShowValueMessage:string[][] =[];
  onChangeStatus(response: any) {
    console.log("response-->"+response.function)
    
    console.log("response-->"+response.zeroButtonText)

    console.log("response-->"+response.oneButtonText)
    if (this.selectedRowIndex !== -1 && this.selectedColIndex !== -1) {
      if (response && response.id !== undefined 
        && response.address !== undefined 
        && response.decimal !== undefined
        && response.min !== undefined
        && response.max !== undefined
      && response.unit != undefined
    && response.function != undefined) {
        this.rows[this.selectedRowIndex].cells[this.selectedColIndex].value = response.id;
        this.rows[this.selectedRowIndex].cells[this.selectedColIndex].decimal = response.decimal;
        this.rows[this.selectedRowIndex].cells[this.selectedColIndex].min = response.min;
        this.rows[this.selectedRowIndex].cells[this.selectedColIndex].max = response.max;
        this.rows[this.selectedRowIndex].cells[this.selectedColIndex].unit = response.unit;
        this.rows[this.selectedRowIndex].cells[this.selectedColIndex].function = response.function;
        this.rows[this.selectedRowIndex].cells[this.selectedColIndex].id = response.id;

        if(response.zeroButtonText != undefined){
          this.rows[this.selectedRowIndex].cells[this.selectedColIndex].zeroButtonText = response.zeroButtonText;
          if (!this.responseZeroButtonText[this.selectedRowIndex]) {
            this.responseZeroButtonText[this.selectedRowIndex] = [];
          }
          this.responseZeroButtonText[this.selectedRowIndex][this.selectedColIndex] = response.zeroButtonText;
        }
        if(response.oneButtonText != undefined){
          this.rows[this.selectedRowIndex].cells[this.selectedColIndex].oneButtonText = response.oneButtonText;
          if (!this.responseOneButtonText[this.selectedRowIndex]) {
            this.responseOneButtonText[this.selectedRowIndex] = [];
          }
          this.responseOneButtonText[this.selectedRowIndex][this.selectedColIndex] = response.oneButtonText;
        }
        if(response.showValueMessage != undefined){
          this.rows[this.selectedRowIndex].cells[this.selectedColIndex].showValueMessage = response.showValueMessage;
          if (!this.responseShowValueMessage[this.selectedRowIndex]) {
            this.responseShowValueMessage[this.selectedRowIndex] = [];
          }
          this.responseShowValueMessage[this.selectedRowIndex][this.selectedColIndex] = response.showValueMessage;
        }
        
        if (!this.responseAddresses[this.selectedRowIndex]) {
          this.responseAddresses[this.selectedRowIndex] = [];
        }
        this.responseAddresses[this.selectedRowIndex][this.selectedColIndex] = response.address;

        if (!this.responseDecimal[this.selectedRowIndex]) {
          this.responseDecimal[this.selectedRowIndex] = [];
        }
        this.responseDecimal[this.selectedRowIndex][this.selectedColIndex] = response.decimal;

        if (!this.responseMin[this.selectedRowIndex]) {
          this.responseMin[this.selectedRowIndex] = [];
        }
        this.responseMin[this.selectedRowIndex][this.selectedColIndex] = response.min;

        if (!this.responseMax[this.selectedRowIndex]) {
          this.responseMax[this.selectedRowIndex] = [];
        }
        this.responseMax[this.selectedRowIndex][this.selectedColIndex] = response.max;
        

        if (!this.responseUnit[this.selectedRowIndex]) {
          this.responseUnit[this.selectedRowIndex] = [];
        }
        this.responseUnit[this.selectedRowIndex][this.selectedColIndex] = response.unit;

        if (!this.responseFunction[this.selectedRowIndex]) {
          this.responseFunction[this.selectedRowIndex] = [];
        }
        this.responseFunction[this.selectedRowIndex][this.selectedColIndex] = response.function;
      } else {
        //console.error('Invalid response object:', response);
      }
    }
    this.isDialogBoxOpen = false;
  }
  getResponseAddress(rowIndex: number, colIndex: number): string {
    if (this.responseAddresses[rowIndex]) {
      return this.responseAddresses[rowIndex][colIndex] || '';
    }
    return '';
  }

  getResponseDecimal(rowIndex: number, colIndex: number): string {
    if (this.responseDecimal[rowIndex]) {
      return this.responseDecimal[rowIndex][colIndex] || '';
    }
    return '';
  }

  getResponseMin(rowIndex: number, colIndex: number): string {
    if (this.responseMin[rowIndex]) {
      return this.responseMin[rowIndex][colIndex] || '';
    }
    return '';
  }

  getResponseMax(rowIndex: number, colIndex: number): string {
    if (this.responseMax[rowIndex]) {
      return this.responseMax[rowIndex][colIndex] || '';
    }
    return '';
  }

  getResponseUnit(rowIndex: number, colIndex: number): string {
    if (this.responseUnit[rowIndex]) {
      return this.responseUnit[rowIndex][colIndex] || '';
    }
    return '';
  }

  getResponseFunction(rowIndex: number, colIndex: number): string {
    if (this.responseFunction[rowIndex]) {
      return this.responseFunction[rowIndex][colIndex] || '';
    }
    return '';
  }

  

  closeAddEditForm() {
    this.router.navigate([Url.SCREEN]);
  }
}