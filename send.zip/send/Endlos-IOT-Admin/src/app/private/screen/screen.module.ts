import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ScreenListComponent } from './screen-list/screen-list.component';
import { ScreenAddEditComponent } from './screen-add-edit/screen-add-edit.component';
import { ScreenViewComponent } from './screen-view/screen-view.component';
import { ScreenRouting } from './screen-routing';
import { DefineDialogComponent } from './screen-add-edit/define-dialog/define-dialog.component';

const COMPONENTS = [
  ScreenListComponent,
  ScreenAddEditComponent,
  ScreenViewComponent
]

@NgModule({
  declarations: [...COMPONENTS, DefineDialogComponent],
  imports: [CommonModule, ScreenRouting, SharedModule, FormsModule, ReactiveFormsModule],
  exports: [...COMPONENTS]
})
export class ScreenModule { }
