import { Component, OnInit } from '@angular/core';
import { KeyValue, Pagination } from 'src/app/common/interfaces/entities/entity';
import { Url } from 'src/app/constant/app-url';
import { ScreenService } from '../screen.service';
import { SnackBarService } from 'src/app/shared/components/services/snackbar.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ViewResponse } from 'src/app/common/interfaces/response';
import { Line100By50Theme } from 'src/app/constant/skeleton-theme';
import { Screen } from 'src/app/shared/entities/Screen';

@Component({
  selector: 'app-screen-view',
  templateUrl: './screen-view.component.html',
  styleUrls: ['./screen-view.component.scss']
})
export class ScreenViewComponent implements OnInit {
  screenName: string = '';
  titleText: string = '';
  rowNumber: number = 0;
  colNumber: number = 0;
  screenDesc: string = '';
  screenParameters: any;
  columns: string[] = [];
  rows: { name: string, cells: { address: string }[] }[] = [];

  breadcrumbs: KeyValue[];
  url = Url;
  pagination!: Pagination;

  isDeleteDialogBoxOpen = false;
  hasData = false;
  theme = Line100By50Theme;
  placeholderList = Array.from({ length: 6 }, (_, i) => i + 1);
  screenId!: number;

  screenView = new Screen();

  constructor(
    private screenService: ScreenService,
    private snackbarService: SnackBarService,
    private route: ActivatedRoute,
    private router: Router,
  ) {
    this.breadcrumbs = [
      { key: 'SCREEN', value: this.url.SCREEN },
      { key: 'DETAILS', value: '' },
    ];
    this.screenId = this.route.snapshot.params['id'];
  }

  ngOnInit(): void {
    this.onScreenView();
  }

  onScreenView() {
    this.hasData = false;
    this.screenService.view(this.screenId).then((response: ViewResponse) => {
    this.screenView = response.view as Screen;
    this.screenName = this.screenView.screenName;
    this.titleText = this.screenView.titleText;
    this.rowNumber = this.screenView.rowNumber;
    this.colNumber = this.screenView.colNumber;
    this.screenDesc = this.screenView.screenDesc;

    if (this.screenView.rows && this.screenView.rows.length > 0) {
      // Assuming columns are the same for all rows based on the example
      this.columns = this.screenView.rows[0].columns.map(col => col.column);

      this.rows = this.screenView.rows.map(row => ({
        name: row.row,
        cells: row.columns.map(col => ({address: col.address}))
      }));
    }
    }).finally(() => {
      this.hasData = true;
    });
  }

  onEdit() {
    this.router.navigate([Url.SCREEN_EDIT + '/' + this.screenId]);
  }

  extractValue(value: string): string {
    const startIndex = value.indexOf('(');
    const endIndex = value.indexOf(')');
    if (startIndex !== -1 && endIndex !== -1) {
      return value.substring(startIndex + 1, endIndex);
    }
    return 'NA';
  }

  
  submitDelete(event: any) {
    if(event) {
      this.screenService.delete(this.screenView.id).then(() => {
        this.snackbarService.successSnackBar('Screen deleted successfully.');
        this.router.navigate([Url.SCREEN]);
      }).finally(() => {
        this.isDeleteDialogBoxOpen = false;
      });
    }
  }
}