import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { range } from 'lodash';
import { KeyValue, Pagination } from 'src/app/common/interfaces/entities/entity';
import { ListResponse } from 'src/app/common/interfaces/response';
import { Url } from 'src/app/constant/app-url';
import { PageTitle } from 'src/app/constant/page-title';
import { Line100By50Theme, Line100PercentBy300Theme } from 'src/app/constant/skeleton-theme';
import { SnackBarService } from 'src/app/shared/components/services/snackbar.service';
import { paginationFactory } from 'src/app/shared/entities/pagination';
import { PaginationType } from 'src/app/shared/enums/common-enums';
import { Screen } from 'src/app/shared/entities/Screen';
import { ScreenService } from '../screen.service';
import { ListContainer } from 'src/app/Interface/list-container';
import { Modules } from 'src/app/constant/constant';
import { SharedService } from 'src/app/shared/shared.service';



@Component({
  selector: 'app-screen-list',
  templateUrl: './screen-list.component.html',
  styleUrls: ['./screen-list.component.scss']
})
export class ScreenListComponent {
  pagination!: Pagination;
  screenList: Screen[] = [];
  hasData = false;
  breadcrumbs: KeyValue[];
  isListView = false;
  hasAppliedFilter = false;
  searchedData = '';
  placeholderList = range(24);
  cardPlaceholderList = range(9);
  theme = Line100By50Theme;
  cardTheme = Line100PercentBy300Theme;
  selectElement = new Screen();
  isDeleteDialogBoxOpen = false;
  public listContainer: ListContainer = {
    accessRightsJson: this.sharedService.getAccessRights(Modules.Screen),
  };

  constructor(
    private screenService: ScreenService,
    private router: Router,
    private snackbarService: SnackBarService,
    private sharedService: SharedService
  ) {
    this.breadcrumbs = [
      { key: PageTitle.SCREEN, value: '' }
    ];
    const viewTypeData = sessionStorage.getItem('viewType');
    if(viewTypeData) {
      this.isListView = viewTypeData === 'grid' ? false : true;
    }
    this.pagination = paginationFactory(this.isListView ? PaginationType.table : PaginationType.card);
  }

  ngOnInit(): void {
    const data: any = sessionStorage.getItem('screenFilter');
    const filterData = JSON.parse(data);
    if(filterData && (filterData.searchedData)) {
      this.searchedData = filterData.searchedData ? filterData.searchedData : null;
      this.hasAppliedFilter = true;
    }
    this.onSearch();
  }

  onSearch() {
    this.hasData = false;
    const data: any = {};
    if(this.searchedData) {
      data.screenName = this.searchedData;
    }
    this.screenService.list(this.pagination, data).then((response: ListResponse) => {
      this.screenList = response.list as Screen[];
    }).finally(() => {
      this.hasData = true;
    });
  }

  changeView(type: string) {
    this.isListView = type === 'grid' ? false : true;
    this.pagination = paginationFactory(this.isListView ? PaginationType.table : PaginationType.card);
    this.onSearch();
  }

  onSearched(event: any) {
    if(event) {
      this.searchedData = event;
      this.hasAppliedFilter = true;
      this.setFilterStorage();
    }
    else {
      this.onCancel(1);
    }
  }

  setFilterStorage() {
    const data: any = {};
    data.searchedData = this.searchedData;
    sessionStorage.setItem('screenFilter', JSON.stringify(data));
    this.onSearch();
  }

  onCancel(index: number) {
    switch(index) {
      case 1:
        this.searchedData = '';
        break;
      case 2:
        this.searchedData = '';
        this.hasAppliedFilter = false;
        break;
    }
    if(!this.searchedData) {
      this.hasAppliedFilter = false;
    }
    this.setFilterStorage();
  }

  gotoView(id: number) {
    this.router.navigate([Url.SCREEN_VIEW + '/' + id]);
  }

  gotoEdit(id: number) {
    this.router.navigate([Url.SCREEN_EDIT + '/' + id]);
  }

  onDelete(screenData: Screen) {
    this.selectElement = screenData;
    this.isDeleteDialogBoxOpen = true;
  }

  submitDelete(event: any) {
    if(event) {
      this.screenService.delete(this.selectElement.id).then(() => {
        this.snackbarService.successSnackBar('Screen deleted successfully.');
        this.onSearch();
      }).finally(() => {
        this.isDeleteDialogBoxOpen = false;
      });
    }
  }

}
