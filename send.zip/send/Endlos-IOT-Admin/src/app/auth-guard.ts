import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { JwtHelperService } from '@auth0/angular-jwt';
import { environment } from 'src/environments/environment';
import { ViewResponse } from './common/interfaces/response';
import { AppUrlConstant, Url } from './constant/app-url';
import { HttpService } from './services/http.service';
import { SnackBarService } from './shared/components/services/snackbar.service';

@Injectable()
export class AuthGuard implements CanActivate {
    constructor(
        public jwtHelper: JwtHelperService,
        private router: Router,
        private httpService: HttpService,
        private snackbarService: SnackBarService
    ) {}

    canActivate(_route: ActivatedRouteSnapshot, _state: RouterStateSnapshot): boolean {
        const url: string = _state.url;
        if (localStorage.getItem('auth-token')) {
            const expired: boolean = this.jwtHelper.isTokenExpired(localStorage.getItem('auth-token') as string);
            if (expired) {
                if (this.jwtHelper.isTokenExpired(localStorage.getItem('refresh-token') as string)) {
                    this.snackbarService.errorSnackBar('Expired JSON token.');
                    this.router.navigate([AppUrlConstant.HOME]);
                    const themeData: any = localStorage.getItem('theme');
                    localStorage.clear();
                    localStorage.setItem('theme', themeData);
                    return true;
                }
                const data = { accessToken: localStorage.getItem('auth-token'), refreshToken: localStorage.getItem('refresh-token') };
                this.httpService
                    .postAuth<ViewResponse>(`${environment.apiUrl}/private/user/get-access-token`, data)
                    .then((response: ViewResponse) => {
                        if (response.accessToken) {
                            localStorage.setItem('auth-token', response.accessToken);
                            return true;
                        } else {
                            return false;
                        }
                    });
                return false;
            } else {
                if (
                    url ===
                        `${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.PUBLIC}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.LOGIN}` ||
                    url ===
                        `${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.PUBLIC}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.FORGOT_PASSWORD}`
                ) {
                    this.router.navigate([Url.DASHBOARD]);
                    return true;
                }
                return true;
            }
        } else if (
            url === `${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.PUBLIC}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.LOGIN}` ||
            url ===
                `${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.PUBLIC}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.FORGOT_PASSWORD}`
        ) {
            return true;
        } else {
            this.router.navigate([AppUrlConstant.HOME]);
            return true;
        }
    }
}