import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SharedModule } from './shared/shared.module';
import { AuthGuard } from './auth-guard';
import { JwtHelperService, JWT_OPTIONS } from '@auth0/angular-jwt';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpService } from './services/http.service';
import { PublicComponent } from './public/public.component';
import { ErrorPageComponent } from './error-page/error-page.component';
import { ChangePasswordComponent } from './private/change-password/change-password.component';
import { PrivateComponent } from './private/private.component';
import { ClientsModule } from './private/clients/clients.module';
import { SettingModule } from './private/setting/setting.module';

@NgModule({
  declarations: [AppComponent, PublicComponent, ErrorPageComponent, PrivateComponent, ChangePasswordComponent],
  imports: [BrowserModule, SharedModule, BrowserAnimationsModule, AppRoutingModule, HttpClientModule, FormsModule, ReactiveFormsModule, ClientsModule, SettingModule],
  providers: [HttpService, AuthGuard, { provide: JWT_OPTIONS, useValue: JWT_OPTIONS }, JwtHelperService],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class AppModule {}
