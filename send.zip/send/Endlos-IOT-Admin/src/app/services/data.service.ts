import { Injectable } from '@angular/core';
import { BehaviorSubject} from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class DataServices {

//   constructor(  ) {}

  public clientDataSubject = new BehaviorSubject(null);
  public clientData = this.clientDataSubject.asObservable();
}
