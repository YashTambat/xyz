import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { lastValueFrom } from 'rxjs';
import { Response } from '../common/interfaces/response';
import { AppUrlConstant } from '../constant/app-url';
import { ErrorMessage } from '../constant/error-message';
import { SnackBarService } from '../shared/components/services/snackbar.service';

@Injectable({
    providedIn: 'root',
})
export class HttpService {
    constructor(private http: HttpClient, private router: Router, private snackbarService: SnackBarService) {}

    get<T extends Response>(path: string, handleErrInSpecComponent = false): Promise<T> {
        return lastValueFrom(this.http.get(path))
            .then((response: object) => {
                const proResponse = response as T;
                if ((1000 <= proResponse.code && proResponse.code < 2000) || handleErrInSpecComponent) {
                    return Promise.resolve(proResponse);
                }
                this.snackbarService.errorSnackBar(proResponse.message);
                return Promise.reject({} as T);
            })
            .catch((httpErrorResponse: HttpErrorResponse) => {
                this.handleHttpErrorResponse(httpErrorResponse);
                return Promise.reject({} as T);
            });
    }

    post<T extends Response>(path: string, data: object, handleErrInSpecComponent = false): Promise<T> {
        return lastValueFrom(this.http.post(path, data))
            .then((response: object) => {
                const proResponse = response as T;
                if ((1000 <= proResponse.code && proResponse.code < 2000) || handleErrInSpecComponent) {
                    return Promise.resolve(proResponse);
                }
                this.snackbarService.errorSnackBar(proResponse.message);
                return Promise.reject({} as T);
            })
            .catch((httpErrorResponse: HttpErrorResponse) => {
                this.handleHttpErrorResponse(httpErrorResponse);
                return Promise.reject({} as T);
            });
    }

    getAuth<T extends Response>(path: string, handleErrInSpecComponent = false): Promise<T> {
        return lastValueFrom(this.http.get(path, { headers: this.getHeader() }))
            .then((response: object) => {
                const proResponse = response as T;
                if ((1000 <= proResponse.code && proResponse.code < 2000) || handleErrInSpecComponent) {
                    this.setOrUpdateToken(proResponse);
                    return Promise.resolve(proResponse);
                }
                this.snackbarService.errorSnackBar(proResponse.message);
                return Promise.reject({} as T);
            })
            .catch((httpErrorResponse: HttpErrorResponse) => {
                this.handleHttpErrorResponse(httpErrorResponse);
                return Promise.reject({} as T);
            });
    }

    deleteAuth<T extends Response>(path: string, handleErrInSpecComponent = false): Promise<T> {
        return lastValueFrom(this.http.delete(path, { headers: this.getHeader() }))
            .then((response: object) => {
                const proResponse = response as T;
                if ((1000 <= proResponse.code && proResponse.code < 2000) || handleErrInSpecComponent) {
                    this.setOrUpdateToken(proResponse);
                    return Promise.resolve(proResponse);
                }
                this.snackbarService.errorSnackBar(proResponse.message);
                return Promise.reject({} as T);
            })
            .catch((httpErrorResponse: HttpErrorResponse) => {
                this.handleHttpErrorResponse(httpErrorResponse);
                return Promise.reject({} as T);
            });
    }

    postAuth<T extends Response>(path: string, data: object, handleErrInSpecComponent = false): Promise<T> {
        return lastValueFrom(this.http.post(path, data, { headers: this.getHeader() }))
            .then((response: object) => {
                const proResponse = response as T;
                if ((1000 <= proResponse.code && proResponse.code < 2000) || handleErrInSpecComponent) {
                    this.setOrUpdateToken(proResponse);
                    return Promise.resolve(proResponse);
                }
                this.snackbarService.errorSnackBar(proResponse.message);
                return Promise.reject({} as T);
            })
            .catch((httpErrorResponse: HttpErrorResponse) => {
                this.handleHttpErrorResponse(httpErrorResponse);
                return Promise.reject({} as T);
            });
    }

    putAuth<T extends Response>(path: string, data: object, handleErrInSpecComponent = false): Promise<T> {
        return lastValueFrom(this.http.put(path, data, { headers: this.getHeader() }))
            .then((response: object) => {
                const proResponse = response as T;
                if ((1000 <= proResponse.code && proResponse.code < 2000) || handleErrInSpecComponent) {
                    this.setOrUpdateToken(proResponse);
                    return Promise.resolve(proResponse);
                }
                this.snackbarService.errorSnackBar(proResponse.message);
                return Promise.reject({} as T);
            })
            .catch((httpErrorResponse: HttpErrorResponse) => {
                this.handleHttpErrorResponse(httpErrorResponse);
                return Promise.reject({} as T);
            });
    }

    private handleHttpErrorResponse(httpErrorResponse: HttpErrorResponse): void {
        const themeData: any = localStorage.getItem('theme');
        if (!httpErrorResponse.error) {
            return;
        }
        switch (httpErrorResponse.status) {
            case 500:
                this.snackbarService.errorSnackBar(httpErrorResponse.error.message);
                break;
            case 404:
                this.snackbarService.errorSnackBar(httpErrorResponse.message);
                break;
            case 401:
                localStorage.clear();
                localStorage.setItem('theme', themeData);
                this.router.navigate([AppUrlConstant.HOME]);
                this.snackbarService.errorSnackBar(httpErrorResponse.error.message);
                break;
            case 403:
                this.snackbarService.errorSnackBar(httpErrorResponse.error.message);
                this.router.navigate([AppUrlConstant.UNAUTHORIZED]);
                break;
            case 502:
                this.snackbarService.errorSnackBar(ErrorMessage.unAuthorization);
                break;
            case 0:
                this.snackbarService.errorSnackBar(ErrorMessage.unAuthorization);
                break;
            default:
                this.snackbarService.errorSnackBar(httpErrorResponse.message);
                break;
        }
    }

    private setOrUpdateToken(response: Response): void {
        if (response?.accessToken) {
            localStorage.setItem('auth-token', response.accessToken);
        }
        if (response?.refreshToken) {
            localStorage.setItem('refresh-token', response.refreshToken);
        }
    }

    private getHeader() {
        return new HttpHeaders({
            Authorization: 'bearer ' + localStorage.getItem('auth-token'),
            refreshToken: 'bearer ' + localStorage.getItem('refresh-token'),
        });
    }

    postAuthBlob<T extends Response>(path: string, data: object, handleErrInSpecComponent = false): Promise<T> {
        return lastValueFrom(this.http.post(path, data, { headers: this.getHeader(),responseType: 'blob' }))
            .then((response:any) => {
                const proResponse = response;
                // if ((1000 <= proResponse.code && proResponse.code < 2000) || handleErrInSpecComponent) {
                    // this.setOrUpdateToken(proResponse);
                    return Promise.resolve(proResponse);
                // }
                // this.snackbarService.errorSnackBar(proResponse.message);
                // return Promise.reject({} as T);
            })
            .catch((httpErrorResponse: HttpErrorResponse) => {
                this.handleHttpErrorResponse(httpErrorResponse);
                return Promise.reject({} as T);
            });
    }
}
