import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
})
export class AppComponent {
  title = 'jal-jeevan-mission';
  splashScreenFlag = false;

    constructor() {
        if (window.location.pathname === '/') {
            this.splashScreenFlag = true;
        }
        // const themeData: any = localStorage.getItem('theme');
        // if(themeData === 'light') {
        //     this.renderer.addClass(document.body, 'light-theme');
        //     this.renderer.removeClass(document.body, 'dark-theme');
        // }
        // if(themeData === 'dark') {
        //     this.renderer.addClass(document.body, 'dark-theme');
        //     this.renderer.removeClass(document.body, 'light-theme');
        // }
    }
}
