import { AcceessRightsInterface } from './acceess-rights';

export type ListContainer = {
    accessRightsJson: AcceessRightsInterface
}
