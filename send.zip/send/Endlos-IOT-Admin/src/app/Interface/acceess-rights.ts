export interface AcceessRightsInterface {
    isAccessRightAdd: boolean;
    isAccessRightEdit: boolean;
    isAccessRightDelete: boolean;
    isAccessRightView: boolean;
    isAccessRightActivation: boolean;
    isAccessRightList: boolean;
}