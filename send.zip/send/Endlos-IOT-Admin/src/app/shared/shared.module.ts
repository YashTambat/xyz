import { HeaderComponent } from './components/header/header.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MaterialModule } from './material/material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BreadcrumbComponent } from './components/breadcrumb/breadcrumb.component';
import { LoaderComponent } from './components/loader/loader.component';
import { ErrorMessageComponent } from './components/error-message/error-message.component';
import { DialogBoxComponent } from './components/dialog-box/dialog-box.component';
import { SplashScreenComponent } from './splash-screen/splash-screen.component';
import { LottieModule } from 'ngx-lottie';
import player from 'lottie-web';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { CommonPublicLogoComponent } from './components/common-public-logo/common-public-logo.component';
import { HeaderFilterMenuComponent } from './components/header-filter-menu/header-filter-menu.component';
import { TopPanelComponent } from './components/top-panel/top-panel.component';
import { DeleteDialogBoxComponent } from './components/delete-dialog-box/delete-dialog-box.component';
import { ActiveInactiveDialogBoxComponent } from './components/active-inactive-dialog-box/active-inactive-dialog-box.component';
import { CircleSkeletonLoaderComponent } from './components/circle-skeleton-loader/circle-skeleton-loader.component';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { LineSkeletonLoaderComponent } from './components/circle-skeleton-loader/line-skeleton-loader.component';
import { MatPaginationComponent } from './components/mat-pagination/mat-pagination.component';
import { PaginatorModule } from 'primeng/paginator';
import { NoRecordFoundComponent } from './components/no-record-found/no-record-found.component';
import { CommonPublicDesignedBy } from './components/common-public-logo/common-public-designed-by.component';
import { ZingChartModule } from './components/zing-chart/zing-chart.module';

export function playerFactory() {
    return player;
}

const COMPONENTS = [
    BreadcrumbComponent,
    LoaderComponent,
    ErrorMessageComponent,
    DialogBoxComponent,
    SplashScreenComponent,
    HeaderComponent,
    SidebarComponent,
    CommonPublicLogoComponent,
    CommonPublicDesignedBy,
    HeaderFilterMenuComponent,
    TopPanelComponent,
    DeleteDialogBoxComponent,
    ActiveInactiveDialogBoxComponent,
    CircleSkeletonLoaderComponent,
    LineSkeletonLoaderComponent,
    MatPaginationComponent,
    NoRecordFoundComponent
]

@NgModule({
    declarations: [...COMPONENTS],
    imports: [CommonModule, MaterialModule, RouterModule, FormsModule, ReactiveFormsModule, LottieModule.forRoot({ player: playerFactory }), NgxSkeletonLoaderModule, PaginatorModule, ZingChartModule],
    exports: [...COMPONENTS, MaterialModule],
})
export class SharedModule {}
