import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { AcceessRightsInterface } from './../Interface/acceess-rights';
import { User } from './entities/User';
import { Url } from '../constant/app-url';
import { SnackBarService } from './components/services/snackbar.service';
import { IdNameView } from '../common/view/common/id-name-view';
import { RightsConfig } from '../constant/rights-config';
import Utils from '../public/utils/utils';


@Injectable({
  providedIn: 'root'
})
export class SharedService {
  public currentLoggedInUser: User = new User();
  public appUrl = Url;
  constructor(
    private http: HttpClient,
    private snackBarService: SnackBarService
  ) { }





  getAccessRights(module: IdNameView): AcceessRightsInterface {
    let accessRightsJson: AcceessRightsInterface = {
      isAccessRightAdd: false,
      isAccessRightEdit: false,
      isAccessRightView: false,
      isAccessRightDelete: false,
      isAccessRightList: false,
      isAccessRightActivation: false
    }
    
    this.currentLoggedInUser = Utils.getUserView();
    if (this.currentLoggedInUser != undefined && this.currentLoggedInUser.id != undefined && this.currentLoggedInUser.id != 0) {
      //this.currentLoggedInUser = this.currentUserStoreService.getCurrentUser();
      if (this.currentLoggedInUser.moduleViews != undefined && this.currentLoggedInUser.moduleViews.length > 0) {
        this.currentLoggedInUser.moduleViews.forEach(function (moduleKey, moduleValue) {
          if (module.id == moduleKey.id) {
            moduleKey.rightsViews.forEach(function (rightKey, rightValue) {
              switch (rightKey.id) {
                case (RightsConfig.ADD.id): {
                  accessRightsJson.isAccessRightAdd = true;
                  break;
                }
                case (RightsConfig.UPDATE.id): {
                  accessRightsJson.isAccessRightEdit = true;
                  break;
                }
                case (RightsConfig.VIEW.id): {
                  accessRightsJson.isAccessRightView = true;
                  break;
                }
                case (RightsConfig.DELETE.id): {
                  accessRightsJson.isAccessRightDelete = true;
                  break;
                }
                case (RightsConfig.LIST.id): {
                  accessRightsJson.isAccessRightList = true;
                  break;
                }
                case (RightsConfig.ACTIVATION.id): {
                  accessRightsJson.isAccessRightActivation = true;
                  break;
                }
              }
            });
          }
        });
      }
    }
    return accessRightsJson
  }

}
