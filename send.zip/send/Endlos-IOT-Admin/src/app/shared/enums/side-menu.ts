import { Url } from "src/app/constant/app-url";
import { Modules } from "src/app/constant/constant";

export const SideBarMenuList = [
    {
        text: 'Dashboard',
        icon: 'grid_view',
        routerLink: Url.DASHBOARD,
        moduleId: Modules.Dashboard.id,
    },
    {
        text: 'Device',
        icon: 'devices',
        routerLink: Url.DEVICE,
        moduleId: Modules.Device.id,
    },
    {
        text: 'Screen',
        icon: 'devices',
        routerLink: Url.SCREEN,
        moduleId: Modules.Screen.id
    },
    {
        text: 'Device Diagnosis',
        icon: 'monitor_heart',
        routerLink: Url.DEVICE_DIAGNOSIS,
        moduleId: Modules.Device_Diagnosis.id
    },
    {
        text: 'Alarm History',
        icon: 'monitor_heart',
        routerLink: Url.ALARM_HISTORY,
        moduleId: Modules.Alarm_History.id
    },
    {
        text: 'User',
        icon: 'person',
        routerLink: Url.USER,
        moduleId: Modules.User.id,
    },
    {
        text: 'Role',
        icon: 'list',
        routerLink: Url.USER_ROLE,
        moduleId: Modules.Role.id,
    },
    {
        text: 'Setting',
        icon: 'settings',
        routerLink: Url.SETTING, 
        moduleId: Modules.System_Setting.id,
    },
    // {
    //     text: 'Alarm',
    //     icon: 'notifications',
    //     routerLink: Url.ALARM,
    //     moduleId: Modules.Alarm.id,
    // },
    /* {
        text: 'Report',
        icon: 'monitoring',
        routerLink: Url.REPORT,
        moduleId: Modules.Report.id,
    }, */
    /* {
        text: 'GSM Device Data',
        icon: 'devices',
        routerLink: Url.DEVICE_DATA + 1,
        moduleId: Modules.Device.id,
    },
    {
        text: 'Gateway Device Data',
        icon: 'devices',
        routerLink: Url.DEVICE_DATA + 2,
        moduleId: Modules.Device.id,
    }, */
    // {
    //     text: 'Gateway',
    //     icon: 'router',
    //     routerLink: Url.GATEWAY,
    //     moduleId: Modules.Gateway.id,
    // },
   /*  {
        text: 'Location',
        icon: 'pin_drop',
        routerLink: Url.LOCATION,
        moduleId: Modules.Location.id,
    }, */
    // {
    //     text: 'Device',
    //     icon: 'devices',
    //     routerLink: Url.DEVICE,
    //     moduleId: Modules.Dashboard.id,
    // },
   /*  
    {
        text: 'Clients',
        icon: 'person',
        routerLink: Url.CLIENTS, 
        moduleId: Modules.Client.id,
    }, */
    // {
    //     text: 'Setting',
    //     icon: 'settings',
    //     routerLink: '',
    //     children: [
    //         {
    //             text: 'Setting',
    //             icon: 'settings',
    //             routerLink: '',
    //         },
    //         // {
    //         //     text: 'Password Policy',
    //         //     icon: 'key',
    //         //     routerLink: '',
    //         // },
    //         // {
    //         //     text: 'Security Policy',
    //         //     icon: 'security',
    //         //     routerLink: '',
    //         // },
            
    //     ],
    // },
    // {
    //     text: 'Users',
    //     icon: 'groups',
    //     routerLink: Url.USERS,
    //     routerLink: '',
    //     children: [
    //         {
    //             text: 'User',
    //             icon: 'person',
    //             routerLink: Url.USER,
    //             routerLink: '',
    //         },
    //         {
    //             text: 'Role',
    //             icon: 'manage_accounts',
    //             routerLink: '',
    //         },
    //     ],
    // },
  
    // {
    //     text: 'Parameter Mapping',
    //     icon: 'speed',
    //     routerLink: Url.PARAMETER_MAPPING,
    // },
   
    // {
    //     text: 'Job',
    //     icon: 'work',
    //     routerLink: '',
    // },
    // {
    //     text: 'Notification & Alarm',
    //     icon: 'notifications',
    //     routerLink: '',
    // },
    // {
    //     text: 'Maintenance',
    //     icon: 'construction',
    //     routerLink: '',
    // },

    // {
    //     text: 'Dashboard Setting',
    //     icon: 'build',
    //     routerLink: '',
    //     children: [
    //         {
    //             text: 'Dashboard View Setting',
    //             icon: 'widgets',
    //             routerLink: '',
    //         },
    //         {
    //             text: 'Machine Parameter Setting',
    //             icon: 'room_preferences',
    //             routerLink: '',
    //         },
    //         {
    //             text: 'Over All Summary Setting',
    //             icon: 'inbox_customize',
    //             routerLink: '',
    //         },
    //     ],
    // },
    // {
    //     text: 'Diagnosis',
    //     icon: 'browse_activity',
    //     routerLink: Url.DIAGNOSIS,
    //     children: [
    //         // {
    //         //     text: 'Diagnosis Log',
    //         //     icon: 'list_alt',
    //         //     routerLink: Url.DIAGNOSIS_LOG,
    //         // },
    //         {
    //             text: 'Device Diagnosis',
    //             icon: 'monitor_heart',
    //             routerLink: Url.DEVICE_DIAGNOSIS,
    //         },
    //         // {
    //         //     text: 'Device Log',
    //         //     icon: 'aod',
    //         //     routerLink: '',
    //         // },
    //         // {
    //         //     text: 'Gateway Log',
    //         //     icon: 'text_snippet',
    //         //     routerLink: '',
    //         // },
    //         // {
    //         //     text: 'Network Diagram',
    //         //     icon: 'signal_cellular_alt',
    //         //     routerLink: '',
    //         // },
    //     ],
    // },
    // {
    //     text: 'OTA',
    //     icon: 'cell_tower',
    //     routerLink: '',
    //     children: [
    //         {
    //             text: 'Save OTA',
    //             icon: 'save',
    //             routerLink: '',
    //         },
    //         {
    //             text: 'Send OTA',
    //             icon: 'send',
    //             routerLink: '',
    //         },
    //     ],
    // },
];