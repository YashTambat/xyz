export enum PaginationType {
    card = 'card',
    table = 'table',
}
