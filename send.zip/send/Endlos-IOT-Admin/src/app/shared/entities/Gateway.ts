import { IdName, KeyValue } from 'src/app/common/interfaces/entities/entity';
import { BaseEntity } from './BaseEntity';

export class Gateway extends BaseEntity {
    name!: string;
    gatewayId!:string    
    ipadd!: string;
    mqttHost!: string;
   
   
    code!: string;
    location!: string;
    ipAddress!: number;
    longitude!: number;  
    latitude!: number; 
    macAddress!: string; 
    
    // mac!: string;
    port!: KeyValue;
    key!: number;
    value!: string;
    clientName!: string;
    gid!: string;
    locationView!: any;
}