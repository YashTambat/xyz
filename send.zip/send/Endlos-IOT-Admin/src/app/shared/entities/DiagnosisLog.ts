import { BaseEntity } from './BaseEntity';

export class DiagnosisLog extends BaseEntity {
    _id!: string;
    deviceId!: string;
    tds!: string;
    flow!: string;
    pH!: string;
    time!: string;
}