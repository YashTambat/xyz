import { BaseEntity } from './BaseEntity';
import { ParameterMapping } from './ParameterMapping';

export class DeviceParameter extends BaseEntity {
    registerName!: string;
    imei!:string;
    unit!:string;
    address!:string;
    function!:string;
    parameterMasterView!:any;
    min!:number;
    max!:number
}