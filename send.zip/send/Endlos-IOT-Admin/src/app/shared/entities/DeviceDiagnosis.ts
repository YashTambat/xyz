import { BaseEntity } from './BaseEntity';

export class DeviceDiagnosis extends BaseEntity {
    _id!: string;
    deviceId!: string;
    parameterDetail!: {name:string,value:string};
}