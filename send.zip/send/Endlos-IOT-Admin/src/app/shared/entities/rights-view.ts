import { BaseEntity } from "./BaseEntity";

export class RightsView extends BaseEntity {
	public name! : String;

    constructor(view : RightsView){
        super();
        this.name = view.name
    }
}