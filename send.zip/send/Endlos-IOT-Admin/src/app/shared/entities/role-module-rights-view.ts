import { BaseEntity } from "./BaseEntity";
import { ModuleView } from "./module-view";
import { RightsView } from "./rights-view";

export class RoleModuleRightsView extends BaseEntity {
    public rightsView: RightsView;
    public moduleView: ModuleView;

    constructor(view: RoleModuleRightsView) {
        super();
        this.rightsView = view.rightsView
        this.moduleView = view.moduleView
    }

}