export class BaseEntity {
    id!: number;
    checked!: boolean;
    isSelected!: boolean;
}
