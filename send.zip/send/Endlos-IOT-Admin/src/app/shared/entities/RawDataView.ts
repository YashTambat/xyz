import { BaseEntity } from './BaseEntity';
import { Device } from './Device';

export class RawDataView extends BaseEntity {
    flow!: string;
    cholrine!: string;
    turbidity!: string;
    levelSensor!: string;
    pressureTransmitter!: string;
    deviceView!: Device;
    createDate!:number
    digitalOutput!:string;
}