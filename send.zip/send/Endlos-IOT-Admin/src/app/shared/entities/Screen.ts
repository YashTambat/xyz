import { BaseEntity } from './BaseEntity';
import { Machine } from './Machine';
import { Gateway } from './Gateway';
import { KeyValue } from 'src/app/common/interfaces/entities/entity';
import { ParameterMapping } from './ParameterMapping';

export class Screen extends BaseEntity {
    screenName!: string;
    screenId!: string;
    titleText!: string;
    screenDesc!: string;
    rowNumber!: number;
    colNumber!: number;
    columns!: string[];
    rows!: { row: string; columns: { column: string; value: string; readOnly:boolean; id:any; address:string,decimal:any,min:any,max:any,unit:any,function:any,zeroButtonText:any,oneButtonText:any,showValueMessage:any}[] }[];
  }
  
  