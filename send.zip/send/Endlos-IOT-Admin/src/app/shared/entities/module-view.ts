import { BaseEntity } from "./BaseEntity";
import { RightsView } from "./rights-view";

export class ModuleView extends BaseEntity {
    public name!: String;
    public rightsViews!: Array<RightsView>;

    constructor(view: ModuleView) {
        super();
        this.name = view.name
        this.rightsViews = view.rightsViews
    }
}