import { Pagination } from 'src/app/common/interfaces/entities/entity';
import { PaginationType } from '../enums/common-enums';

export class TablePagination implements Pagination {
    pageIndex: number;
    pageSize: number;
    length: number;
    pageSizes: number[];

    readonly DEFAULT_PAGE_SIZES = [10, 20, 30, 40];
    readonly DEFAULT_PAGE_SIZE = 10;

    constructor(pageIndex = 0, length = 0) {
        this.pageIndex = pageIndex;
        this.length = length;
        this.pageSize = this.DEFAULT_PAGE_SIZE;
        this.pageSizes = this.DEFAULT_PAGE_SIZES;
    }
}

export class CardPagination implements Pagination {
    pageIndex: number;
    pageSize: number;
    length: number;
    pageSizes: number[];

    readonly DEFAULT_PAGE_SIZES = [15, 30, 60, 90, 120];
    readonly DEFAULT_PAGE_SIZE = 15;

    constructor(pageIndex = 0, length = 0) {
        this.pageIndex = pageIndex;
        this.length = length;
        this.pageSize = this.DEFAULT_PAGE_SIZE;
        this.pageSizes = this.DEFAULT_PAGE_SIZES;
    }
}

export function paginationFactory(type: string): Pagination {
    if (type === PaginationType.card) {
        return new CardPagination();
    } else {
        return new TablePagination();
    }
}
