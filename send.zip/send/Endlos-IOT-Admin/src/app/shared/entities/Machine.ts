import { KeyValue } from 'src/app/common/interfaces/entities/entity';
import { BaseEntity } from './BaseEntity';

export class Machine extends BaseEntity {
    name!: string;
    mcode!: string;
    ptype!: KeyValue;
    pmviews!: Machine[];
}