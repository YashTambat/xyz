import { FileView, IdName, KeyValue } from 'src/app/common/interfaces/entities/entity';
import { BaseEntity } from './BaseEntity';
import { User } from './User';

export class Client extends BaseEntity {
    name: string = '';
    logo!: FileView;
    address!: string;
    area!: string;
    stateView!: KeyValue;
    cityView!: KeyValue;
    pincode!: number;
    active!: boolean;
    userView!: User;
    email!: User;
    mobile!: number; 
    clientView!: IdName;
    value!: string;
    userName!: string;
    contactPersonName!: string;
}
