import { BaseEntity } from "./BaseEntity";
import { RoleModuleRightsView } from "./role-module-rights-view";

export class RoleView extends BaseEntity{
    public name! : String;
	public description! : String;
	public roleModuleRightsViews! : Array<RoleModuleRightsView>;

    constructor(view? : RoleView){
        super();
        if(view != undefined){
            this.name = view.name
            this.description = view.description
            this.roleModuleRightsViews = view.roleModuleRightsViews
        }
    }
}