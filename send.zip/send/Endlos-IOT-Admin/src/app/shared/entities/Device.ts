import { BaseEntity } from './BaseEntity';
import { Machine } from './Machine';
import { Gateway } from './Gateway';
import { KeyValue } from 'src/app/common/interfaces/entities/entity';
import { ParameterMapping } from './ParameterMapping';

export class Device extends BaseEntity {
    did!: string;
    dparamList!: ParameterMapping[];
    deviceParameterViewList!: ParameterMapping[];

    name!: string;
    deviceId!: string;
    ParameterMasterView: ParameterMapping;
    
    registerName!: string;
    imei!:string;
    unit!:string;
    address!:string;
    function!:string;

}