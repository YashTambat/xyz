import { KeyValue } from 'src/app/common/interfaces/entities/entity';
import { BaseEntity } from './BaseEntity';

export class ParameterMapping extends BaseEntity {
    name!: string;
    jsonCode!: string;
    paramUnit!: string;
    paramVal!: string;
    paramAgg!: KeyValue;
    unitConv!: string;
    paramFun!: string;
    parameterName!: string;
    value!: string;
    disabled?: boolean;
}