import { Entity, IdName, KeyValue } from 'src/app/common/interfaces/entities/entity';
import { BaseEntity } from './BaseEntity';

export class Location extends BaseEntity {
    name!: string;
    gid: string = '';
    // code!: string;
    // mqttHost!: string;
    // mac!: string;
    // ipadd!: string;
    // location!: string;
    // port!: KeyValue;
    // key!: number;    
    // clientName!: string;
    value!: string;
    locationId!: string;    
    latitude!: number;
    longitude!: number;
    altitude!: number;
    address!: string;
    area!: string;
    pincode!: string;
    clientView!: IdName;
    cityView!: KeyValue;
    stateView!: KeyValue; 
    block!: string;
    panchayat!: string;
    village!: string;
}