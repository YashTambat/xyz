import { FileView, KeyValue } from 'src/app/common/interfaces/entities/entity';
import { BaseEntity } from './BaseEntity';
import { RoleView } from './role-view';
import { Screen } from './Screen';
import { ModuleView } from './module-view';

export class User extends BaseEntity {
    firstName!: string;
    lastName!: string;
    email: string = '';
    mobile!: number;
    address!: string;
    cityName!: string;
    landmark!: string;
    stateName!: string;
    pinCode!: number;
    hasLoggedIn!: boolean;
    verified!: boolean;
    verifyTokenUsed!: boolean;
    shortFormOfName!: string;
    name: string = '';
    //roleViews!: any[];
    typeId!: KeyValue;
    userView!: User;
    active!: boolean;
    logo!: FileView;
    stateView!: KeyValue;  
    area!: string; 
    cityView!: KeyValue;
    pincode!: number;  
    value!: string;
    userName!: string; 
    locationView!: any;
    clientView!: any;
    public roleViews? : Array<RoleView>;
    public screenViews? : Array<Screen>;
    password!: string;
    public moduleViews? : Array<ModuleView>

    /* constructor(view?: User) {
        super()
        if(view != undefined){
            this.firstName = view.firstName
            this.lastName = view.lastName
            this.email = view.email
            this.mobile = view.mobile
            this.address = view.address
            this.cityName = view.cityName;
            this.landmark = view.landmark
            this.pinCode = view.pinCode
            this.stateName = view.stateName
            this.hasLoggedIn = view.hasLoggedIn
            this.verified = view.verified
            this.verifyTokenUsed = view.verifyTokenUsed
            this.name = view.name
            this.typeId = view.typeId
            this.userView = view.userView
            this.active = view.active
            this.logo = view.logo
            this.stateView = view.stateView
            this.area = view.area
            this.cityView = view.cityView
            this.pincode = view.pincode
            this.value = view.value
            this.userName = view.userName
            this.locationView = view.locationView
            this.clientView = view.clientView
            this.roleViews = view.roleViews
        }
    } */

}
