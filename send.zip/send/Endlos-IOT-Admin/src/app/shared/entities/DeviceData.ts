import { BaseEntity } from './BaseEntity';

export class DeviceData extends BaseEntity {
    plus!: string;
    analog1!: string;
    analog2!: string;
    turbodity!: string;
    chlorine!: string;
    dateCreate!: number;

}