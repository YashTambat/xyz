import { KeyValue } from 'src/app/common/interfaces/entities/entity';
import { BaseEntity } from './BaseEntity';

export class Alarm extends BaseEntity {
    name!: string;
    gid!: string;
    code!: string;
    mqttHost!: string;
    mac!: string;
    ipadd!: string;
    location!: string;
    port!: KeyValue;
    key!: number;
    value!: string;
    clientName!: string;
}