import { AfterViewInit, Component, ElementRef, Input, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { AnimationOptions, AnimationLoader } from 'ngx-lottie';

@Component({
    selector: 'app-dialog-box',
    templateUrl: './dialog-box.component.html',
    providers: [AnimationLoader]
})
export class DialogBoxComponent implements AfterViewInit {
    @ViewChild('openSuccessPopup') openSuccessPopup!: TemplateRef<ElementRef>;
    @Input() title = '';
    @Input() content = '';
    @Input() url: string | undefined;
    @Input() timer = 0;
    options: AnimationOptions = {
        path: 'assets/animation/thank-you-gif.json',
    };

    constructor(public dialog: MatDialog, private router: Router) {}

    ngAfterViewInit(): void {
        const dialogRef = this.dialog.open(this.openSuccessPopup);
        setTimeout(() => {
            dialogRef.close();
            this.router.navigate([this.url]);
        }, this.timer);
    }
}
