import { BreakpointObserver, BreakpointState } from '@angular/cdk/layout';
import { Component, EventEmitter, Output, Input, OnInit, ViewChild, ElementRef, Renderer2, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { JwtHelperService } from '@auth0/angular-jwt';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { KeyValue } from 'src/app/common/interfaces/entities/entity';
import { ApiUrl, AppUrlConstant, Url } from 'src/app/constant/app-url';
import { ChangePasswordComponent } from 'src/app/private/change-password/change-password.component';
import { PublicService } from 'src/app/public/public.service';
import { SnackBarService } from '../services/snackbar.service';
import { BreadcrumbService } from '../services/breadcrumb.service';
import { HeaderFilterMenuComponent } from '../header-filter-menu/header-filter-menu.component';
import { User } from '../../entities/User';
import { MatBottomSheet } from '@angular/material/bottom-sheet';
import { HttpService } from 'src/app/services/http.service';
import { ListResponse } from 'src/app/common/interfaces/response';
import * as _ from 'lodash';
import Utils from 'src/app/public/utils/utils';
import { DataServices } from 'src/app/services/data.service';

@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    providers: [PublicService],
})
export class HeaderComponent implements OnInit, AfterViewInit {
    @Input() showResponsive!: boolean;
    @Input() isExpanded!: boolean;
    @Output() responsiveFlag = new EventEmitter();
    @Output() expandedFlag = new EventEmitter();
    @ViewChild('darkModeSwitch', { read: ElementRef }) element: ElementRef | undefined;

    userView = new User();
    breadcrumbs!: KeyValue[];
    checked!: boolean;
    disabled = false;
    isOpen = false;
    isUserRole = false;
    clients: any[] = [];
    isSelectedClient: number;

    constructor(
        private breakpointObserver: BreakpointObserver,
        public router: Router,
        public jwtHelper: JwtHelperService,
        private snackbarService: SnackBarService,
        private publicService: PublicService,
        private modalService: NgbModal,
        private breadcrumbService: BreadcrumbService,
        private renderer: Renderer2,
        private _bottomSheet: MatBottomSheet,
        private httpService: HttpService,
        private dataServices: DataServices
    ) { }

    ngOnInit(): void {
        this.breadcrumbService.pageHeaderTitle.subscribe(title => (this.breadcrumbs = title));
        this.userView = Utils.getUserView();;
        const themeData: any = localStorage.getItem('theme');
        this.checked = themeData === 'light' ? false : true;
        themeData ? '' : localStorage.setItem('theme', 'dark');
        /* if (_.find(this.userView.roleViews, r => r.typeId.key !== 3)) {
            //this.getLocations();
            this.isUserRole = false;
        } else {
            this.isUserRole = true;
        } */
    }

    ngAfterViewInit(): void {
        this.setIcon();
    }

    getLocations() {
        const data: any = {};
        if (this.userView.clientView && this.userView.clientView.id) {
            data.clientView = { id: this.userView.clientView.id }
        }
        const params = `start=0&recordSize=100`;
        this.httpService.postAuth<ListResponse>(`${ApiUrl.LOCATION_SEARCH}?${params}`, data, true).then((listResponse: ListResponse) => {
            this.clients = listResponse.list;
            this.isSelectedClient = this.clients.length > 0 ? this.clients[0].id : null;
            this.onClientChange();
        });
    }

    sideNav() {
        this.breakpointObserver.observe(['(min-width: 0) and (max-width: 767px)']).subscribe((result: BreakpointState) => {
            if (result.matches) {
                this.showResponsive = true;
            }
        });
        this.breakpointObserver.observe(['(min-width: 768px) and (max-width: 991px)']).subscribe((result: BreakpointState) => {
            if (result.matches && !this.isExpanded) {
                this.showResponsive = true;
            }
            if (result.matches && this.isExpanded) {
                this.showResponsive = false;
            }
        });
        this.breakpointObserver.observe(['(min-width: 992px)']).subscribe((result: BreakpointState) => {
            if (result.matches && !this.isExpanded) {
                this.showResponsive = true;
            }
            if (result.matches && this.isExpanded) {
                this.showResponsive = false;
            }
        });
        this.isExpanded = !this.isExpanded;
        this.responsiveFlag.emit(this.showResponsive);
        this.expandedFlag.emit(this.isExpanded);
    }

    onLogout() {
        // localStorage.clear();
        // sessionStorage.clear();
        // this.router.navigate([AppUrlConstant.PUBLIC]);
        if (this.jwtHelper.isTokenExpired(localStorage.getItem('auth-token') as string)) {
            this.router.navigate([AppUrlConstant.PUBLIC]);
            const themeData: any = localStorage.getItem('theme');
            localStorage.clear();
            localStorage.setItem('theme', themeData);
            this.snackbarService.successSnackBar('You have successfully logged out.');
        } else {
            this.publicService.logout().then(response => {
                this.router.navigate([AppUrlConstant.PUBLIC]);
                const themeData: any = localStorage.getItem('theme');
                localStorage.clear();
                localStorage.setItem('theme', themeData);
                this.snackbarService.successSnackBar(response.message);
            });
        }
    }

    changePassword() {
        this.modalService.open(ChangePasswordComponent, { backdrop: 'static', size: 'md', centered: true });
    }

    setIcon() {
        if (this.element) {
            const targetSpan: HTMLElement = this.element.nativeElement.querySelector('.mdc-switch__icons');
            while (targetSpan.firstChild) {
                targetSpan.firstChild.remove();
            }
            const elem = this.renderer.createElement('mat-icon');
            const icon = this.checked ? 'light_mode' : 'dark_mode';
            elem.setAttribute('class', 'mat-icon notranslate material-icons mat-icon-no-color light-mode-switch-icon');
            elem.textContent = icon
            targetSpan.appendChild(elem);
        }
    }

    // changeTheme(event: any) {
    //     this.checked = event.checked;
    //     if(this.checked) {
    //         this.renderer.addClass(document.body, 'dark-theme');
    //         this.renderer.removeClass(document.body, 'light-theme');
    //         localStorage.setItem('theme', 'dark');
    //     }
    //     else {
    //         this.renderer.addClass(document.body, 'light-theme');
    //         this.renderer.removeClass(document.body, 'dark-theme');
    //         localStorage.setItem('theme', 'light');
    //     }
    //     this.setIcon();
    // }

    openFilterMenu() {
        const modalData = this._bottomSheet.open(HeaderFilterMenuComponent, { disableClose: true });
        modalData.instance.clients = this.clients;
    }

    myProfile() {
        this.router.navigate([Url.MY_PROFILE]);
    }

    onClientChange() {
        const client = this.clients.find(a => a.id == this.isSelectedClient)
        if (client) this.dataServices.clientDataSubject.next(client);
    }
}
