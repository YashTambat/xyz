import { BreakpointObserver, BreakpointState } from '@angular/cdk/layout';
import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatBottomSheet } from '@angular/material/bottom-sheet';

@Component({
  selector: 'app-header-filter-menu',
  templateUrl: './header-filter-menu.component.html',
})
export class HeaderFilterMenuComponent implements OnInit {
  @Input() clients!: any[];
  filterForm: FormGroup;
  clicked = false;

  constructor(
    private fb: FormBuilder,
    private breakpointObserver: BreakpointObserver,
    private _bottomSheet: MatBottomSheet
  ) {
    this.filterForm = this.fb.group(
      {
        client: [null],
        location: [null],
      }
    );
  }

  ngOnInit(): void {
    this.breakpointObserver.observe(['(min-width: 768px)']).subscribe((result: BreakpointState) => {
      if (result.matches) {
        this._bottomSheet.dismiss();
      }
    });
  }

  onSubmit() {
    console.log(this.filterForm.value);
  }

  closeModal() {
    this._bottomSheet.dismiss();
  }
}