import { AfterViewInit, Component, Inject, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import * as _ from 'lodash';
import { combineLatest, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { CustomZingChartAngularComponent } from 'zingchart';
import { ChartQuery } from '../../akita/chart';
import { ChartWrapperService, CHART_WRAPPER_SERVICE } from '../../chart-services/chart-wrapper-service';
import { GraphsetData, ZingData } from '../../zing-data';

@Component({
    selector: 'app-line-chart',
    template: `<zingchart-angular
                    [id]="chartId"
                  width="100%"
                  #lineChart
                  [config]="chartConfig"
              ></zingchart-angular>`,
})
export class LineChartComponent implements AfterViewInit, OnDestroy, OnInit {


    @ViewChild('lineChart') areaChart: CustomZingChartAngularComponent;
    areaChartData: GraphsetData;
    chartId: string;
    readonly DEFAULT_HEIGHT = 266;
    private unsubscribe = new Subject<void>();
    @Input() chartConfig = {
        "type": "line",
         "hideprogresslogo": true,
        "scaleY": {
            "markers": []
        },
        "gui": {
            "contextMenu": {
                "empty": true
            }
        },
        "noData": {
            "text": "Currently there is no data in the chart",
            "fontSize": 18
        },
        "plotarea": {
            "margin": "dynamic 45 60 dynamic"
        },
        "scale-x": {
            "min-value": 1711391400000,
            "max-value": 1711476900000,
            "step": 900000,
            "transform": {
                "type": "date",
                "all": "%D, %d %M<br />%h:%i %A",
                "item": {
                    "visible": false
                }
            },
            "label": {
                "visible": false
            },
            "minor-ticks": 0
        },
        "crosshair-x": {
            "line-color": "#efefef",
            "plot-label": {
                "border-radius": "5px",
                "border-width": "1px",
                "border-color": "#f6f7f8",
                "padding": "10px",
                "font-weight": "bold"
            },
            "scale-label": {
                "font-color": "#000",
                "background-color": "#f6f7f8",
                "border-radius": "5px"
            }
        },
        "tooltip": {
            "visible": false
        },
        "plot": {
            "highlight": true,
            "tooltip-text": "%t views: %v<br>%k",
            "shadow": 0,
            "line-width": "2px",
            "marker": {
                "type": "circle",
                "size": 3
            },
            "highlight-state": {
                "line-width": 3
            }
        },
        "series": []
    }
    constructor(
        @Inject(CHART_WRAPPER_SERVICE) private chartWrapperService: ChartWrapperService,
        private chartQuery: ChartQuery,
    ) { }

    ngOnInit() {
        const id = this.chartWrapperService.getChartEntityId();
        this.chartId=id;
        const chartRawData$ = this.chartQuery.getChartRawDataObservable(id);
        const hasPlotTotal$ = this.chartQuery.getPlotObservable(id);
        combineLatest([chartRawData$, hasPlotTotal$])
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(([chartRawData, hasPlotTotal]) => {
                if (chartRawData) {
                    this.chartWrapperService.setHeight(this.DEFAULT_HEIGHT);
                }
            });
    }

    ngAfterViewInit(): void {
        this.chartWrapperService.chartType = this.areaChart;
        this.chartWrapperService.setHeight(this.DEFAULT_HEIGHT);
        document.getElementById(this.chartId+'-license-text')?.classList.add('d-none');
    }



    ngOnDestroy(): void {
        this.unsubscribe.next();
        this.unsubscribe.complete();
    }
}
