import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { ChartWrapperComponent } from './chart-wrapper/chart-wrapper.component';
import { ChartButtonGroupComponent } from './chart-button-group/chart-button-group.component';
import { ChartLegendComponent } from './chart-legend/chart-legend.component';
import { ChartActionSectionComponent } from './chart-action-section/chart-action-section.component';
import { ColumnChartComponent } from './chart/column-chart/column-chart.component';
import { ZingchartAngularModule } from 'zingchart-angular';
import { LineAreaChartComponent } from './chart/line-area-chart/line-area-chart.component';
import { LineChartComponent } from './chart/line-chart/line-area-chart.component';


const routes: Routes = [];
@NgModule({
  declarations: [
    ChartWrapperComponent,
    ChartButtonGroupComponent,
    ChartLegendComponent,
    ChartActionSectionComponent,
    ColumnChartComponent,
    LineAreaChartComponent,
    LineChartComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    ZingchartAngularModule
  ],
  exports:[
    ChartWrapperComponent,
    ColumnChartComponent,
    LineAreaChartComponent,
    LineChartComponent
  ]
})
export class ZingChartModule { }
