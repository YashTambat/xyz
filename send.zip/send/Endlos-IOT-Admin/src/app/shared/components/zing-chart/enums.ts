export enum ChartType {
    Line = 1,
    Bar = 2,
    Pie = 3,
    StackedColumn = 4,
    LineArea = 5,
    Column = 6,
    HeatMap = 7,
}