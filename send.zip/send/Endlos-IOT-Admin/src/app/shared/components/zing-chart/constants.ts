import { ChartType } from "./enums";

export class Constants {

    public static readonly reportChart = 'reportChart';
    public static readonly DashboardLevelChart = 'dashboardLevelChart';
    public static readonly DashboardPressureChart = 'dashboardPressureChart';
    public static readonly DashboardFlowChart = 'dashboardFlowChart';
    
    public static chartTypeSelectors = [
        {
            type: ChartType.Pie,
            name: 'Pie',
            icon: 'pie_chart',
        },
        {
            type: ChartType.StackedColumn,
            name: 'Stacked Column Chart',
            icon: 'stacked_bar_chart',
        },
        {
            type: ChartType.Column,
            name: 'Column Chart',
            icon: 'bar_chart',
        },
        {
            type: ChartType.LineArea,
            name: 'Line Area Chart',
            icon: 'area_chart',
        },
        {
            type: ChartType.Line,
            name: 'Line Chart',
            icon: 'multiline_chart',
        },
        {
            type: ChartType.HeatMap,
            name: 'Heat Map Chart',
            icon: 'widgets',
        },
    ];

    public static dateFormats = {
        dayMonthYearUnderScored: 'yy_MM_DD',
        dateTimeUTC: 'YYYY-MM-DDTHH:mm:ssZ'
    };
}