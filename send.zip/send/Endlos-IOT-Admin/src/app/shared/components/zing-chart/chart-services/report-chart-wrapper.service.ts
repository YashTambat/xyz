import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { ChartService, ChartQuery } from '../akita/chart';
import { ChartInitData } from '../chart-init-data';
import { Constants } from '../constants';
import { ChartType } from '../enums';
import { ChartActionSectionSetup, ChartButtonGroupSetup } from '../interface';
import { ZingData } from '../zing-data';

import { ChartWrapperService } from './chart-wrapper-service';

@Injectable()
export class ReportChartWrapperService extends ChartWrapperService {
    public drillDownChartType: ChartType;
    public chartName = 'report chart';
    public chartStoreKey = Constants.reportChart;

    constructor(
        protected override router: Router,
        protected override chartService: ChartService,
        protected override chartQuery: ChartQuery,
    ) {
        super(router, chartService, chartQuery);
    }
    getChartButtonGroupConfig(): ChartButtonGroupSetup {
        this.chartEntity = this.getChartEntity();
        return {
            hasCopyButton: true,
            chartTypeSelectors: this.getChartTypeSelectors([ChartType.LineArea, ChartType.StackedColumn]),
            menuButton: {
                aggregateSection: {
                    hasButton: false,
                },
                totalSection: {
                    hasButton: true,
                    isSelected: this.chartEntity?.hasPlotTotal ?? false,
                },
                legendSection: {
                    hasButton: true,
                    isSelected: true,
                },
                hasShowGuideButton: false,
                hasDownloadPDFButton: true,
                hasDownloadCSVButton: true,
                hasDownloadXLSButton: true,
                hasPrintButton: true,
            },
        };
    }

    getChartActionSectionConfig(): ChartActionSectionSetup {
        return { hasViewButton: false };
    }

    getInitialData(): ZingData {
        return ChartInitData.getColumnChartInitData();
    }
}
