import { ChangeDetectorRef, Component, EventEmitter, Input, Output } from '@angular/core';
import { BreadcrumbService } from '../services/breadcrumb.service';
import { KeyValue } from 'src/app/common/interfaces/entities/entity';
import { FormBuilder, FormGroup } from '@angular/forms';
import { AppUrlConstant } from 'src/app/constant/app-url';
import * as _ from 'lodash';
import { ListContainer } from 'src/app/Interface/list-container';

@Component({
  selector: 'app-top-panel',
  templateUrl: './top-panel.component.html',
  styleUrls: ['./top-panel.component.scss']
})
export class TopPanelComponent {
  @Input() breadcrumbs: KeyValue[] = [];
  @Input() hasSearch!: boolean;
  @Input() hasFilter!: boolean;
  @Input() hasFilterBox!: boolean;
  @Input() hasDoubleLayout!: boolean;
  @Input() hasMapLayout!: boolean;
  @Input() hasAdd!: boolean;
  @Input() viewPage!: boolean;
  @Input() hasEdit!: boolean;
  @Input() hasDelete!: boolean;
  @Input() filterTitle!: string;
  @Input() searchedData!: string;
  @Input() hasFilterMenu!: boolean;
  @Input() buttonName = 'Add';
  @Input() navigationButtonList:{id: number, name: string, active: boolean}[] = [];
  @Input() listContainer!: ListContainer;
  @Output() openFilterBox = new EventEmitter();
  @Output() searched = new EventEmitter();
  @Output() isEdit = new EventEmitter();
  @Output() isDelete = new EventEmitter();
  @Output() listView = new EventEmitter();
  @Output() gridView = new EventEmitter();
  @Output() mapView = new EventEmitter();
  @Output() navigationButtonClick = new EventEmitter();
  searchForm: FormGroup;
  appUrlConstant = AppUrlConstant;
  isList = false;
  isMapView = false;

  constructor(
    private breadcrumbService: BreadcrumbService,
    private fb: FormBuilder,
    private cn :ChangeDetectorRef
  ) {
    this.breadcrumbService.changePageTitle(this.breadcrumbs);
    this.searchForm = this.fb.group({
      search: null,
    });
    const viewTypeData = sessionStorage.getItem('viewType');
    if(viewTypeData) {
      this.changeListView(viewTypeData);
    }
  }

  toggleFilter() {
    this.openFilterBox.emit();
  }

  onSearch() {
    this.searched.emit(this.searchForm.value.search);
  }

  changeListView(listType: string) {
    listType === 'grid' ? this.gridView.emit() : this.listView.emit();
    this.isList = listType === 'grid' ? false : true;
    sessionStorage.setItem('viewType', listType);
  }

  onMapdView(value: string) {
    this.isMapView = value !== 'map' ? false : true;
    this.mapView.emit(value)
    this.cn.detectChanges();
    sessionStorage.setItem('mapType', value);
  }
  onChangeNavigation(data:any) {
    _.map(this.navigationButtonList,n=>n.active = false);
    data.active = true;
    this.navigationButtonClick.emit(this.navigationButtonList)
    console.log(this.navigationButtonList) 
  }

  showFilterBox = false;
  showFilter() {
    // Toggle the visibility of the edit-del-icon
    this.showFilterBox  = !this.showFilterBox;
  }
  
}