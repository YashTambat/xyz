import { AfterViewInit, Component, ElementRef, Input, Output, TemplateRef, ViewChild, EventEmitter } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';

@Component({
    selector: 'app-active-inactive-dialog-box',
    templateUrl: './active-inactive-dialog-box.component.html',
})
export class ActiveInactiveDialogBoxComponent implements AfterViewInit {
    @ViewChild('openSuccessPopup') openSuccessPopup!: TemplateRef<ElementRef>;
    @Input() heading!: string;
    @Input() description!: string;
    @Output() dialogBox = new EventEmitter();
    @Output() dialogBoxResponse = new EventEmitter();

    constructor(public dialog: MatDialog) {}

    ngAfterViewInit(): void {
        const dialogRef = this.dialog.open(this.openSuccessPopup);
        dialogRef.afterClosed().subscribe(() => {
            this.dialogBox.emit();
        });
    }

    onSubmit(event: boolean) {
        this.dialogBoxResponse.emit(event);
    }
}