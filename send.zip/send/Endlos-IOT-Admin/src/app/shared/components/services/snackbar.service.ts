import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';

@Injectable({
    providedIn: 'root',
})
export class SnackBarService {
    readonly DEFAULT_DISPLAY_SECONDS = 4000;
    constructor(private matSnackBar: MatSnackBar) {}
    public errorSnackBar(message: string) {
        this.matSnackBar.open(message, '×', {
            duration: this.DEFAULT_DISPLAY_SECONDS,
            panelClass: ['error-snack-bar'],
        });
    }

    public successSnackBar(message: string) {
        this.matSnackBar.open(message, '×', {
            duration: this.DEFAULT_DISPLAY_SECONDS,
            panelClass: ['success-snack-bar'],
        });
    }
}
