import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { KeyValue } from 'src/app/common/interfaces/entities/entity';

@Injectable({
    providedIn: 'root',
})
export class BreadcrumbService {
    private pageTitle = new BehaviorSubject<KeyValue[]>([{ key: '', value: '' }]);
    pageHeaderTitle = this.pageTitle.asObservable();

    changePageTitle(changedPageTitle: KeyValue[]) {
        this.pageTitle.next(changedPageTitle);
    }
}
