import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';
import { KeyValue } from 'src/app/common/interfaces/entities/entity';

@Component({
    selector: 'app-breadcrumb',
    templateUrl: './breadcrumb.component.html',
    styleUrls: ['./breadcrumb.component.scss'],
})
export class BreadcrumbComponent {
    @Input() breadcrumbs: KeyValue[] = [];

    constructor(private router : Router) {}

    changeRouting(breadcrumb: string) {
        this.router.navigate([breadcrumb]);
    }
}
