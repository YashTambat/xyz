import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-common-public-designed-by',
  templateUrl: './common-public-designed-by.component.html'
})
export class CommonPublicDesignedBy implements OnInit {

  theme: any = '';

  ngOnInit(): void {
    this.theme = localStorage.getItem('theme');
  }

}