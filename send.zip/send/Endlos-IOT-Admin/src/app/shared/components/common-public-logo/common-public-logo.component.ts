import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-common-public-logo',
  templateUrl: './common-public-logo.component.html'
})
export class CommonPublicLogoComponent implements OnInit {

  theme: any = '';

  ngOnInit(): void {
    this.theme = localStorage.getItem('theme');
  }

}