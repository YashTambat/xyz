import { Url } from 'src/app/constant/app-url';
import { MatSidenav } from '@angular/material/sidenav';
import { Component, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { BreakpointObserver, BreakpointState } from '@angular/cdk/layout';
import { Router } from '@angular/router';
import { ActiveMenuService } from '../services/active-menu.service';
import { SideBarMenuList } from '../../enums/side-menu';
import { Menu } from '../../entities/Menu';
import * as _ from 'lodash';
import Utils from 'src/app/public/utils/utils';

@Component({
    selector: 'app-sidebar',
    templateUrl: './sidebar.component.html'
})
export class SidebarComponent implements OnInit {
    @ViewChild('sidenav') sidenav?: MatSidenav;
    @Output() isExpandedFlag = new EventEmitter();
    @Output() showResponsiveFlag = new EventEmitter();

    isExpanded = true;
    showSubmenu = false;
    showResponsive = false;
    showSubSubMenu = false;
    url = Url;
    currentUrl!: string;

    menuList:any = [];

    constructor(private breakpointObserver: BreakpointObserver, private router: Router, private activeMenuService: ActiveMenuService) {}

    ngOnInit(): void {
        const userView = Utils.getUserView();;
        const moduleIds = _.map(userView.moduleViews, 'id')
        this.menuList = _.filter(SideBarMenuList, s => moduleIds.includes(s.moduleId))
        this.breakpointObserver.observe(['(min-width: 0px) and (max-width: 767px)']).subscribe((result: BreakpointState) => {
            if (result.matches) {
                this.isExpanded = true;
            }
        });
        this.breakpointObserver.observe(['(min-width: 768px) and (max-width: 991px)']).subscribe((result: BreakpointState) => {
            if (result.matches) {
                this.isExpanded = false;
            }
        });
        this.breakpointObserver.observe(['(min-width: 992px)']).subscribe((result: BreakpointState) => {
            if (result.matches) {
                this.isExpanded = true;
                this.showResponsive = true;
            }
        });
        this.activeMenuService.activeMenu.subscribe(() => {
            const routerList = this.router.url.split('/');
            if(routerList.length > 2) {
                this.activeParentMenu(routerList[1] + '/', routerList[1] + '/' + routerList[2]);
            }
            else {
                this.activeParentMenu(this.router.url.split('/')[1] + '/');
            }
        });
    }

    activeParentMenu(activeMenu: string, submenu?: string) {
        this.menuList.forEach((menuData: any) => {
            if(menuData.routerLink === activeMenu) {
                menuData.active = true;
            }
            else {
                menuData.active = false;
            }
            if(menuData.children) {
                menuData.children.forEach((element: any) => {
                    if(element.routerLink === submenu) {
                        element.active = true;
                    }
                    else {
                        element.active = false;
                    }
                });
            }
        });
    }

    openMenu(menu: Menu, submenu?: Menu) {
        this.activeParentMenu(menu.routerLink, submenu?.routerLink);
        this.breakpointObserver.observe(['(min-width: 0) and (max-width: 767px)']).subscribe((result: BreakpointState) => {
            if (result.matches) {
                this.isExpanded = true;
            }
        });
    }

    mouseenter() {
        this.breakpointObserver.observe(['(min-width: 0) and (max-width: 767px)']).subscribe((result: BreakpointState) => {
            if (result.matches) {
                this.isExpanded = false;
            }
        });
        this.breakpointObserver.observe(['(min-width: 768px) and (max-width: 991px)']).subscribe((result: BreakpointState) => {
            if (result.matches) {
                this.isExpanded = true;
            }
        });
        this.breakpointObserver.observe(['(min-width: 992px)']).subscribe((result: BreakpointState) => {
            if (result.matches) {
                this.isExpanded = true;
            }
        });
    }

    mouseleave() {
        this.breakpointObserver.observe(['(min-width: 0) and (max-width: 767px)']).subscribe((result: BreakpointState) => {
            if (result.matches && !this.showResponsive) {
                this.isExpanded = false;
            }
        });
        this.breakpointObserver.observe(['(min-width: 768px) and (max-width: 991px)']).subscribe((result: BreakpointState) => {
            if (result.matches && !this.showResponsive) {
                this.isExpanded = false;
            }
        });
        this.breakpointObserver.observe(['(min-width: 992px)']).subscribe((result: BreakpointState) => {
            if (result.matches && !this.showResponsive) {
                this.isExpanded = false;
            }
        });
    }

    responsiveFlag(event: any) {
        this.showResponsive = event;
    }

    expandedFlag(event: any) {
        this.isExpanded = event;
    }
}
