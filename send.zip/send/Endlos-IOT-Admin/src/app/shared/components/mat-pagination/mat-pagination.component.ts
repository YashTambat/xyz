import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Pagination } from 'src/app/common/interfaces/entities/entity';

@Component({
    selector: 'app-mat-pagination',
    templateUrl: './mat-pagination.component.html'
})
export class MatPaginationComponent {
    @Input() pagination!: Pagination;
    @Output() changedPagination = new EventEmitter();

    onPageSizeChange() {
        this.pagination.pageIndex = 0;
        this.changedPagination.emit(this.pagination);
    }

    onPageChange(pageEvent: any) {
        this.pagination.pageIndex = pageEvent.page;
        this.pagination.pageSize = pageEvent.rows;
        this.changedPagination.emit(this.pagination);
      }
}
