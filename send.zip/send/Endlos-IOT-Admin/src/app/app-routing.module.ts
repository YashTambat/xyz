import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PublicComponent } from './public/public.component';
import { AuthGuard } from './auth-guard';
import { AppUrlConstant } from './constant/app-url';
import { ErrorPageComponent } from './error-page/error-page.component';
import { ErrorMessage } from './constant/error-message';
import { PrivateComponent } from './private/private.component';

const routes: Routes = [
  {
    path: '',
    component: PublicComponent,
    children: [
        { path: '', redirectTo: 'public', pathMatch: 'full' },
        {
            path: AppUrlConstant.PUBLIC,
            canActivate: [AuthGuard],
            loadChildren: () => import('src/app/public/public.module').then(m => m.PublicModule),
        },
    ],
  },
  {
    path: '',
    component: PrivateComponent,
    children: [
      { 
        path: '',
        loadChildren: () => import('src/app/private/private.module').then(m => m.PrivateModule),
        canActivate: [AuthGuard]
      },
    ],
  },
  {
    path: AppUrlConstant.UNAUTHORIZED,
    component: ErrorPageComponent,
    data: {
        title: '403',
        shortDescription: ErrorMessage.unauthorized,
        longDescription: ErrorMessage[403],
    },
  },
  {
      path: '**',
      component: ErrorPageComponent,
      data: {
          title: '404',
          shortDescription: ErrorMessage.pageNotFound,
          longDescription: ErrorMessage[404],
      },
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
