import { Component } from '@angular/core';

@Component({
    selector: 'app-public',
    templateUrl: './public.component.html',
})
export class PublicComponent {}
