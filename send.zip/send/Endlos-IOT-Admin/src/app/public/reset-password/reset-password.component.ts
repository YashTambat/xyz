import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Component, ElementRef, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AppUrlConstant } from 'src/app/constant/app-url';
import { ConfirmPasswordValidator } from 'src/app/shared/validator/confirm-password.validator';
import { AnimationOptions } from 'ngx-lottie';
@Component({
    selector: 'app-reset-password',
    templateUrl: './reset-password.component.html'
})
export class ResetPasswordComponent {
    hide = true;
    hideConfirmPass = true;
    clicked = false;
    blockUI = false;
    isDialogBoxOpen = false;
    title = 'Thank You';
    content = 'You have successfully changed your password';
    redirectTo = `${AppUrlConstant.PUBLIC}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.LOGIN}`;
    timer = 2300;
    resetPasswordForm: FormGroup;
    options: AnimationOptions = {
        path: 'assets/animation/create-new-password-gif.json',
    };

    @ViewChild('openSuccessPopup') openSuccessPopup!: TemplateRef<ElementRef>;

    constructor(public dialog: MatDialog, private fb: FormBuilder) {
        this.resetPasswordForm = this.fb.group(
            {
                password: new FormControl(null, [Validators.required]),
                confirmPassword: new FormControl(null, [Validators.required]),
            },
            {
                validator: ConfirmPasswordValidator('password', 'confirmPassword'),
            }
        );
    }

    onSubmit() {
        this.blockUI = true;
        this.isDialogBoxOpen = true;
    }
}
