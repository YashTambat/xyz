export default class Utils {
    static getUserView() { 
        const userData: any = localStorage.getItem('userView');
        return JSON.parse(userData);
    }
    static fromEpochToDate(epoch: number): Date {
        return new Date(epoch * 1000);
    }
    static fromDateToEpochUnix(date: Date): number {
        return Math.floor(new Date(date).getTime());
    }
    static fromDateToEpoch(date: Date): number {
        return Math.floor(new Date(date).getTime() / 1000);
    }
    static getUpcomingMinutesEpoch(minutes = 0): number {
        return Math.floor(Date.now() / 1000 + minutes * 60);
    }
    static removeSpecialCharacter(value: string): string {
        const newVal = value.replace(/[^\w\s]/gi, ' ');
        return newVal;
    }
    static idComparer(o1: any, o2: any): boolean {
        if (o1 && o2) {
            return o1 && o2 ? o1.id === o2.id : o2 === o2;
        } else {
            return false;
        }
    }

    static keyComparer(o1: any, o2: any): boolean {
        if (o1 && o2) {
            return o1 && o2 ? o1.key === o2.key : o2 === o2;
        } else {
            return false;
        }
    }

    static valueComparer(o1: any, o2: any): boolean {
        if (o1 && o2) {
            return o1 && o2 ? o1 === o2 : o2 === o2;
        } else {
            return false;
        }
    }
}
