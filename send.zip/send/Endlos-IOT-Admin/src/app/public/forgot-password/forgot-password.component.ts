import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Url } from 'src/app/constant/app-url';
import { AnimationOptions } from 'ngx-lottie';

@Component({
    selector: 'app-forgot-password',
    templateUrl: './forgot-password.component.html'
})
export class ForgotPasswordComponent {
    forgotPasswordForm: FormGroup;
    loginUrl: string = Url.LOGIN;
    blockUI = false;
    clicked = false;
    options: AnimationOptions = {
        path: 'assets/animation/forgot-password-gif.json',
    };

    constructor(private router: Router, private fb: FormBuilder) {
        this.forgotPasswordForm = this.fb.group({
            email: [null, Validators.required]
        });
    }

    onSubmit() {
        this.blockUI = true;
        this.router.navigate([Url.VERIFICATION]);
    }
}
