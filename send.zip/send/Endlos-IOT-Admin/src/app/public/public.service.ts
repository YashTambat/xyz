import { Injectable } from '@angular/core';
import { ViewResponse } from 'src/app/common/interfaces/response';
import { ApiUrl } from 'src/app/constant/app-url';
import { HttpService } from 'src/app/services/http.service';
import { User } from '../shared/entities/User';

@Injectable()
export class PublicService {
    constructor(private httpService: HttpService) {}

    login(data: User) {
        return this.httpService.postAuth<ViewResponse>(`${ApiUrl.LOGIN_API}`, data).then((viewResponse: ViewResponse) => {
            return viewResponse;
        });
    }

    logout() {
        return this.httpService.getAuth<ViewResponse>(`${ApiUrl.LOGOUT_API}`).then((viewResponse: ViewResponse) => {
            return viewResponse;
        });
    }
}
