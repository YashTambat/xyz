import { Component, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { NgOtpInputComponent } from 'ng-otp-input';
import { AppUrlConstant, Url } from 'src/app/constant/app-url';
import { AnimationOptions } from 'ngx-lottie';

@Component({
    selector: 'app-verification',
    templateUrl: './verification.component.html'
})
export class VerificationComponent {
    @ViewChild(NgOtpInputComponent, { static: false }) ngOtpInput!: NgOtpInputComponent;
    readonly RESEND_OTP_TIMER: number = 1000;
    timeLeft = 0;
    blockUI = false;
    clicked = false;
    options: AnimationOptions = {
        path: 'assets/animation/verification-gif.json',
    };

    constructor(private router: Router) {
        this.timer();
    }

    onOtpChange(otp: string) {
        if (otp.length === 4) {
            this.router.navigate([`${AppUrlConstant.PUBLIC}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.RESET_PASSWORD}`]);
        }
    }

    timer() {
        this.timeLeft = 59;
        const interval = setInterval(() => {
            this.timeLeft--;
            if (this.timeLeft === 0) {
                clearInterval(interval);
            }
        }, this.RESEND_OTP_TIMER);
    }

    resendOtp() {
        this.timer();
    }

    onSubmit() {
        this.blockUI = true;
        this.router.navigate([Url.RESET_PASSWORD]);
    }
}
