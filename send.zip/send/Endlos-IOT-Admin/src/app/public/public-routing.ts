import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppUrlConstant } from '../constant/app-url';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { LoginComponent } from './login/login.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { VerificationComponent } from './verification/verification.component';
import { AuthGuard } from '../auth-guard';

const routes: Routes = [
    { path: '', redirectTo: 'login', pathMatch: 'full' },
    { path: AppUrlConstant.LOGIN, component: LoginComponent, canActivate: [AuthGuard] },
    { path: AppUrlConstant.FORGOT_PASSWORD, component: ForgotPasswordComponent, canActivate: [AuthGuard] },
    { path: AppUrlConstant.VERIFICATION, component: VerificationComponent, canActivate: [AuthGuard] },
    { path: AppUrlConstant.RESET_PASSWORD, component: ResetPasswordComponent, canActivate: [AuthGuard] },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class PublicRouting {}
