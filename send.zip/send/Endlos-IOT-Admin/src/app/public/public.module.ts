import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { LoginComponent } from './login/login.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PublicRouting } from './public-routing';
import { SharedModule } from '../shared/shared.module';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { VerificationComponent } from './verification/verification.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgOtpInputModule } from 'ng-otp-input';
import { LottieModule, AnimationLoader } from 'ngx-lottie';
import player from 'lottie-web';

export function playerFactory() {
    return player;
}
const COMPONENTS = [LoginComponent, ForgotPasswordComponent, ResetPasswordComponent, VerificationComponent];
@NgModule({
    declarations: [...COMPONENTS],
    imports: [CommonModule, PublicRouting, SharedModule, NgOtpInputModule, FormsModule, ReactiveFormsModule, LottieModule.forRoot({ player: playerFactory })],
    providers: [AnimationLoader],
    exports: [...COMPONENTS],
})
export class PublicModule {}
