import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { PublicService } from '../public.service';
import { Url } from './../../constant/app-url';
import { AnimationOptions } from 'ngx-lottie';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    providers: [PublicService],
})
export class LoginComponent {
    hide = true;
    forgotPasswordUrl: string = Url.FORGOT_PASSWORD;
    clicked = false;
    loginForm: FormGroup;
    options: AnimationOptions = {
        path: 'assets/animation/login-gif.json',
    };

    constructor(private router: Router, private publicService: PublicService, private fb: FormBuilder) {
        this.loginForm = this.fb.group({
            loginId: new FormControl(null, [Validators.required]),
            password: new FormControl(null, [Validators.required]),
        });
    }

    onSubmit() {
        if (this.loginForm.invalid) {
            return;
        } else {
            this.clicked = true;
            this.publicService
                .login(this.loginForm.value)
                .then(user => {
                    localStorage.setItem('userView', JSON.stringify(user.view));

                    if (user.accessToken) {
                        localStorage.setItem('auth-token', user.accessToken);
                    }
                    if (user.refreshToken) {
                        localStorage.setItem('refresh-token', user.refreshToken);
                    }
                    this.router.navigate([Url.DASHBOARD]);
                })
                .finally(() => {
                    this.clicked = false;
                });
        }
    }
}
