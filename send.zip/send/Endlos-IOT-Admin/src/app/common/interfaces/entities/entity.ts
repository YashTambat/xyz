export interface Entity {
    id: number;
}

export interface KeyValue {
    key?: number | string;
    value: string;
}
export interface IdName {
    id: number;
    name: string;
}
export interface Pagination {
    pageIndex: number;
    pageSize: number;
    length: number;
    pageSizes: number[];
}

export interface FileView {
    fileId?: string;
    name: string;
    caption: string;
    fileType: string;
}
