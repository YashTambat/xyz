export interface Environment {
    apiUrl: string;
}
