export class PageTitle {
    public static readonly ADD = 'Add ';
    public static readonly EDIT = 'Edit ';
    public static readonly DETAILS = 'Details';
    public static readonly DASHBOARD = 'Dashboard';
    public static readonly MY_PROFILE = 'My Profile';
    public static readonly USER = 'User';
    public static readonly PARAMETER_MAPPING = 'Parameter Mapping';
    public static readonly ALARM = 'Alarm';
    public static readonly GATEWAY = 'Gateway';
    public static readonly DIAGNOSIS_LOG = 'Diagnosis Log';
    public static readonly DEVICE_DIAGNOSIS = 'Device Diagnosis';
    public static readonly DEVICE = 'Device';
    public static readonly SCREEN = 'Screen';
    public static readonly REPORT = 'Report'; 
    public static readonly CLIENT = 'Clients';
    public static readonly LOCATION = 'Location';

    public static readonly GSM_DEVIE_DATA = 'GSM Device Data';
    public static readonly GATEWAY_DEVICE_DATA = 'Gateway Device Data';
    public static readonly ROLE = 'User Role';
    public static readonly ALARM_HISTORY = 'Alarm History';


}
