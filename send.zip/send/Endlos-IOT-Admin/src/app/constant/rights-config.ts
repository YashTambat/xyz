export class RightsConfig{
    public static ADD = {id :1 ,name : "Add"}; //Add, Save
	public static UPDATE = {id : 2,name : "Update"}; //Update, Edit,
	public static VIEW = {id : 3,name : "View"}; //View
	public static DELETE = {id: 4,name:"Delete"};//Delete
	public static ACTIVATION = {id:5,name:"Activation"};//Activation
	public static LIST = {id:6,name:"List"}; //List,Search
	public static DOWNLOAD = {id : 7,name : "Download"};//Download
	public static FILE_UPLOAD = {id : 8,name : "File Upload"};// File Upload
	public static IMPORT = {id : 9,name : "IMPORT"};//Import
}
