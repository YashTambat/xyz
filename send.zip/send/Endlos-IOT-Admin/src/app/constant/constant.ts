export class Constant {
   public static nameLength = 100; 
   public static mediumNameLength = 100; 
   public static maxNameLength = 500;
   public static minPinCodeLength = 4;
   public static maxPinCodeLength = 6;
   public static minMobileNumberLength = 10;
   public static maxMobileNumberLength = 10;
   public static minPasswordLength = 8;
   public static maxPasswordLength = 16;
}

export class Modules {
   public static User = { id: 1, name:"User"};
   public static Role = { id: 2, name:"Role"};
   public static Device = { id: 3, name:"Device"};
   public static Screen = { id: 4, name:"Screen"};
   public static Device_Diagnosis = { id: 5, name:"Device Diagnosis"};
   public static Response_Message = { id: 6, name:"Response Message"};
   public static Dashboard = { id: 7, name:"Dashboard"};
   public static Report = { id: 8, name:"Report"};
   public static System_Setting = { id: 9, name:"System Setting"};
   public static Alarm_History = { id: 10, name:"Alarm History"};

   /* public static Client = {id:10,name:"Client"};
   public static Role = { id: 2, name:"Role"};
   public static Notifcation = { id: 4, name:"Notifcation"};
   public static Location = { id: 9, name:"Location"};
   public static Bannner = { id: 8, name:"Bannner"};
   public static Email_Account = { id: 5, name:"Email Account"};
   public static User = { id: 1, name:"User"};
   public static Sms_Account = { id: 7, name:"Sms Account"};
   public static Response_Message = { id: 6, name:"Response Message"};
   public static Dashboard = { id: 11, name:"Dashboard"};
   public static Report = { id: 12, name:"Report"};
   public static Alarm = { id: 13, name:"Alarm"};
   public static Device = { id: 6, name:"Response Message"};
   public static Gateway = { id: 6, name:"Response Message"}; */
}