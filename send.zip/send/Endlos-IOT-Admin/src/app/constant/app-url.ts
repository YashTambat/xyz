import { environment } from "src/environments/environment";

export class AppUrlConstant {
    public static readonly HOME = '';

    public static readonly URL_SEPARATOR = '/';
    public static readonly PUBLIC = 'public';
    public static readonly PRIVATE = 'private';
    public static readonly UNAUTHORIZED = 'unauthorized';

    public static readonly ADD = 'add';
    public static readonly EDIT = 'edit';
    public static readonly VIEW = 'view';

    public static readonly LOGIN = 'login';
    public static readonly FORGOT_PASSWORD = 'forgot-password';
    public static readonly VERIFICATION = 'verification';
    public static readonly RESET_PASSWORD = 'reset-password';

    public static readonly DASHBOARD = 'dashboard';
    public static readonly MY_PROFILE = 'my-profile';
    public static readonly USERS = 'users';
    public static readonly USER = 'user';
    public static readonly PARAMETER_MAPPING = 'parameter-mapping';
    public static readonly ALARM = 'alarm';
    public static readonly GATEWAY = 'gateway';
    public static readonly DIAGNOSIS = 'diagnosis';
    public static readonly DIAGNOSIS_LOG = 'diagnosis-log';
    public static readonly DEVICE_DIAGNOSIS = 'device-diagnosis';
    public static readonly DEVICES = 'devices';
    public static readonly DEVICE = 'device';
    public static readonly SCREEN = 'screen';
    public static readonly DEVICE_DATA = 'device-data';

    public static readonly REPORT = 'report';
    public static readonly LOCATION = 'location';
    public static readonly SETTING = 'setting';
    public static readonly CLIENTS = 'clients';

    public static readonly USER_ROLE = 'role';
    public static readonly ALARM_HISTORY = 'alarm-history';

}


export class Url {
    private static readonly PUBLIC = `${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.PUBLIC}${AppUrlConstant.URL_SEPARATOR}`;

    public static readonly HOME = `${Url.PUBLIC}${AppUrlConstant.HOME}`;
    public static readonly FORGOT_PASSWORD = `${Url.PUBLIC}${AppUrlConstant.FORGOT_PASSWORD}`;
    public static readonly LOGIN = `${Url.PUBLIC}${AppUrlConstant.LOGIN}`;
    public static readonly VERIFICATION = `${Url.PUBLIC}${AppUrlConstant.VERIFICATION}`;
    public static readonly RESET_PASSWORD = `${Url.PUBLIC}${AppUrlConstant.RESET_PASSWORD}`;

    //dashboard
    public static readonly DASHBOARD = `${AppUrlConstant.DASHBOARD}${AppUrlConstant.URL_SEPARATOR}`;
    public static readonly DASHBOARD_VIEW = `${Url.DASHBOARD}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.VIEW}`;

    //Menu Urls
    public static readonly MY_PROFILE = `${AppUrlConstant.MY_PROFILE}${AppUrlConstant.URL_SEPARATOR}`;
    public static readonly MY_PROFILE_EDIT = `${Url.MY_PROFILE}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.EDIT}`;

    //User Module Urls
    public static readonly USERS = `${AppUrlConstant.USERS}${AppUrlConstant.URL_SEPARATOR}`;
    public static readonly USER = `${AppUrlConstant.USER}${AppUrlConstant.URL_SEPARATOR}`;
    public static readonly USER_ADD = `${Url.USER}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.ADD}`;
    public static readonly USER_EDIT = `${Url.USER}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.EDIT}`;
    public static readonly USER_VIEW = `${Url.USER}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.VIEW}`;

    //Parameter-Mapping Module Urls
    public static readonly PARAMETER_MAPPING = `${AppUrlConstant.PARAMETER_MAPPING}${AppUrlConstant.URL_SEPARATOR}`;
    public static readonly PARAMETER_MAPPING_ADD = `${Url.PARAMETER_MAPPING}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.ADD}`
    public static readonly PARAMETER_MAPPING_EDIT = `${Url.PARAMETER_MAPPING}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.EDIT}`;
    public static readonly PARAMETER_MAPPING_VIEW = `${Url.PARAMETER_MAPPING}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.VIEW}`;


    //Gateway Module Urls
    public static readonly GATEWAY = `${AppUrlConstant.GATEWAY}${AppUrlConstant.URL_SEPARATOR}`;
    public static readonly GATEWAY_ADD = `${Url.GATEWAY}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.ADD}`
    public static readonly GATEWAY_EDIT = `${Url.GATEWAY}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.EDIT}`;
    public static readonly GATEWAY_VIEW = `${Url.GATEWAY}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.VIEW}`;

    //Diagnosis Module Urls
    public static readonly DIAGNOSIS = `${AppUrlConstant.DIAGNOSIS}${AppUrlConstant.URL_SEPARATOR}`;
    public static readonly DIAGNOSIS_LOG = `${Url.DIAGNOSIS}${AppUrlConstant.DIAGNOSIS_LOG}`;
    public static readonly DEVICE_DIAGNOSIS = `${Url.DIAGNOSIS}${AppUrlConstant.DEVICE_DIAGNOSIS}`;

    //Device Module Urls  
    public static readonly DEVICE = `${AppUrlConstant.DEVICE}${AppUrlConstant.URL_SEPARATOR}`;
    public static readonly DEVICE_ADD = `${Url.DEVICE}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.ADD}`;
    public static readonly DEVICE_EDIT = `${Url.DEVICE}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.EDIT}`;
    public static readonly DEVICE_VIEW = `${Url.DEVICE}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.VIEW}`;
    public static readonly DEVICE_DATA = `${AppUrlConstant.DEVICE_DATA}${AppUrlConstant.URL_SEPARATOR}`;

    //Screen Module Urls  
    public static readonly SCREEN = `${AppUrlConstant.SCREEN}${AppUrlConstant.URL_SEPARATOR}`;
    public static readonly SCREEN_ADD = `${Url.SCREEN}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.ADD}`;
    public static readonly SCREEN_EDIT = `${Url.SCREEN}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.EDIT}`;
    public static readonly SCREEN_VIEW = `${Url.SCREEN}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.VIEW}`;

    //Alarm Module Urls
    public static readonly ALARM = `${AppUrlConstant.ALARM}${AppUrlConstant.URL_SEPARATOR}`;
    public static readonly ALARM_VIEW = `${Url.ALARM}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.VIEW}`;

    //Location Module Urls
    public static readonly LOCATION = `${AppUrlConstant.LOCATION}${AppUrlConstant.URL_SEPARATOR}`;
    public static readonly LOCATION_ADD = `${Url.LOCATION}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.ADD}`;
    public static readonly LOCATION_EDIT = `${Url.LOCATION}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.EDIT}`;
    public static readonly LOCATION_VIEW = `${Url.LOCATION}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.VIEW}`;

    //Setting Module Urls
    public static readonly SETTING = `${AppUrlConstant.SETTING}${AppUrlConstant.URL_SEPARATOR}`;
    public static readonly SETTING_ADD = `${Url.SETTING}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.ADD}`;
    public static readonly SETTING_EDIT = `${Url.SETTING}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.EDIT}`;
    public static readonly SETTING_VIEW = `${Url.SETTING}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.VIEW}`;

    //clients Module Urls
    public static readonly CLIENTS = `${AppUrlConstant.CLIENTS}${AppUrlConstant.URL_SEPARATOR}`;
    public static readonly CLIENTS_ADD = `${Url.CLIENTS}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.ADD}`;
    public static readonly CLIENTS_EDIT = `${Url.CLIENTS}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.EDIT}`;
    public static readonly CLIENTS_VIEW = `${Url.CLIENTS}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.VIEW}`;

    //report Module Urls
    public static readonly REPORT = `${AppUrlConstant.REPORT}${AppUrlConstant.URL_SEPARATOR}`;

    //User ROle Module Urls
    public static readonly USER_ROLE = `${AppUrlConstant.USER_ROLE}${AppUrlConstant.URL_SEPARATOR}`;
    public static readonly ROLE_EDIT = `${Url.USER_ROLE}${AppUrlConstant.URL_SEPARATOR}${AppUrlConstant.EDIT}`;

    public static readonly ALARM_HISTORY = `${AppUrlConstant.ALARM_HISTORY}${AppUrlConstant.URL_SEPARATOR}`;

}

export class ApiUrl {
    private static readonly API_URL = `${environment.apiUrl}`;
    private static readonly PUBLIC_API_URL = `${ApiUrl.API_URL}/${AppUrlConstant.PUBLIC}/`;
    private static readonly PRIVATE_API_URL = `${ApiUrl.API_URL}/${AppUrlConstant.PRIVATE}/`;

    //public module related APIs
    public static readonly LOGIN_API = `${ApiUrl.PUBLIC_API_URL}user/login`;
    public static readonly STATE_DROPDOWN = `${ApiUrl.PUBLIC_API_URL}state?countryId=`;
    public static readonly CITY_DROPDOWN = `${ApiUrl.PUBLIC_API_URL}city?stateId=`;

    //logout API
    public static readonly LOGOUT_API = `${ApiUrl.PRIVATE_API_URL}user/logout`;

    //dashboard APIs
    public static readonly DASHBOARD_API = `${ApiUrl.PRIVATE_API_URL}dashbaord/get-dashboard-data`;
    public static readonly DASHBOARD_VIEW_API = `${ApiUrl.PRIVATE_API_URL}device/parameter-wise-data`;
    public static readonly DASHBOARD_Lat_Long_API = `${ApiUrl.PRIVATE_API_URL}device/get-latitude-longitude`;


    //user module related APIs
    public static readonly USER_SEARCH = `${ApiUrl.PRIVATE_API_URL}user/search`;
    public static readonly USER_ACTIVE_INACTIVE = `${ApiUrl.PRIVATE_API_URL}user/activation`;
    public static readonly USER_DELETE = `${ApiUrl.PRIVATE_API_URL}user/delete`;
    public static readonly USER_VIEW = `${ApiUrl.PRIVATE_API_URL}user/view`;
    public static readonly USER_SAVE = `${ApiUrl.PRIVATE_API_URL}user/save`;
    public static readonly USER_UPDATE = `${ApiUrl.PRIVATE_API_URL}user/update`;

    //parameter-mapping module related APIs
    public static readonly PARAMETER_MAPPING_SEARCH = `${ApiUrl.PRIVATE_API_URL}parametermapping/search`;
    public static readonly PARAMETER_MAPPING_DELETE = `${ApiUrl.PRIVATE_API_URL}parametermapping/delete`;
    public static readonly PARAMETER_MAPPING_VIEW = `${ApiUrl.PRIVATE_API_URL}parametermapping/view`;
    public static readonly PARAMETER_MAPPING_SAVE = `${ApiUrl.PRIVATE_API_URL}parametermapping/save`;
    public static readonly PARAMETER_MAPPING_UPDATE = `${ApiUrl.PRIVATE_API_URL}parametermapping/update`;
    //parameter-mapping module dropdown list
    public static readonly PARAMETER_MAPPING_DROPDOWN = `${ApiUrl.PRIVATE_API_URL}parametermapping/drop-down`;
    public static readonly PARAMETER_AGGREGATION_DROPDOWN = `${ApiUrl.PRIVATE_API_URL}parametermapping/dropdown-aggregation`;

    //gateway module related APIs
    public static readonly GATEWAY_SEARCH = `${ApiUrl.PRIVATE_API_URL}gateway/search`;
    public static readonly GATEWAY_DELETE = `${ApiUrl.PRIVATE_API_URL}gateway/delete`;
    public static readonly GATEWAY_VIEW = `${ApiUrl.PRIVATE_API_URL}gateway/view`;
    public static readonly GATEWAY_SAVE = `${ApiUrl.PRIVATE_API_URL}gateway/save`;
    public static readonly GATEWAY_UPDATE = `${ApiUrl.PRIVATE_API_URL}gateway/update`;

    //Location module related APIs
    public static readonly LOCATION_SEARCH = `${ApiUrl.PRIVATE_API_URL}location/search`;
    public static readonly LOCATION_DELETE = `${ApiUrl.PRIVATE_API_URL}location/delete`;
    public static readonly LOCATION_VIEW = `${ApiUrl.PRIVATE_API_URL}location/view`;
    public static readonly LOCATION_SAVE = `${ApiUrl.PRIVATE_API_URL}location/save`;
    public static readonly LOCATION_UPDATE = `${ApiUrl.PRIVATE_API_URL}location/update`;

    //Client module related APIs 
    public static readonly CLIENT_SEARCH = `${ApiUrl.PRIVATE_API_URL}client/search`;
    public static readonly CLIENT_VIEW = `${ApiUrl.PRIVATE_API_URL}client/view`;
    public static readonly CLIENT_DELETE = `${ApiUrl.PRIVATE_API_URL}client/delete`;
    public static readonly CLIENT_SAVE = `${ApiUrl.PRIVATE_API_URL}client/save`;
    public static readonly CLIENT_UPDATE = `${ApiUrl.PRIVATE_API_URL}client/update`;
    public static readonly CLIENT_ACTIVE_INACTIVE = `${ApiUrl.PRIVATE_API_URL}client/activation`;

    // Download Image API
    public static readonly IMAGE_DOWNLOAD_API = `${ApiUrl.PUBLIC_API_URL}file/download-image?fileId=`;
    public static readonly UPLOAD_IMAGE_API = `${ApiUrl.PRIVATE_API_URL}file/upload-product-image`;

    //Alarm module related APIs
    public static readonly ALARM_SEARCH = `${ApiUrl.PRIVATE_API_URL}gateway/search`;
    public static readonly ALARM_DELETE = `${ApiUrl.PRIVATE_API_URL}gateway/delete`;
    public static readonly ALARM_VIEW = `${ApiUrl.PRIVATE_API_URL}gateway/view`;
    public static readonly ALARM_SAVE = `${ApiUrl.PRIVATE_API_URL}gateway/save`;
    public static readonly ALARM_UPDATE = `${ApiUrl.PRIVATE_API_URL}gateway/update`;

    //Report module related APIs
    public static readonly REPORT_SEARCH = `${ApiUrl.PRIVATE_API_URL}gateway/search`;
    public static readonly REPORT_DELETE = `${ApiUrl.PRIVATE_API_URL}gateway/delete`;
    public static readonly REPORT_VIEW = `${ApiUrl.PRIVATE_API_URL}gateway/view`;
    public static readonly REPORT_SAVE = `${ApiUrl.PRIVATE_API_URL}gateway/save`;
    public static readonly REPORT_UPDATE = `${ApiUrl.PRIVATE_API_URL}gateway/update`;
    public static readonly REPORT_GET_PARAMETER_WISE = `${ApiUrl.PRIVATE_API_URL}device/get-parameter-wise-report`;
    public static readonly REPORT_GET_EXCEL = `${ApiUrl.PRIVATE_API_URL}device/get-excel-report`;

    //gateway module dropdown list
    public static readonly PORT_DROPDOWN = `${ApiUrl.PRIVATE_API_URL}gateway/dropdown-port`;

    //diagnosis-log module related APIs
    public static readonly DIAGNOSIS_LOG_SEARCH = `${ApiUrl.PRIVATE_API_URL}diagnosis/fetch-records`;
    public static readonly DEVICE_DIAGNOSIS_DROPDOWN = `${ApiUrl.PRIVATE_API_URL}device/drop-down`;
    public static readonly DEVICE_DIAGNOSIS_PARAMETER_MAPPING_DROPDOWN = `${ApiUrl.PRIVATE_API_URL}device/device-param/drop-down?deviceId=`;
    public static readonly DEVICE_DIAGNOSIS_SEARCH = `${ApiUrl.PRIVATE_API_URL}diagnosis/fetch-records`;
    public static readonly REPORT_TYPE_DROPDOWN = `${ApiUrl.PRIVATE_API_URL}device/report-type`;

    //device module related APIs
    public static readonly DEVICE_SEARCH = `${ApiUrl.PRIVATE_API_URL}device/search`;
    public static readonly DEVICE_DELETE = `${ApiUrl.PRIVATE_API_URL}device/delete`;
    public static readonly DEVICE_VIEW = `${ApiUrl.PRIVATE_API_URL}device/view`;
    public static readonly DEVICE_SAVE = `${ApiUrl.PRIVATE_API_URL}device/save`;
    public static readonly DEVICE_UPDATE = `${ApiUrl.PRIVATE_API_URL}device/update`;
    public static readonly DEVICE_TYPE = `${ApiUrl.PRIVATE_API_URL}device/dropdown-type`;
    public static readonly DEVICE_DIAGNOSIS_DATA = `${ApiUrl.PRIVATE_API_URL}devicediagnosis/fetch-records`;
    public static readonly DEVICE_EXPORT = `${ApiUrl.PRIVATE_API_URL}devicediagnosis/export`;
    public static readonly DEVICE_PARAMETERID_WISE_LIST = `${ApiUrl.PRIVATE_API_URL}device/parameter-id-wise-list`;

    public static readonly ALARM_HISTORY_DATA = `${ApiUrl.PRIVATE_API_URL}alarmhistory/fetch-records`;

    //screen module related APIs
    public static readonly SCREEN_SEARCH = `${ApiUrl.PRIVATE_API_URL}screen/search`;
    public static readonly SCREEN_DELETE = `${ApiUrl.PRIVATE_API_URL}screen/delete`;
    public static readonly SCREEN_VIEW = `${ApiUrl.PRIVATE_API_URL}screen/view`;
    //public static readonly SCREEN_SAVE = `${ApiUrl.PRIVATE_API_URL}screen/save`;
    public static readonly SCREEN_SAVE = `${ApiUrl.PRIVATE_API_URL}screen/save-screen-data`;
    //public static readonly SCREEN_UPDATE = `${ApiUrl.PRIVATE_API_URL}screen/update`;
    public static readonly SCREEN_UPDATE = `${ApiUrl.PRIVATE_API_URL}screen/update-screen-data`;
    public static readonly SCREEN_DROPDOWN = `${ApiUrl.PRIVATE_API_URL}screen/drop-down`;
    public static readonly USER_SCREEN_DROPDOWN = `${ApiUrl.PRIVATE_API_URL}screen/user-drop-down`;
    public static readonly SCREEN_RAWDATA_SAVE = `${ApiUrl.PRIVATE_API_URL}screen/save-raw`;


    //device module dropdown list
    public static readonly DROPDOWN_DEVICE_STATUS = `${ApiUrl.PRIVATE_API_URL}device/dropdown-status`;
    public static readonly DROPDOWN_INTERNAL_COMMUNICATION = `${ApiUrl.PRIVATE_API_URL}device/dropdown-int-comm`;
    public static readonly DROPDOWN_EXTERNAL_COMMUNICATION = `${ApiUrl.PRIVATE_API_URL}device/dropdown-ext-comm`;
    public static readonly DROPDOWN_GATEWAY_NAME = `${ApiUrl.PRIVATE_API_URL}gateway/dropdown-gateway`;
    public static readonly DROPDOWN_MACHINE_NAME = `${ApiUrl.PRIVATE_API_URL}machine/dropdown-machine`;
    public static readonly DROPDOWN_ENDIANESS = `${ApiUrl.PRIVATE_API_URL}device/dropdown-endianess`;
    public static readonly DROPDOWN_DATAMODE = `${ApiUrl.PRIVATE_API_URL}device/dropdown-datamode`;
    public static readonly DROPDOWN_PARAMETER_MAPPING = `${ApiUrl.PRIVATE_API_URL}parametermapping/drop-down`;

    public static readonly DEVICE_DATA_SEARCH = `${ApiUrl.PRIVATE_API_URL}device/search-device-data`;
    public static readonly DEVICE_DATA_VIEW = `${ApiUrl.PRIVATE_API_URL}device/set-data`;

    //User module related APIs
    public static readonly DROPDOWN_ROLE = `${ApiUrl.PRIVATE_API_URL}role/drop-down`;
    public static readonly USER_ADD = `${ApiUrl.PRIVATE_API_URL}user/add`;

    //User-Role module related APIs
    public static readonly USER_ROLE_SEARCH = `${ApiUrl.PRIVATE_API_URL}role/search`;
    public static readonly USER_ROLE_SAVE = `${ApiUrl.PRIVATE_API_URL}role/save`; 
    public static readonly ROLE_VIEW = `${ApiUrl.PRIVATE_API_URL}role/view`;   
    public static readonly MODULE_ALL = `${ApiUrl.PRIVATE_API_URL}module/all`;
    public static readonly RIGHTS_ALL = `${ApiUrl.PRIVATE_API_URL}rights/all`;
    public static readonly ROLE_DROPDOWN_TYPE = `${ApiUrl.PRIVATE_API_URL}role/dropdown-type`;
    public static readonly ROLE_DELETE = `${ApiUrl.PRIVATE_API_URL}role/delete`;
    public static readonly ROLE_UPDATE = `${ApiUrl.PRIVATE_API_URL}role/update`;
    public static readonly ROLE_ADD = `${ApiUrl.PRIVATE_API_URL}role/add`;
}
