export const environment = {
    production: true,
    tinymceApiKey: '0i9ht3q44zfwubhy5pjaw4uwfs6afu382vy5h5lk96n6pxfv',
    apiUrl: 'http://iot.endlos.in/endlos-api',
};
